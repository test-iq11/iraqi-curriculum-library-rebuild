import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/library_catalog.dart';
import '../services/library_repository.dart';
import 'downloaded_books.dart';
import 'review_bank.dart';

/// Native Flutter interface: no WebView, HTML navigation or JS bridge.
/// The administrator and users still share the same published catalog schema.
class IraqiLibraryUserApp extends StatefulWidget {
  const IraqiLibraryUserApp({super.key});

  /// Shared academic icon mapping used by both the UI and widget tests.
  /// Keep this public facade so test code does not depend on private State.
  static IconData gradeIcon(String grade) =>
      _IraqiLibraryUserAppState.gradeIcon(grade);

  @override
  State<IraqiLibraryUserApp> createState() => _IraqiLibraryUserAppState();
}

class _IraqiLibraryUserAppState extends State<IraqiLibraryUserApp>
    with WidgetsBindingObserver {
  static const _blue = Color(0xff496af2);
  static const _ink = Color(0xff192b4e);
  static const _bg = Color(0xfff5f7ff);
  static const _prefsFav = 'native_user_favorites_v23';
  static const _prefsNotes = 'native_user_notes_v23';
  static const _prefsDark = 'native_user_dark_v23';
  static const _prefsScale = 'native_user_text_scale_v23';

  final _repository = LibraryRepository();
  final _downloads = DownloadedBooks();
  final _prefs = SharedPreferencesAsync();
  final _messenger = GlobalKey<ScaffoldMessengerState>();
  final _navigator = GlobalKey<NavigatorState>();
  final _searchController = TextEditingController();

  LibraryCatalog? _catalog;
  final Set<String> _favorites = {};
  final List<String> _notes = [];
  bool _dark = false;
  bool _syncing = false;
  double _fontScale = 1.0;
  String _section = 'home';
  String? _stageId;
  String? _gradeId;
  String? _subjectId;
  String? _syncError;
  DateTime? _lastSync;
  String _search = '';

  // Review cards: chosen grade / subject and randomized question session.
  String? _reviewGrade;
  String? _reviewSubject;
  List<QuizQuestion> _session = [];
  int _cardIndex = 0;
  bool _answerShown = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      final cached = await _repository.cachedOrPackaged();
      final fav = await _prefs.getString(_prefsFav);
      final notes = await _prefs.getString(_prefsNotes);
      final dark = await _prefs.getBool(_prefsDark) ?? false;
      final scale = await _prefs.getDouble(_prefsScale) ?? 1.0;
      if (!mounted) return;
      setState(() {
        _catalog = cached;
        _dark = dark;
        _fontScale = scale.clamp(.9, 1.25).toDouble();
        if (fav != null) {
          final items = jsonDecode(fav);
          if (items is List) _favorites.addAll(items.map((e) => e.toString()));
        }
        if (notes != null) {
          final items = jsonDecode(notes);
          if (items is List) _notes.addAll(items.map((e) => e.toString()));
        }
      });
      await _refresh();
    } catch (e) {
      _toast('تعذر فتح الفهرس المحلي: $e');
    }
  }

  Future<void> _refresh({bool notify = false}) async {
    if (_syncing || !LibraryEndpoint.configured) {
      if (notify && !LibraryEndpoint.configured) _toast('المزامنة غير مهيأة في نسخة APK');
      return;
    }
    setState(() => _syncing = true);
    try {
      final fresh = await _repository.refreshPublic();
      if (!mounted) return;
      setState(() {
        if (fresh != null) _catalog = fresh;
        _syncError = null;
        _lastSync = DateTime.now();
        _syncing = false;
      });
      if (notify) _toast('تم تحديث الكتب والمراحل بنجاح');
    } catch (e) {
      if (!mounted) return;
      setState(() { _syncError = e.toString(); _syncing = false; });
      if (notify) _toast('تعذرت المزامنة؛ تُعرض آخر نسخة محفوظة');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        (_lastSync == null || DateTime.now().difference(_lastSync!).inMinutes >= 2)) {
      _refresh();
    }
  }

  void _toast(String msg) {
    _messenger.currentState?.showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _saveFavorites() => _prefs.setString(_prefsFav, jsonEncode(_favorites.toList()));
  Future<void> _saveNotes() => _prefs.setString(_prefsNotes, jsonEncode(_notes));

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
  }

  void _go(String section, {String? stageId, String? gradeId, String? subjectId}) {
    FocusManager.instance.primaryFocus?.unfocus();
    _searchController.clear();
    setState(() {
      _section = section;
      _stageId = stageId;
      _gradeId = gradeId;
      _subjectId = subjectId;
      _search = '';
    });
  }

  void _back() {
    switch (_section) {
      case 'books': _go('subjects', stageId: _stageId, gradeId: _gradeId); break;
      case 'subjects': _go('grades', stageId: _stageId); break;
      case 'grades': _go('home'); break;
      default: _go('home');
    }
  }

  Map<String, dynamic>? _lookup(List<Map<String, dynamic>> group, String? id) {
    if (id == null) return null;
    for (final item in group) { if (item['id'] == id) return item; }
    return null;
  }

  List<Map<String, dynamic>> _visibleStages() =>
      _catalog?.sorted(_catalog!.stages, onlyVisible: true) ?? [];

  List<Map<String, dynamic>> _visibleGrades({String? stageId}) =>
      _catalog?.sorted(_catalog!.grades.where((g) =>
        (stageId == null || g['stageId'] == stageId) &&
        _visibleStages().any((s) => s['id'] == g['stageId'])).toList(), onlyVisible: true) ?? [];

  List<Map<String, dynamic>> _visibleSubjects({String? gradeId}) {
    final catalog = _catalog;
    if (catalog == null) return [];
    final gradeIds = _visibleGrades().map((g) => g['id']).toSet();
    return catalog.sorted(catalog.subjects.where((s) =>
      (gradeId == null || s['gradeId'] == gradeId) && gradeIds.contains(s['gradeId'])).toList(), onlyVisible: true);
  }

  List<Map<String, dynamic>> _visibleBooks({String? subjectId}) {
    final catalog = _catalog;
    if (catalog == null) return [];
    final subjectIds = _visibleSubjects().map((s) => s['id']).toSet();
    return catalog.sorted(catalog.books.where((b) =>
      (subjectId == null || b['subjectId'] == subjectId) && subjectIds.contains(b['subjectId'])).toList(), onlyVisible: true);
  }

  static Color _color(Object? value, [Color fallback = _blue]) {
    if (!LibraryCatalog.isColor(value)) return fallback;
    return Color(int.parse('FF${(value as String).substring(1)}', radix: 16));
  }

  static IconData _stageIcon(String? name) => switch (name) {
    'school' => Icons.school_outlined,
    'star' => Icons.workspace_premium_outlined,
    _ => Icons.menu_book_outlined,
  };

  /// School-related grade pictograms (replaces the broken 'ال' abbreviation).
  /// New grades also receive a stable academic icon by name.
  static IconData gradeIcon(String grade) {
    const defined = <String, IconData>{
      'الأول الابتدائي': Icons.edit_outlined,
      'الثاني الابتدائي': Icons.auto_stories_outlined,
      'الثالث الابتدائي': Icons.straighten,
      'الرابع الابتدائي': Icons.explore_outlined,
      'الخامس الابتدائي': Icons.public_outlined,
      'السادس الابتدائي': Icons.calculate_outlined,
      'الأول المتوسط': Icons.menu_book_outlined,
      'الثاني المتوسط': Icons.science_outlined,
      'الثالث المتوسط': Icons.biotech_outlined,
      'الرابع العلمي': Icons.science_outlined,
      'الخامس العلمي': Icons.biotech_outlined,
      'السادس العلمي': Icons.travel_explore_outlined,
      'الرابع الأدبي': Icons.history_edu_outlined,
      'الخامس الأدبي': Icons.library_books_outlined,
      'السادس الأدبي': Icons.lightbulb_outline,
    };
    if (defined.containsKey(grade)) return defined[grade]!;
    const extra = [Icons.edit_outlined, Icons.menu_book_outlined,
      Icons.science_outlined, Icons.calculate_outlined, Icons.public_outlined];
    var sum = 0;
    for (final rune in grade.runes) { sum = (sum * 31 + rune) & 0x7fffffff; }
    return extra[sum % extra.length];
  }

  String _headerTitle() {
    final cat = _catalog;
    if (cat == null) return 'المكتبة العراقية';
    switch (_section) {
      case 'grades': return LibraryCatalog.name(_lookup(cat.stages, _stageId) ?? {});
      case 'subjects': return LibraryCatalog.name(_lookup(cat.grades, _gradeId) ?? {});
      case 'books': return LibraryCatalog.name(_lookup(cat.subjects, _subjectId) ?? {});
      case 'favorites': return 'المفضلة';
      case 'notes': return 'ملاحظاتي';
      case 'downloads': return 'التنزيلات';
      case 'reviews': return 'بطاقات المراجعة';
      case 'settings': return 'الإعدادات';
      default: return 'المكتبة العراقية';
    }
  }

  bool get _nested => const ['grades', 'subjects', 'books', 'downloads', 'reviews'].contains(_section);

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: _blue,
        brightness: _dark ? Brightness.dark : Brightness.light),
      scaffoldBackgroundColor: _dark ? const Color(0xff101a2d) : _bg,
      cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero,
        color: _dark ? const Color(0xff172640) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _dark ? const Color(0xff293b58) : const Color(0xffe4eaf5)))),
      appBarTheme: AppBarTheme(backgroundColor: _dark ? const Color(0xff101a2d) : _bg,
        foregroundColor: _dark ? Colors.white : _ink,
        elevation: 0, centerTitle: false),
    );
    return MaterialApp(
      title: 'المكتبة العراقية',
      debugShowCheckedModeBanner: false,
      theme: theme,
      navigatorKey: _navigator,
      scaffoldMessengerKey: _messenger,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: MediaQuery(data: MediaQuery.of(context).copyWith(
          textScaler: TextScaler.linear(_fontScale)), child: child ?? const SizedBox.shrink()),
      ),
      home: Scaffold(
        appBar: AppBar(
          leading: _nested ? IconButton(tooltip: 'رجوع', onPressed: _back,
            icon: const Icon(Icons.arrow_forward_rounded)) : null,
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_headerTitle(), maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            if (_section == 'home') Text('تعلم بذكاء وتصفح براحة',
              style: const TextStyle(fontSize: 11, color: Color(0xff8c98b0))),
          ]),
          actions: [
            if (_syncing) const Padding(padding: EdgeInsets.all(15),
              child: SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2)))
            else IconButton(tooltip: 'مزامنة الكتب', onPressed: () => _refresh(notify: true),
              icon: const Icon(Icons.sync_rounded)),
            IconButton(tooltip: 'الوضع الليلي', icon: Icon(_dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
              onPressed: () { setState(() => _dark = !_dark); _prefs.setBool(_prefsDark, _dark); }),
          ],
        ),
        body: _catalog == null ? const Center(child: CircularProgressIndicator()) : _body(),
        bottomNavigationBar: NavigationBar(
          selectedIndex: switch (_section) {
            'favorites' => 1, 'notes' => 2, 'settings' => 3, _ => 0,
          },
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) => _go(['home','favorites','notes','settings'][i]),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.notes_outlined), selectedIcon: Icon(Icons.notes_rounded), label: 'الملاحظات'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
          ],
        ),
      ),
    );
  }

  Widget _body() => switch (_section) {
    'grades' => _gradesPage(),
    'subjects' => _subjectsPage(),
    'books' => _booksPage(),
    'favorites' => _favoritesPage(),
    'downloads' => _downloadsPage(),
    'reviews' => _reviewsPage(),
    'notes' => _notesPage(),
    'settings' => _settingsPage(),
    _ => _homePage(),
  };

  Widget _title(String title, [String? subtitle]) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 17, 2, 11),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 4),
        child: Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xff8e9bb0)))),
    ]),
  );

  Widget _homePage() {
    final stages = _visibleStages();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 9, 16, 24), children: [
      Container(
        constraints: const BoxConstraints(minHeight: 174),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xff5352e9), Color(0xff2386ee)])),
        padding: const EdgeInsets.all(22),
        child: Stack(children: [
          Positioned(left: 2, top: 12, child: Icon(Icons.menu_book_rounded,
            size: 97, color: Colors.white.withValues(alpha: .16))),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('المناهج الدراسية العراقية', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            const Text('كل كتبك الدراسية\nفي مكان واحد',
              style: TextStyle(color: Colors.white, fontSize: 23, height: 1.4, fontWeight: FontWeight.w900)),
            const SizedBox(height: 11),
            FilledButton.icon(onPressed: () { if (stages.isNotEmpty) _go('grades', stageId: stages.first['id'].toString()); },
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: _blue),
              icon: const Icon(Icons.auto_stories_outlined), label: const Text('ابدأ التصفح')),
          ]),
        ]),
      ),
      const SizedBox(height: 17),
      TextField(controller: _searchController, onChanged: (v) => setState(() => _search = v),
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search),
          hintText: 'ابحث عن كتاب أو مادة أو صف...', filled: true,
          fillColor: _dark ? const Color(0xff172640) : Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(17),
            borderSide: BorderSide.none)),
      ),
      if (_search.trim().isNotEmpty) ...[
        _title('نتائج البحث'),
        ..._searchResults(),
      ] else ...[
        _title('المراحل الدراسية', 'اختر المرحلة للوصول إلى الصفوف والكتب'),
        ...stages.map((s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _stageCard(s))),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _quickCard('التنزيلات', 'كتبك المحفوظة', Icons.download_outlined,
            const Color(0xff10aa8d), () => _go('downloads'))),
          const SizedBox(width: 10),
          Expanded(child: _quickCard('بطاقات المراجعة', 'أسئلة للتدريب', Icons.style_outlined,
            const Color(0xff8b5bd7), () => _go('reviews'))),
        ]),
      ],
    ]);
  }

  List<Widget> _searchResults() {
    final term = _search.trim().toLowerCase();
    final results = _visibleBooks().where((b) {
      final subject = _lookup(_catalog!.subjects, b['subjectId']?.toString());
      final grade = _lookup(_catalog!.grades, subject?['gradeId']?.toString());
      final bookName = LibraryCatalog.name(b);
      final subjectName = LibraryCatalog.name(subject ?? <String, dynamic>{});
      final gradeName = LibraryCatalog.name(grade ?? <String, dynamic>{});
      return '$bookName $subjectName $gradeName'.toLowerCase().contains(term);
    }).take(50).toList();
    if (results.isEmpty) return [const ListTile(title: Text('لا توجد نتائج مطابقة'))];
    return results.map((b) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _bookCard(b))).toList();
  }

  Widget _stageCard(Map<String, dynamic> item, {bool header = false}) {
    final accent = _color(item['color']);
    final id = item['id'].toString();
    final n = _visibleGrades(stageId: id).length;
    final foreground = header ? null : Colors.white;
    final detail = header ? const Color(0xff8491a7) : Colors.white70;
    return Card(child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _go('grades', stageId: id),
      child: Container(constraints: BoxConstraints(minHeight: header ? 103 : 119),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
          gradient: header ? null : LinearGradient(colors: [
            Color.lerp(accent, Colors.white, .08)!,
            Color.lerp(accent, const Color(0xff142654), .18)!,
          ]),
          border: header ? Border(right: BorderSide(color: accent, width: 5)) : null),
        child: Row(children: [
          if (header) _iconTile(_stageIcon(item['icon']?.toString()), accent, size: 54)
          else Container(width: 54, height: 54,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .2),
              borderRadius: BorderRadius.circular(15)),
            child: Icon(_stageIcon(item['icon']?.toString()), color: Colors.white, size: 30)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(LibraryCatalog.name(item), style: TextStyle(color: foreground,
              fontWeight: FontWeight.w900, fontSize: 17)),
            const SizedBox(height: 4),
            Text((item['description'] ?? '$n صفوف').toString(),
              maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: detail)),
          ])),
          Column(children: [Icon(Icons.chevron_left, color: foreground ?? accent),
            Text('$n صفوف', style: TextStyle(color: foreground ?? accent,
              fontSize: 10, fontWeight: FontWeight.w800))]),
        ]),
      ),
    ));
  }

  Widget _quickCard(String title, String detail, IconData symbol, Color accent, VoidCallback action) =>
    Card(child: InkWell(onTap: action, borderRadius: BorderRadius.circular(19),
      child: Padding(padding: const EdgeInsets.all(14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          _iconTile(symbol, accent, size: 47),
          const SizedBox(height: 12),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 3),
          Text(detail, style: const TextStyle(color: Color(0xff8e9bb0), fontSize: 10)),
        ])),
    ));

  Widget _iconTile(IconData symbol, Color accent, {double size = 52}) => Container(
    width: size, height: size,
    decoration: BoxDecoration(color: accent.withValues(alpha: .11),
      borderRadius: BorderRadius.circular(15)),
    child: Icon(symbol, color: accent, size: size * .49),
  );

  Widget _gradesPage() {
    final stage = _lookup(_catalog!.stages, _stageId);
    final grades = _visibleGrades(stageId: _stageId);
    return Column(children: [
      if (stage != null) Padding(padding: const EdgeInsets.fromLTRB(15, 12, 15, 0),
        child: _stageCard(stage, header: true)),
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 25),
        itemCount: grades.length + 1,
        itemBuilder: (ctx, index) {
          if (index == 0) return _title('اختر الصف الدراسي', 'لكل صف أيقونة دراسية ولون مميز');
          final grade = grades[index - 1];
          final accent = _color(grade['color']);
          final gradeId = grade['id'].toString();
          final subjects = _visibleSubjects(gradeId: gradeId);
          final books = subjects.expand((s) => _visibleBooks(subjectId: s['id'].toString())).length;
          return Padding(padding: const EdgeInsets.only(bottom: 11), child: Card(
            child: InkWell(onTap: () => _go('subjects', stageId: _stageId, gradeId: gradeId),
              borderRadius: BorderRadius.circular(20),
              child: Container(constraints: const BoxConstraints(minHeight: 95),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                  border: Border(right: BorderSide(color: accent, width: 6))),
                child: Row(children: [
                  _iconTile(gradeIcon(LibraryCatalog.name(grade)), accent, size: 62),
                  const SizedBox(width: 15),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(LibraryCatalog.name(grade), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 5),
                    Text('$books كتب مدرجة', style: const TextStyle(color: Color(0xff8897a9), fontSize: 12)),
                  ])),
                  Icon(Icons.chevron_left_rounded, color: accent),
                ]),
              ),
            ),
          ));
        },
      )),
    ]);
  }

  Widget _subjectsPage() {
    final subjects = _visibleSubjects(gradeId: _gradeId);
    final grade = _lookup(_catalog!.grades, _gradeId);
    final accent = _color(grade?['color']);
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 25),
      itemCount: subjects.length + 1,
      itemBuilder: (ctx, index) {
        if (index == 0) return _title('المواد الدراسية', 'اختر مادة لعرض كتبها');
        final item = subjects[index - 1];
        final number = _visibleBooks(subjectId: item['id'].toString()).length;
        return Padding(padding: const EdgeInsets.only(bottom: 10),
          child: Card(child: ListTile(
            contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
            leading: _iconTile(Icons.menu_book_outlined, accent),
            title: Text(LibraryCatalog.name(item), style: const TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text('$number كتب'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _go('books', stageId: _stageId, gradeId: _gradeId,
              subjectId: item['id'].toString()),
          )),
        );
      },
    );
  }

  Widget _booksPage() {
    final books = _visibleBooks(subjectId: _subjectId).where((b) =>
      LibraryCatalog.name(b).toLowerCase().contains(_search.toLowerCase())).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 13, 16, 3), child: TextField(
        controller: _searchController, onChanged: (v) => setState(() => _search = v),
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search),
          hintText: 'ابحث في كتب المادة', border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14))),
      )),
      Expanded(child: books.isEmpty ? const Center(child: Text('لا توجد كتب مطابقة')) :
        ListView.builder(padding: const EdgeInsets.fromLTRB(16, 13, 16, 25),
          itemCount: books.length, itemBuilder: (ctx, i) => Padding(
            padding: const EdgeInsets.only(bottom: 9), child: _bookCard(books[i])))),
    ]);
  }

  Widget _bookCard(Map<String, dynamic> book) {
    final subject = _lookup(_catalog!.subjects, book['subjectId']?.toString());
    final grade = _lookup(_catalog!.grades, subject?['gradeId']?.toString());
    final accent = _color(grade?['color']);
    final id = book['id'].toString();
    final subjectName = LibraryCatalog.name(subject ?? <String, dynamic>{});
    final gradeName = LibraryCatalog.name(grade ?? <String, dynamic>{});
    final location = '$subjectName • $gradeName';
    return Card(child: InkWell(borderRadius: BorderRadius.circular(19),
      onTap: () => _bookActions(book),
      child: Padding(padding: const EdgeInsets.all(11), child: Row(children: [
        _iconTile(Icons.auto_stories_outlined, accent, size: 56),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(LibraryCatalog.name(book), maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 5),
          Text(location,
            maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10.5, color: Color(0xff8693a8))),
          const SizedBox(height: 4),
          Text('اضغط لفتح خيارات الكتاب', style: TextStyle(color: accent, fontSize: 10)),
        ])),
        IconButton(tooltip: _favorites.contains(id) ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
          onPressed: () => _toggleFavorite(id),
          icon: Icon(_favorites.contains(id) ? Icons.favorite : Icons.favorite_border,
            color: _favorites.contains(id) ? const Color(0xffe95e88) : accent)),
        Icon(Icons.chevron_left_rounded, color: accent),
      ])),
    ));
  }

  Future<void> _bookActions(Map<String, dynamic> book) async {
    final id = book['id'].toString();
    final url = (book['url'] ?? '').toString();
    final valid = LibraryCatalog.validWebUrl(url);
    final ctx = _navigator.currentContext;
    if (ctx == null) return;
    await showModalBottomSheet<void>(context: ctx, isScrollControlled: true,
      showDragHandle: true, useSafeArea: true,
      builder: (sheet) => Padding(padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(LibraryCatalog.name(book), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 13),
          FilledButton.icon(onPressed: valid ? () {
            Navigator.pop(sheet); _read(book);
          } : null, icon: const Icon(Icons.chrome_reader_mode_outlined), label: const Text('فتح الكتاب')),
          OutlinedButton.icon(onPressed: valid ? () {
            Navigator.pop(sheet); _download(book);
          } : null, icon: const Icon(Icons.download_outlined), label: const Text('تحميل الكتاب')),
          OutlinedButton.icon(onPressed: valid ? () async {
            await Clipboard.setData(ClipboardData(text: url));
            if (sheet.mounted) Navigator.pop(sheet);
            _toast('تم نسخ رابط الكتاب');
          } : null, icon: const Icon(Icons.copy_outlined), label: const Text('نسخ الرابط')),
          TextButton.icon(onPressed: () {
            Navigator.pop(sheet); _toggleFavorite(id);
          }, icon: Icon(_favorites.contains(id) ? Icons.favorite : Icons.favorite_border),
            label: Text(_favorites.contains(id) ? 'إزالة من المفضلة' : 'إضافة للمفضلة')),
        ]),
      ),
    );
  }

  Future<void> _read(Map<String, dynamic> book) async {
    final url = (book['url'] ?? '').toString();
    if (!LibraryCatalog.validWebUrl(url)) { _toast('رابط الكتاب غير صالح'); return; }
    final file = await _downloads.localFile(book['id'].toString());
    if (!mounted) return;
    await _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
      title: LibraryCatalog.name(book), url: url, localPath: file)));
  }

  Future<void> _download(Map<String, dynamic> book) async {
    _toast('بدأ تنزيل الكتاب');
    try {
      final path = await _downloads.download(book);
      if (!mounted) return;
      _toast('اكتمل التنزيل بنجاح');
      await _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
        title: LibraryCatalog.name(book), url: (book['url'] ?? '').toString(), localPath: path)));
    } catch (e) { _toast('تعذر التنزيل: $e'); }
  }

  Widget _favoritesPage() {
    final books = _visibleBooks().where((b) => _favorites.contains(b['id'])).toList();
    return books.isEmpty ? const Center(child: Text('لم تُضف كتباً إلى المفضلة بعد')) :
      ListView.builder(padding: const EdgeInsets.all(15), itemCount: books.length,
        itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.only(bottom: 9),
          child: _bookCard(books[i])));
  }

  Widget _downloadsPage() => FutureBuilder<Map<String, dynamic>>(
    future: _downloads.entries(),
    builder: (context, snapshot) {
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final items = snapshot.data!.entries.toList();
      if (items.isEmpty) return const Center(child: Text('لم تحمّل كتباً بعد'));
      return ListView.builder(padding: const EdgeInsets.all(15), itemCount: items.length,
        itemBuilder: (ctx, i) {
          final entry = items[i];
          final book = Map<String, dynamic>.from(entry.value as Map);
          return Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(
            child: ListTile(leading: const Icon(Icons.picture_as_pdf_outlined, color: _blue),
              title: Text((book['title'] ?? 'كتاب').toString()),
              subtitle: const Text('محفوظ للقراءة دون إنترنت'),
              onTap: () => _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
                title: (book['title'] ?? 'كتاب').toString(), url: (book['sourceUrl'] ?? '').toString(),
                localPath: (book['path'] ?? '').toString()))),
              trailing: IconButton(tooltip: 'حذف النسخة المحمّلة', icon: const Icon(Icons.delete_outline),
                onPressed: () async { await _downloads.remove(entry.key); if (mounted) setState(() {}); }),
            ),
          ));
        },
      );
    },
  );

  List<Map<String, dynamic>> _reviewSubjects() => _reviewGrade == null ? [] : _visibleSubjects(gradeId: _reviewGrade)
    .where((s) => makeQuizQuestions('', LibraryCatalog.name(s)).isNotEmpty).toList();

  void _newReview() {
    if (_reviewSubject == null) return;
    final subject = _lookup(_catalog!.subjects, _reviewSubject);
    if (subject == null) return;
    final questions = makeQuizQuestions('', LibraryCatalog.name(subject)).toList();
    questions.shuffle(Random());
    setState(() {
      _session = questions.take(20).toList();
      _cardIndex = 0;
      _answerShown = false;
    });
  }

  Widget _reviewsPage() {
    final grades = _visibleGrades();
    final subjects = _reviewSubjects();
    final question = _session.isNotEmpty && _cardIndex < _session.length ? _session[_cardIndex] : null;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: [
      _title('بطاقات المراجعة', 'اختر الصف والمادة وراجع أسئلة تدريبية من النسخة القديمة'),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        DropdownButtonFormField<String>(initialValue: _reviewGrade,
          isExpanded: true, decoration: const InputDecoration(labelText: 'الصف الدراسي', border: OutlineInputBorder()),
          items: grades.map((g) => DropdownMenuItem(value: g['id'].toString(),
            child: Text(LibraryCatalog.name(g)))).toList(),
          onChanged: (v) => setState(() { _reviewGrade = v; _reviewSubject = null; _session = []; }),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(key: ValueKey(_reviewGrade), initialValue: _reviewSubject,
          isExpanded: true, decoration: const InputDecoration(labelText: 'المادة', border: OutlineInputBorder()),
          items: subjects.map((s) => DropdownMenuItem(value: s['id'].toString(),
            child: Text(LibraryCatalog.name(s)))).toList(),
          onChanged: (v) => setState(() { _reviewSubject = v; _session = []; }),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: _reviewSubject == null ? null : _newReview,
          icon: const Icon(Icons.shuffle), label: const Text('ابدأ جلسة مراجعة جديدة')),
      ]))),
      if (_reviewGrade != null && subjects.isEmpty) Padding(
        padding: const EdgeInsets.all(15), child: Text('لا تتوفر أسئلة تدريبية لهذه المواد في النسخة القديمة حالياً.')),
      if (question != null) ...[
        _title('بطاقة ${_cardIndex + 1} من ${_session.length}', 'تذكّر الإجابة ثم اضغط على البطاقة'),
        Card(child: InkWell(borderRadius: BorderRadius.circular(20),
          onTap: () => setState(() => _answerShown = !_answerShown),
          child: SizedBox(height: 230, child: Padding(padding: const EdgeInsets.all(23),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(_answerShown ? Icons.check_circle_outline : Icons.quiz_outlined,
                size: 38, color: _answerShown ? const Color(0xff0fa98e) : _blue),
              const SizedBox(height: 16),
              Text(_answerShown ? question.choices[question.answer] : question.text,
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 18),
              Text(_answerShown ? 'اضغط للعودة للسؤال' : 'اضغط لكشف الإجابة',
                style: const TextStyle(color: Color(0xff8996ab), fontSize: 11)),
            ])),
          ),
        )),
        const SizedBox(height: 13),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _cardIndex == 0 ? null : () => setState(() {
            _cardIndex--; _answerShown = false;
          }), icon: const Icon(Icons.navigate_next), label: const Text('السابقة'))),
          const SizedBox(width: 9),
          Expanded(child: FilledButton.icon(onPressed: () {
            if (_cardIndex < _session.length - 1) {
              setState(() { _cardIndex++; _answerShown = false; });
            } else {
              _newReview();
            }
          }, icon: const Icon(Icons.navigate_before), label: Text(_cardIndex == _session.length - 1 ? 'جلسة جديدة' : 'التالية'))),
        ]),
      ],
      const SizedBox(height: 10),
      const Text('هذه أسئلة تدريبية عامة مستعادة من كود النسخة السابقة، وليست بديلاً عن مراجعة الكتاب الوزاري.',
        textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Color(0xff8d9bb1))),
    ]);
  }

  Future<void> _editNote({int? index}) async {
    final controller = TextEditingController(text: index == null ? '' : _notes[index]);
    final ctx = _navigator.currentContext;
    if (ctx == null) { controller.dispose(); return; }
    final result = await showDialog<String>(context: ctx, builder: (dialog) => AlertDialog(
      title: Text(index == null ? 'ملاحظة جديدة' : 'تعديل الملاحظة'),
      content: TextField(controller: controller, maxLength: 1500, minLines: 3, maxLines: 7,
        decoration: const InputDecoration(hintText: 'اكتب ملاحظتك...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(dialog, controller.text.trim()),
          child: const Text('حفظ')),
      ],
    ));
    controller.dispose();
    if (result == null || result.isEmpty || !mounted) return;
    setState(() { if (index == null) { _notes.insert(0, result); } else { _notes[index] = result; } });
    await _saveNotes();
  }

  Widget _notesPage() => Column(children: [
    Padding(padding: const EdgeInsets.all(16), child: SizedBox(width: double.infinity,
      child: FilledButton.icon(onPressed: () => _editNote(),
        icon: const Icon(Icons.note_add_outlined), label: const Text('إضافة ملاحظة')))),
    Expanded(child: _notes.isEmpty ? const Center(child: Text('لا توجد ملاحظات بعد')) :
      ListView.builder(padding: const EdgeInsets.fromLTRB(15, 0, 15, 22), itemCount: _notes.length,
        itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Card(
          child: ListTile(title: Text(_notes[i], maxLines: 10),
            onTap: () => _editNote(index: i),
            trailing: IconButton(tooltip: 'حذف الملاحظة', icon: const Icon(Icons.delete_outline),
              onPressed: () { setState(() => _notes.removeAt(i)); _saveNotes(); })),
        )))),
  ]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _title('إعدادات المكتبة'),
    Card(child: Column(children: [
      SwitchListTile.adaptive(secondary: const Icon(Icons.dark_mode_outlined),
        title: const Text('الوضع الليلي'), value: _dark,
        onChanged: (v) { setState(() => _dark = v); _prefs.setBool(_prefsDark, v); }),
      ListTile(leading: const Icon(Icons.text_fields), title: const Text('حجم الخط'),
        subtitle: Slider(value: _fontScale, min: .9, max: 1.25, divisions: 7,
          label: '${(_fontScale * 100).round()}%', onChanged: (v) {
            setState(() => _fontScale = v); _prefs.setDouble(_prefsScale, v);
          })),
      ListTile(leading: const Icon(Icons.cloud_sync_outlined), title: const Text('تحديث الكتب والمراحل'),
        subtitle: Text(_syncError == null ?
          (_lastSync == null ? 'لم تتم المزامنة بعد' : 'آخر مزامنة: ${_lastSync!.hour}:${_lastSync!.minute.toString().padLeft(2, '0')}') :
          'فشلت المزامنة الأخيرة: $_syncError', maxLines: 3),
        trailing: IconButton(onPressed: _syncing ? null : () => _refresh(notify: true),
          icon: const Icon(Icons.refresh)),
      ),
      ListTile(leading: const Icon(Icons.info_outline), title: const Text('نسخة فهرس الكتب'),
        subtitle: Text('الإصدار ${_catalog?.revision ?? 0} • ${_visibleStages().length} مراحل')),
    ])),
    const SizedBox(height: 20),
    const Text('يتم جلب التحديثات من GitHub دون تعديل بياناتك الشخصية أو المفضلة أو الملاحظات.',
      style: TextStyle(color: Color(0xff8f9bb0), fontSize: 12)),
  ]);

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _searchController.dispose();
    super.dispose();
  }
}

/// Continuous vertical PDF reader. An already-downloaded PDF opens offline.
class BookPdfScreen extends StatelessWidget {
  const BookPdfScreen({super.key, required this.title, required this.url, this.localPath});
  final String title;
  final String url;
  final String? localPath;

  @override
  Widget build(BuildContext context) {
    final Uri uri = DownloadedBooks.directPdfUri(url);
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
        IconButton(tooltip: 'فتح المصدر في المتصفح', icon: const Icon(Icons.open_in_browser),
          onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)),
      ]),
      body: (localPath != null)
          ? PdfViewer.file(localPath!, params: const PdfViewerParams(margin: 6, verticalCacheExtent: 1.3))
          : PdfViewer.uri(uri, params: const PdfViewerParams(margin: 6, verticalCacheExtent: 1.3),
              timeout: const Duration(seconds: 30)),
      bottomNavigationBar: SafeArea(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        child: Text('تمرير عمودي متواصل • كبّر بإصبعين • عند تعذر عرض Google Drive افتح المصدر من الأعلى',
          textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelSmall),
      )),
    ));
  }
}
