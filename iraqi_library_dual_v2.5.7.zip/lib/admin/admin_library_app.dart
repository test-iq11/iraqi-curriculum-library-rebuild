import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../models/library_catalog.dart';
import '../models/catalog_merge.dart';
import '../services/github_publisher.dart';
import '../services/library_repository.dart';
import 'catalog_tools.dart';


const kBlue = Color(0xff496af2);
const kInk = Color(0xff172748);
const kBg = Color(0xfff5f7fc);

class IraqiLibraryAdminApp extends StatelessWidget {
  const IraqiLibraryAdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'مدير المكتبة العراقية',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: kBg,
          colorScheme: ColorScheme.fromSeed(seedColor: kBlue),
          appBarTheme: const AppBarTheme(backgroundColor: kBg, foregroundColor: kInk),
          cardTheme: const CardThemeData(color: Colors.white, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          ),
        ),
        home: const Directionality(textDirection: TextDirection.rtl, child: ManagerHome()),
      );
}

class ManagerHome extends StatefulWidget {
  const ManagerHome({super.key});
  @override
  State<ManagerHome> createState() => _ManagerHomeState();
}

class _ManagerHomeState extends State<ManagerHome> {
  final LibraryRepository _repo = LibraryRepository();
  final GitHubPublisher _publisher = GitHubPublisher();
  final SharedPreferencesAsync _managerPrefs = SharedPreferencesAsync();
  final LocalAuthentication _localAuth = LocalAuthentication();
  static const _managerLockKey = 'manager_require_local_auth_v24';
  String _tool = '';
  bool _requireAuth = false;
  String? _linkCheckResult, _publicStatus;
  ImportPreview? _importPreview;
  List<Map<String, String>> _history = [];
  final Set<String> _selectedBooks = {}; 
  LibraryCatalog? _doc;
  LibraryCatalog? _published;
  bool _dirty = false, _busy = false, _hasToken = false;
  String _status = 'مخزّن محلياً';
  int _tab = 0;
  final List<Map<String, String>> _path = [];
  String _search = '';

  @override
  void initState() { super.initState(); _initialize(); }

  Future<void> _initialize() async {
    try {
      final baseline = await _repo.cachedOrPackaged();
      final dirty = await _repo.hasDraft();
      final draft = dirty ? await _repo.loadDraft() : null;
      final draftBase = dirty ? await _repo.loadDraftBase() : null;
      final token = await _publisher.hasToken;
      final requireAuth = await _managerPrefs.getBool(_managerLockKey) ?? false;
      if (!mounted) return;
      setState(() {
        _published = draftBase ?? baseline;
        _doc = draft ?? baseline.copy();
        _dirty = draft != null;
        _hasToken = token;
        _requireAuth = requireAuth;
      });
      if (token && LibraryEndpoint.configured) {
        await _refreshFromGitHub(silent: true);
      }
    } catch (e) { _toast('تعذّر تحميل بيانات الإدارة: $e'); }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 5)));
  }

  Future<void> _save(LibraryCatalog next) async {
    try {
      next.validate();
      await _repo.saveDraft(next, base: _dirty ? null : _published);
      if (!mounted) return;
      setState(() { _doc = next; _dirty = true; _status = 'تعديلات غير منشورة'; });
      _toast('تم الحفظ محلياً؛ اضغط «نشر» لإظهاره للمستخدمين');
    } catch (e) { _toast('لم يُقبل التعديل: $e'); }
  }

  /// Check the live file and merge independent edits instead of relying on
  /// JSON equality with the catalog bundled into the APK.
  Future<void> _refreshFromGitHub({bool silent = false}) async {
    if (_busy) return;
    if (!_hasToken) {
      if (!silent) { _toast('أضف رمز GitHub من الإعدادات أولاً'); }
      return;
    }
    if (!LibraryEndpoint.configured) {
      if (!silent) { _toast('المستودع لم يهيّأ أثناء بناء APK'); }
      return;
    }
    setState(() => _busy = true);
    try {
      final remote = await _publisher.fetch();
      if (!mounted) return;
      final current = remote.catalog;
      if (current == null) {
        setState(() {
          _status = 'الفهرس لم يُنشر بعد؛ مسودتك محفوظة';
        });
      } else if (!_dirty) {
        await _repo.markPublished(current);
        if (!mounted) return;
        setState(() {
          _published = current;
          _doc = current.copy();
          _status = 'تم تحميل النسخة المنشورة';
        });
      } else {
        final merged = CatalogMerger.merge(
          base: _published ?? current,
          local: _doc!,
          remote: current,
        );
        if (merged.hasConflicts) {
          // Do not delete or replace the draft. The publish dialog can resolve
          // precisely these overlapping fields with explicit confirmation.
          setState(() {
              _status = 'هناك ${merged.conflicts.length} تغييرات متعارضة؛ اضغط نشر لمراجعتها دون حذف مسودتك';
          });
        } else {
          final isDirty = jsonEncode(merged.catalog.toJson()) != jsonEncode(current.toJson());
          if (isDirty) {
            await _repo.saveDraft(merged.catalog, base: current);
          } else {
            await _repo.markPublished(current);
          }
          if (!mounted) return;
          setState(() {
            _published = current;
            _doc = merged.catalog;
              _dirty = isDirty;
            _status = isDirty
                ? 'تم دمج مسودتك مع GitHub؛ جاهزة للنشر'
                : 'تعديلات مسودتك منشورة بالفعل';
          });
        }
      }
      if (!silent) { _toast(_status); }
    } catch (e) {
      if (!silent) { _toast('تعذّر فحص GitHub: $e'); }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<bool> _confirmOverlappingChanges(List<String> conflicts) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مراجعة تغييرات متعارضة'),
        content: SizedBox(
          width: 360,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('هناك معلومات عدّلتها أنت وتغيّرت أيضاً على GitHub. التعديلات الأخرى ستُدمج تلقائياً. هل تريد اعتماد تعديلك في المعلومات المتعارضة فقط؟'),
              const SizedBox(height: 12),
              ...conflicts.take(12).map((v) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text('• $v', style: const TextStyle(fontSize: 12)),
              )),
              if (conflicts.length > 12) Text('و${conflicts.length - 12} تعارضات أخرى'),
              const SizedBox(height: 10),
              const Text('يمكنك الإلغاء والاحتفاظ بمسودتك بالكامل. لن يُستبدل محتوى GitHub دون موافقتك.',
                style: TextStyle(fontSize: 12, color: Color(0xFF7F4850))),
            ]),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('اعتماد تعديلاتي المتعارضة')),
        ],
      ),
    );
    return approved == true;
  }

  Future<void> _publish() async {
    if (_doc == null || _busy) return;
    if (!_hasToken) {
      _toast('أدخل رمز GitHub من الإعدادات');
      _openTool('security');
      return;
    }
    if (!LibraryEndpoint.configured) {
      _toast('المستودع غير مهيأ في ملف البناء');
      return;
    }
    if (!await _approvePublish() || !mounted) { return; }
    setState(() => _busy = true);
    try {
      // Fetch immediately before publishing. The SHA is checked again by
      // GitHubPublisher: a simultaneous edit cannot be silently overwritten.
      final latest = await _publisher.fetch();
      if (!mounted) return;
      var pending = _doc!;
      if (latest.catalog != null) {
        final base = _published ?? latest.catalog!;
        final preview = CatalogMerger.merge(
          base: base, local: pending, remote: latest.catalog!,
        );
        if (preview.hasConflicts) {
          final approved = await _confirmOverlappingChanges(preview.conflicts);
          if (!approved || !mounted) { return; }
          pending = CatalogMerger.merge(
            base: base, local: pending, remote: latest.catalog!,
            preferLocalConflicts: true,
          ).catalog;
        } else {
          pending = preview.catalog;
        }
        // Save the merged draft before the network write so that even a
        // connectivity failure cannot wipe out the local edits.
        await _repo.saveDraft(pending, base: latest.catalog!);
        if (!mounted) return;
        setState(() {
          _doc = pending;
          _published = latest.catalog;
          _dirty = true;
          _status = 'جارٍ نشر المسودة المدمجة';
        });
      }
      final result = await _publisher.publish(draft: pending, baseSha: latest.sha);
      final published = result.catalog!;
      await _repo.markPublished(published);
      if (!mounted) return;
      setState(() {
        _doc = published.copy();
        _published = published;
        _dirty = false;
        _status = 'تم النشر بنجاح • الإصدار ${published.revision}';
      });
      _toast('نُشرت البيانات على GitHub. ستصل للمستخدمين عند المزامنة.');
    } catch (e) {
      if (mounted) { _toast('تعذّر النشر، مسودتك محفوظة: $e'); }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _openPath(String type, Map<String, dynamic> item) {
    setState(() => _path.add({'type': type, 'id': item['id'].toString(), 'name': LibraryCatalog.name(item)}));
  }

  String get _currentType => switch (_path.length) {
    0 => 'stage', 1 => 'grade', 2 => 'subject', _ => 'book',
  };

  String? get _currentParent => _path.isEmpty ? null : _path.last['id'];

  List<Map<String, dynamic>> _shown() {
    final doc = _doc;
    if (doc == null) return [];
    if (_currentType == 'stage') return doc.sorted(doc.stages);
    return doc.children(_path.last['type']!, _path.last['id']!);
  }

  String _label(String type) => switch (type) {
    'stage' => 'مرحلة', 'grade' => 'صف', 'subject' => 'مادة', _ => 'كتاب',
  };

  IconData _typeIcon(String type) => switch (type) {
    'stage' => Icons.school_outlined, 'grade' => Icons.view_module_outlined,
    'subject' => Icons.menu_book_outlined, _ => Icons.auto_stories_outlined,
  };

  Color _hex(String? color) {
    if (color == null || !LibraryCatalog.isColor(color)) return kBlue;
    return Color(int.parse('FF${color.substring(1)}', radix: 16));
  }

  // Every stored value remains a canonical #RRGGBB color string.
  String _colorCode(Color value) =>
      '#${(value.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';

  // Use the parent color for older books/subjects that have no custom color.
  String _editorDefaultColor(String type, Map<String, dynamic>? original) {
    final parentType = switch (type) {
      'grade' => 'stage', 'subject' => 'grade', 'book' => 'subject', _ => '',
    };
    if (_doc == null || parentType.isEmpty) return '#5274F1';
    final parentKey = switch (type) {
      'grade' => 'stageId', 'subject' => 'gradeId', _ => 'subjectId',
    };
    final parentId = original == null ? _currentParent : original[parentKey]?.toString();
    for (final parent in _doc!.group(parentType)) {
      if (parent['id'] == parentId && LibraryCatalog.isColor(parent['color'])) {
        return parent['color'] as String;
      }
    }
    return type == 'book' ? '#19A7C4' : '#6484EA';
  }

  Future<void> _showEditor(String type, {Map<String, dynamic>? original}) async {
    final titleCtl = TextEditingController(text: original == null ? '' : LibraryCatalog.name(original));
    final descCtl = TextEditingController(text: original?['description']?.toString() ?? '');
    final urlCtl = TextEditingController(text: original?['url']?.toString() ?? '');
    final colorCtl = TextEditingController(text: LibraryCatalog.isColor(original?['color'])
        ? original!['color'] as String : _editorDefaultColor(type, original));
    const colorNames = <String, String>{
      '#4777F2': 'أزرق', '#8955DA': 'بنفسجي', '#EC5B89': 'وردي',
      '#F59E48': 'برتقالي', '#10B69A': 'فيروزي', '#19A7C4': 'سماوي',
      '#5674AA': 'نيلي', '#7B65E9': 'بنفسجي', '#D47438': 'نحاسي',
      '#8A9F36': 'زيتوني', '#B85FA8': 'موف', '#3E8C6C': 'أخضر',
      '#1C83CF': 'أزرق', '#A9644E': 'بني', '#5267B5': 'نيلي',
      '#D85263': 'أحمر',
    };
    const academicIcons = ['book', 'school', 'star', 'pencil', 'ruler', 'compass', 'globe', 'science', 'calculator', 'history'];
    String icon = academicIcons.contains(original?['icon']) ? original!['icon'] as String : 'book';
    bool visible = original?['visible'] != false;
    final key = GlobalKey<FormState>();
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, update) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
        title: Text(original == null ? 'إضافة ${_label(type)}' : 'تعديل ${_label(type)}'),
        content: Form(key: key, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(controller: titleCtl, autofocus: true,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(labelText: type == 'book' ? 'عنوان الكتاب' : 'الاسم'),
              validator: (v) => (v == null || v.trim().isEmpty || v.trim().length > 180)
                ? 'اكتب اسماً لا يتجاوز 180 حرفاً' : null,
            ),
            if (type == 'stage') ...[
              const SizedBox(height: 12),
              TextFormField(controller: descCtl, decoration: const InputDecoration(labelText: 'وصف المرحلة')),
            ],
            if (type == 'stage' || type == 'grade') ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(initialValue: icon,
                decoration: InputDecoration(labelText: 'أيقونة ${_label(type)}'),
                items: const [
                  DropdownMenuItem(value:'book',child:Text('📘  كتاب')),
                  DropdownMenuItem(value:'school',child:Text('🏫  مدرسة')),
                  DropdownMenuItem(value:'star',child:Text('⭐  تميز')),
                  DropdownMenuItem(value:'pencil',child:Text('✏️  قلم')),
                  DropdownMenuItem(value:'ruler',child:Text('📏  مسطرة')),
                  DropdownMenuItem(value:'compass',child:Text('📐  أدوات هندسية')),
                  DropdownMenuItem(value:'globe',child:Text('🌍  جغرافية')),
                  DropdownMenuItem(value:'science',child:Text('🔬  علوم')),
                  DropdownMenuItem(value:'calculator',child:Text('🔢  رياضيات')),
                  DropdownMenuItem(value:'history',child:Text('📜  تاريخ')),
                ],
                onChanged: (v) => update(() => icon = v ?? 'book'),
              ),
            ],
            // A subject and a book now have their own color, with parent fallback.
            if (type == 'grade' || type == 'stage' || type == 'subject' || type == 'book') ...[
              const SizedBox(height: 16),
              const Text('اختيار لون البطاقة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Row(children: [
                Container(height: 52, width: 65,
                  decoration: BoxDecoration(color: _hex(colorCtl.text), borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: const Color(0xffd9e1f0))),
                  child: const Icon(Icons.palette_outlined, color: Colors.white)),
                const SizedBox(width: 12),
                Expanded(child: TextFormField(controller: colorCtl,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(labelText: 'رمز اللون HEX', hintText: '#496AF2',
                    helperText: 'اختر من الألوان أو اكتب الرمز'),
                  onChanged: (_) => update(() {}),
                  validator: (v) => LibraryCatalog.isColor(v) ? null : 'اكتب اللون بصيغة #RRGGBB',
                )),
              ]),
              const SizedBox(height: 14),
              const Text('لوحة الألوان', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
              const SizedBox(height: 7),
              Wrap(spacing: 8, runSpacing: 8, children: [
                '#4777F2', '#8955DA', '#EC5B89', '#F59E48',
                '#10B69A', '#19A7C4', '#5674AA', '#7B65E9',
                '#D47438', '#8A9F36', '#B85FA8', '#3E8C6C',
                '#1C83CF', '#A9644E', '#5267B5', '#D85263',
              ].map((hex) {
                final selected = colorCtl.text.toUpperCase() == hex;
                return Tooltip(message: hex, child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => update(() => colorCtl.text = hex),
                  child: AnimatedContainer(duration: const Duration(milliseconds: 130),
                    width: 57, height: 62, padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: selected ? _hex(hex).withValues(alpha: .11) : const Color(0xFFF8FAFE),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: selected ? _hex(hex) : const Color(0xffE2E7EF),
                        width: selected ? 2.3 : 1),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(width: 31, height: 31,
                        decoration: BoxDecoration(color: _hex(hex), borderRadius: BorderRadius.circular(10)),
                        child: selected ? const Icon(Icons.check_rounded, color: Colors.white, size: 20) : null),
                      const SizedBox(height: 3),
                      Text(colorNames[hex] ?? '', style: const TextStyle(fontSize: 9,
                        fontWeight: FontWeight.w800, color: kInk)),
                    ]),
                  ),
                ));
              }).toList()),
              const SizedBox(height: 13),
              const Text('اختيار درجة اللون بدقة',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
              Row(children: [
                const SizedBox(width: 49, child: Text('اللون', style: TextStyle(fontSize: 11))),
                Expanded(child: Slider(
                  value: HSVColor.fromColor(_hex(colorCtl.text)).hue,
                  min: 0, max: 360,
                  onChanged: (value) => update(() {
                    colorCtl.text = _colorCode(HSVColor.fromColor(_hex(colorCtl.text))
                      .withHue(value).toColor());
                  }),
                )),
              ]),
              Row(children: [
                const SizedBox(width: 49, child: Text('التشبع', style: TextStyle(fontSize: 11))),
                Expanded(child: Slider(
                  value: HSVColor.fromColor(_hex(colorCtl.text)).saturation,
                  min: 0, max: 1,
                  onChanged: (value) => update(() {
                    colorCtl.text = _colorCode(HSVColor.fromColor(_hex(colorCtl.text))
                      .withSaturation(value).toColor());
                  }),
                )),
              ]),
            ],
            if (type == 'book') ...[
              const SizedBox(height: 12),
              TextFormField(controller: urlCtl, maxLines: 3, minLines: 2,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(labelText: 'رابط PDF أو Google Drive', hintText: 'https://...'),
                validator: (v) => (v == null || v.trim().isEmpty || LibraryCatalog.validWebUrl(v))
                  ? null : 'اكتب رابط http أو https صحيحاً',
              ),
            ],
            const SizedBox(height: 8),
            SwitchListTile.adaptive(title: const Text('ظاهر للمستخدمين بعد النشر'),
              value: visible, onChanged: (v) => update(() => visible = v)),
          ],
        ))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            if (key.currentState?.validate() != true) return;
            Navigator.pop(ctx, {
              'title': titleCtl.text.trim(), 'description': descCtl.text.trim(),
              'url': urlCtl.text.trim(), 'color': colorCtl.text.trim(),
              'visible': visible, 'icon': icon,
            });
          }, child: const Text('حفظ')),
        ],
      )),
    );
    titleCtl.dispose(); descCtl.dispose(); urlCtl.dispose(); colorCtl.dispose();
    if (result == null || _doc == null) return;
    final next = _doc!.copy();
    final list = next.group(type);
    Map<String, dynamic> edited;
    if (original != null) {
      edited = list.firstWhere((e) => e['id'] == original['id']);
    } else {
      edited = {
        'id': LibraryCatalog.newId(type),
        'order': list.isEmpty ? 0 : list.map((e) => e['order'] as int).reduce((a, b) => a > b ? a : b) + 1,
        if (type == 'grade') 'stageId': _currentParent,
        if (type == 'subject') 'gradeId': _currentParent,
        if (type == 'book') 'subjectId': _currentParent,
      };
      list.add(edited);
    }
    if (type == 'book') {
      edited['title'] = result['title']; edited['url'] = result['url'];
    } else {
      edited['name'] = result['title'];
    }
    edited['visible'] = result['visible'];
    // Published catalog stores the custom color for all four item types.
    edited['color'] = result['color'];
    if (type == 'stage') edited['description'] = result['description'];
    if (type == 'stage' || type == 'grade') edited['icon'] = result['icon'];
    await _save(next);
  }

  Future<void> _delete(String type, Map<String, dynamic> item) async {
    final descendants = _doc!.descendants(type, item['id'].toString());
    final agreed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تأكيد الحذف'),
      content: Text('حذف «${LibraryCatalog.name(item)}» سيحذف معه $descendants عنصراً تابعاً له. يمكن التراجع قبل النشر بإعادة تحميل النسخة المنشورة.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف'))],
    ));
    if (agreed != true) return;
    final next = _doc!.copy();
    next.deleteTree(type, item['id'].toString());
    await _save(next);
  }

  Future<void> _toggle(String type, Map<String, dynamic> item) async {
    final next = _doc!.copy();
    final target = next.group(type).firstWhere((e) => e['id'] == item['id']);
    target['visible'] = !LibraryCatalog.visible(target);
    await _save(next);
  }

  Future<void> _reorder(String type, String itemId, int direction) async {
    if (_doc == null) return;
    final next = _doc!.copy();
    final list = type == 'stage' ? next.sorted(next.stages) :
      next.children(_path.last['type']!, _currentParent!);
    final pos = list.indexWhere((e) => e['id'] == itemId);
    final other = pos + direction;
    if (pos < 0 || other < 0 || other >= list.length) return;
    final a = list[pos], b = list[other];
    final oldA = a['order']; a['order'] = b['order']; b['order'] = oldA;
    await _save(next);
  }

  Widget _metric(String value, String label, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color), const SizedBox(height: 13),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 23, color: kInk)),
      Text(label, style: const TextStyle(color: Color(0xff76849b), fontSize: 12)),
    ]),
  );

  Widget _dashboard() {
    final doc = _doc!;
    final heroColor = doc.stages.isNotEmpty ? _hex(doc.stages.first['color']?.toString()) : kBlue;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 28), children: [
      Container(padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(colors: [
            Color.lerp(heroColor, const Color(0xFF152749), .12)!,
            Color.lerp(heroColor, const Color(0xFF348EC9), .28)!,
          ]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.admin_panel_settings_outlined, color: Colors.white, size: 34),
          const SizedBox(height: 12),
          const Text('إدارة مكتبتك من هاتفك', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          const Text('أضف مراحل وصفوفاً ومواد وكتباً، ثم انشرها للمستخدمين بنقرة واحدة.',
            style: TextStyle(color: Color(0xffe6ebff), height: 1.7)),
          const SizedBox(height: 17),
          FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: kBlue),
            onPressed: () => setState(() { _tab = 1; _path.clear(); }),
            icon: const Icon(Icons.add_circle_outline), label: const Text('إدارة المراحل')),
        ]),
      ),
      const SizedBox(height: 17),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35,
        children: [
          _metric('${doc.stages.length}', 'المراحل الدراسية', Icons.school_outlined, kBlue),
          _metric('${doc.grades.length}', 'الصفوف الدراسية', Icons.grid_view_outlined, const Color(0xff11a98e)),
          _metric('${doc.subjects.length}', 'المواد الدراسية', Icons.category_outlined, const Color(0xff8d62d5)),
          _metric('${doc.books.length}', 'الكتب المدرسية', Icons.menu_book_outlined, const Color(0xffe6a14c)),
        ],
      ),
      const SizedBox(height: 12),
      _notice(Icons.link_outlined, 'سلامة روابط الكتب',
        '${LinkAudit.run(doc).missing.length} رابطاً ناقصاً • ${LinkAudit.run(doc).duplicates.length} رابطاً مكرراً',
        const Color(0xffdc9546)),
      const SizedBox(height: 15),
      _notice(Icons.cloud_sync, 'حالة النشر', _status,
        _dirty ? const Color(0xfff3a32b) : const Color(0xff16977e)),
      const SizedBox(height: 12),
      _notice(Icons.verified_user_outlined, 'الحماية',
        'المستخدم يقرأ فقط، ولا يحتوي تطبيقه على أدوات الإدارة أو مفتاح الكتابة.', kBlue),
    ]);
  }

  Widget _notice(IconData icon, String title, String description, Color color) =>
    Container(padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(
          color: color.withValues(alpha: .09), borderRadius: BorderRadius.circular(13)),
          child: Icon(icon, color: color)),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(description, style: const TextStyle(color: Color(0xff728097), fontSize: 12)),
        ])),
      ]),
    );

  Widget _hierarchy() {
    final type = _currentType, list = _shown();
    return Column(children: [
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: Row(children: [
          if (_path.isNotEmpty) IconButton(onPressed: () => setState(() => _path.removeLast()),
            icon: const Icon(Icons.arrow_forward_ios, size: 19)),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_path.isEmpty ? 'المراحل الدراسية' : _path.last['name']!,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            Text('إدارة ${_label(type)} • ${list.length} عناصر',
              style: const TextStyle(color: Color(0xff71809c), fontSize: 12)),
          ])),
          FilledButton.icon(onPressed: () => _showEditor(type),
            icon: const Icon(Icons.add, size: 18), label: Text('إضافة ${_label(type)}')),
        ]),
      ),
      if (_path.isNotEmpty)
        SizedBox(height: 37, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            TextButton(onPressed: () => setState(() => _path.clear()), child: const Text('المراحل')),
            ..._path.asMap().entries.map((entry) => TextButton(
              onPressed: () => setState(() => _path.removeRange(entry.key + 1, _path.length)),
              child: Text('› ${entry.value['name']}'),
            )),
          ])),
      Expanded(child: list.isEmpty
        ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.inventory_2_outlined, color: Color(0xff9eacc4), size: 49),
            const SizedBox(height: 13),
            Text('لا يوجد ${_label(type)} هنا'),
            const SizedBox(height: 9),
            OutlinedButton.icon(onPressed: () => _showEditor(type), icon: const Icon(Icons.add),
              label: const Text('إضافة الآن')),
          ]))
        : ListView.builder(padding: const EdgeInsets.fromLTRB(13, 8, 13, 24),
            itemCount: list.length, itemBuilder: (ctx, i) {
              final item = list[i];
              final color = _hex(item['color']?.toString());
              final isBook = type == 'book';
              final childCount = isBook ? 0 : _doc!.children(type, item['id'].toString()).length;
              return Card(margin: const EdgeInsets.only(bottom: 9), shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
                child: InkWell(borderRadius: BorderRadius.circular(18),
                  onTap: isBook ? () => _showEditor(type, original: item) : () => _openPath(type, item),
                  child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                    Container(width: 47, height: 47, decoration: BoxDecoration(
                      color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)),
                      child: Icon(_typeIcon(type), color: color)),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(LibraryCatalog.name(item), style: TextStyle(fontWeight: FontWeight.w800,
                        decoration: LibraryCatalog.visible(item) ? null : TextDecoration.lineThrough)),
                      Text(isBook ? ((item['url'] ?? '').toString().isNotEmpty ? 'الرابط متوفر' : 'بدون رابط') :
                        '$childCount عناصر تابعة', style: const TextStyle(color: Color(0xff8591a7), fontSize: 11)),
                    ])),
                    PopupMenuButton<String>(tooltip: 'خيارات', onSelected: (value) {
                      switch (value) {
                        case 'edit': _showEditor(type, original: item); break;
                        case 'toggle': _toggle(type, item); break;
                        case 'delete': _delete(type, item); break;
                        case 'up': _reorder(type, item['id'] as String, -1); break;
                        case 'down': _reorder(type, item['id'] as String, 1); break;
                      }
                    }, itemBuilder: (_) => [
                      const PopupMenuItem(value:'edit', child: Text('تعديل')),
                      PopupMenuItem(value:'toggle', child: Text(LibraryCatalog.visible(item) ? 'إخفاء' : 'إظهار')),
                      const PopupMenuItem(value:'up', child: Text('تحريك للأعلى')),
                      const PopupMenuItem(value:'down', child: Text('تحريك للأسفل')),
                      const PopupMenuItem(value:'delete', child: Text('حذف', style: TextStyle(color: Colors.red))),
                    ]),
                    if (!isBook) const Icon(Icons.chevron_left, color: Color(0xffa0acc0)),
                  ])),
                ),
              );
            })),
    ]);
  }

  Widget _allBooks() {
    final books = _doc!.sorted(_doc!.books).where((b) {
      final q = _search.trim().toLowerCase();
      return q.isEmpty || LibraryCatalog.name(b).toLowerCase().contains(q) ||
        (b['url'] ?? '').toString().toLowerCase().contains(q);
    }).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 13, 16, 7), child: TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث باسم الكتاب أو الرابط'),
        onChanged: (v) => setState(() => _search = v),
      )),
      Expanded(child: ListView.builder(padding: const EdgeInsets.fromLTRB(14, 7, 14, 20),
        itemCount: books.length, itemBuilder: (ctx, i) {
          final book = books[i];
          return Card(child: ListTile(
            leading: const Icon(Icons.menu_book_outlined, color: kBlue),
            title: Text(LibraryCatalog.name(book)),
            subtitle: Text((book['url'] ?? '').toString(), maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: IconButton(icon: const Icon(Icons.edit_note), onPressed: () => _showEditor('book', original: book)),
            onTap: () => _showEditor('book', original: book),
          ));
        })),
      Padding(padding: const EdgeInsets.all(12), child: OutlinedButton.icon(
        onPressed: () => setState(() { _tab = 1; _path.clear(); }),
        icon: const Icon(Icons.add), label: const Text('لإضافة كتاب: اختر المرحلة ← الصف ← المادة'))),
    ]);
  }

  Map<String, int> _changes() {
    final a = _published, b = _doc;
    final counts = <String, int>{};
    if (a == null || b == null) return counts;
    for (final type in ['stage','grade','subject','book']) {
      final old = {for (final e in a.group(type)) e['id'].toString(): jsonEncode(e)};
      final next = {for (final e in b.group(type)) e['id'].toString(): jsonEncode(e)};
      final keys = {...old.keys, ...next.keys};
      counts[type] = keys.where((id) => old[id] != next[id]).length;
    }
    final oldReviews = {for (final q in a.reviews) q['id'].toString(): jsonEncode(q)};
    final newReviews = {for (final q in b.reviews) q['id'].toString(): jsonEncode(q)};
    counts['review'] = {...oldReviews.keys,...newReviews.keys}
      .where((id) => oldReviews[id] != newReviews[id]).length;
    return counts;
  }

  Future<void> _discardDraftAndLoadPublished() async {
    if (_busy) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('استبدال المسودة المحلية؟'),
      content: const Text('ستفقد كل التعديلات غير المنشورة في هذا الهاتف. لا يمكن التراجع بعد المتابعة.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة المنشور')),
      ],
    ));
    if (ok != true) return;
    try {
      final remote = await _publisher.fetch();
      final fresh = remote.catalog ?? await _repo.packaged();
      await _repo.markPublished(fresh);
      if (!mounted) return;
      setState(() {
        _doc = fresh.copy(); _published = fresh;
        _dirty = false;
        _status = 'تم استعادة الفهرس المنشور';
      });
      _toast('تم إلغاء المسودة المحلية واستعادة الفهرس المنشور');
    } catch (e) { _toast('$e'); }
  }

  Widget _publishPage() {
    final changes = _changes();
    return ListView(padding: const EdgeInsets.all(16), children: [
      _notice(Icons.cloud_upload_outlined, 'نشر التعديلات',
        'لا يرى المستخدمون مسودتك قبل الضغط على «نشر».', kBlue),
      const SizedBox(height: 15),
      ...['stage','grade','subject','book'].map((type) => Card(child: ListTile(
        leading: Icon(_typeIcon(type), color: kBlue),
        title: Text('تغييرات ${_label(type)}'),
        trailing: CircleAvatar(radius: 18, child: Text('${changes[type] ?? 0}')),
      ))),
      Card(child: ListTile(leading: const Icon(Icons.quiz_outlined,color: kBlue),
        title: const Text('أسئلة المراجعة'), trailing: Text('${_doc?.reviews.length ?? 0}'))),
      const SizedBox(height: 13),
      _notice(_dirty ? Icons.edit_outlined : Icons.check_circle_outline,
        _dirty ? 'توجد تعديلات غير منشورة' : 'النسخة الحالية', _status,
        _dirty ? const Color(0xffe7a346) : const Color(0xff139879)),
      const SizedBox(height: 17),
      FilledButton.icon(onPressed: _busy ? null : _publish,
        icon: const Icon(Icons.publish_outlined), label: const Text('نشر المراحل والصفوف والمواد والكتب'),
        style: FilledButton.styleFrom(padding: const EdgeInsets.all(17))),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _busy ? null : () => _refreshFromGitHub(),
        icon: const Icon(Icons.sync), label: const Text('فحص آخر نسخة منشورة على GitHub')),
      const SizedBox(height: 9),
      OutlinedButton.icon(onPressed: _busy || !_hasToken ? null : _discardDraftAndLoadPublished,
        icon: const Icon(Icons.restore), label: const Text('إلغاء مسودتي واستعادة النسخة المنشورة')),
      const SizedBox(height: 13),
      const Text('عند وجود تغييرات جديدة على GitHub، يدمج التطبيق التعديلات المختلفة تلقائياً، ويطلب موافقتك فقط عند تعديل المعلومة نفسها.\n'
        'التحديث لدى المستخدم يحتاج اتصالاً بالإنترنت ومستودعاً عاماً.',
        style: TextStyle(color: Color(0xff728097), height: 1.7)),
    ]);
  }

  Future<void> _saveTokenDialog() async {
    final controller = TextEditingController();
    final token = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تسجيل دخول المدير إلى GitHub'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('أنشئ Fine-grained token بصلاحية Contents: Read and write للمستودع فقط. يُحفظ الرمز مشفراً على هاتف المدير، ولا يدخل في APK.'),
        const SizedBox(height: 14),
        TextField(controller: controller, obscureText: true, autocorrect: false, enableSuggestions: false,
          decoration: const InputDecoration(labelText: 'GitHub personal access token')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('حفظ آمن'))],
    ));
    controller.dispose();
    if (token == null || token.isEmpty) return;
    try {
      await _publisher.saveToken(token);
      if (mounted) setState(() => _hasToken = true);
      _toast('تم حفظ الرمز في مساحة تخزين آمنة');
      await _refreshFromGitHub();
    } catch (e) { _toast('$e'); }
  }

  Widget _settings() => ListView(padding: const EdgeInsets.all(16), children: [
    _notice(Icons.security, 'إعداد GitHub الآمن',
      _hasToken ? 'رمز المدير محفوظ على الجهاز' : 'لم تدخل رمز المدير بعد',
      _hasToken ? const Color(0xff13a085) : const Color(0xffe5a14e)),
    const SizedBox(height: 13),
    Card(child: Column(children: [
      ListTile(title: const Text('المستودع'), subtitle: Text(LibraryEndpoint.configured ?
        '${LibraryEndpoint.owner}/${LibraryEndpoint.repo}' : 'غير محدد في GitHub Actions')),
      const Divider(height: 1),
      ListTile(title: const Text('الفرع والملف'), subtitle: Text('${LibraryEndpoint.branch} / ${LibraryEndpoint.path}')),
      const Divider(height: 1),
      ListTile(title: const Text('عنوان مزامنة المستخدمين'), subtitle: SelectableText(
        LibraryEndpoint.configured ? LibraryEndpoint.rawUrl : 'غير مهيأ')),
    ])),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: _saveTokenDialog,
      icon: const Icon(Icons.key_outlined), label: Text(_hasToken ? 'تغيير رمز GitHub' : 'ربط حساب المدير')),
    const SizedBox(height: 9),
    OutlinedButton.icon(onPressed: _hasToken ? () async {
      await _publisher.clearToken();
      if (mounted) setState(() { _hasToken = false; });
      _toast('تم حذف رمز GitHub من هذا الجهاز');
    } : null,
      icon: const Icon(Icons.logout), label: const Text('فصل صلاحية النشر')),
    const SizedBox(height: 9),
    OutlinedButton.icon(onPressed: () => launchUrl(
      Uri.parse('https://github.com/settings/personal-access-tokens/new'),
      mode: LaunchMode.externalApplication,
    ), icon: const Icon(Icons.open_in_new), label: const Text('إنشاء رمز صلاحية محدودة على GitHub')),
    const SizedBox(height: 17),
    _notice(Icons.info_outline, 'التحديث التلقائي',
      'عندما تنشر الفهرس، يتعرف تطبيق المستخدم على المراحل والصفوف والمواد والكتب الجديدة عند الاتصال ومزامنة البيانات.', kBlue),
  ]);

  // Administrator feature screens: all actions save drafts unless publish is explicitly used.
  void _openTool(String name) => setState(() { _tab = 4; _tool = name; });

  Widget _moreCard(String key, String name, String desc, IconData symbol, Color color) =>
    Material(color: Colors.white, borderRadius: BorderRadius.circular(22), child: InkWell(
      key: Key('more_$key'), onTap: () => _openTool(key), borderRadius: BorderRadius.circular(22),
      child: Container(padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(border: Border.all(color: color.withValues(alpha: .20)),
          borderRadius: BorderRadius.circular(22)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 46, height: 46,
            decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(15)),
            child: Icon(symbol, color: color, size: 25)),
          const Spacer(),
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: kInk)),
          const SizedBox(height: 4),
          Text(desc, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Color(0xff8390a7), fontSize: 10.5, height: 1.4)),
        ])),
    ));

  Widget _moreHome() => ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
    Container(padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(23),
        gradient: const LinearGradient(colors: [Color(0xff7452d8), Color(0xff446fe8)])),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.widgets_outlined, size: 30, color: Colors.white),
        SizedBox(height: 11),
        Text('مركز إدارة المكتبة', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        SizedBox(height: 5),
        Text('كل أدوات المدير في بطاقات واضحة ومنظمة، دون ازدحام الشريط السفلي.',
          style: TextStyle(color: Colors.white, height: 1.6, fontSize: 12)),
      ])),
    const SizedBox(height: 17),
    const Text('أدوات المكتبة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.06,
      children: [
        _moreCard('links','فحص الروابط','ناقص • مكرر • تحقق شبكي',Icons.link_off_outlined,const Color(0xffdc9341)),
        _moreCard('import','استيراد الكتب','CSV وملفات Excel',Icons.file_upload_outlined,const Color(0xff13a48b)),
        _moreCard('preview','معاينة المستخدم','راجع التعديلات قبل نشرها',Icons.phone_android_outlined,const Color(0xff5477ea)),
        _moreCard('history','الإصدارات السابقة','عرض واستعادة مسودة قديمة',Icons.history_rounded,const Color(0xffa05bd9)),
        _moreCard('reviews','أسئلة المراجعة','تحرير الأسئلة والإجابات',Icons.quiz_outlined,const Color(0xffe06c91)),
        _moreCard('bulk','إدارة جماعية','إخفاء أو نقل كتب متعددة',Icons.library_add_check_outlined,const Color(0xff16a5ad)),
        _moreCard('sync','مركز المزامنة','حالة الاتصال وإصدار الفهرس',Icons.cloud_sync_outlined,const Color(0xff6788da)),
        _moreCard('security','الحماية والحساب','الرمز وقفل العمليات الحساسة',Icons.shield_outlined,const Color(0xff7762c8)),
        _moreCard('settings','إعدادات GitHub','المستودع ورابط المزامنة',Icons.tune_rounded,const Color(0xff9a7382)),
        _moreCard('look','المراحل والألوان','ترتيب وألوان وأيقونات',Icons.palette_outlined,const Color(0xffd98a36)),
      ]),
  ]);

  Widget _toolHeader(String title, String subtitle, IconData icon, Color color) =>
      Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(children: [
        Container(padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(16)),
          child: Icon(icon, color: color)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xff8995aa))),
        ])),
      ]));

  Widget _moreScreen() {
    if (_tool.isEmpty) return _moreHome();
    if (_tool == 'settings') return _settings();
    if (_tool == 'look') return _colorsTool();
    return switch (_tool) {
      'links' => _linksTool(),
      'import' => _importTool(),
      'preview' => _previewTool(),
      'history' => _historyTool(),
      'reviews' => _reviewTool(),
      'bulk' => _bulkTool(),
      'sync' => _syncTool(),
      'security' => _securityTool(),
      _ => _moreHome(),
    };
  }

  Widget _linksTool() {
    final audit = LinkAudit.run(_doc!);
    final issues = [...audit.missing.map((v) => ('بدون رابط',v)),
      ...audit.invalid.map((v) => ('رابط غير صالح',v)),
      ...audit.duplicates.map((v) => ('رابط مكرر',v))];
    return ListView(padding: const EdgeInsets.all(16), children: [
      _toolHeader('فحص روابط الكتب','فحص المحتوى دون حذف أو تغيير', Icons.link_outlined,const Color(0xffdc9341)),
      Row(children: [
        Expanded(child: _metric('${audit.ready}', 'روابط متاحة', Icons.check_circle_outline, const Color(0xff119f87))),
        const SizedBox(width: 8),
        Expanded(child: _metric('${audit.missing.length}', 'ناقصة', Icons.link_off_outlined, const Color(0xffec8b51))),
      ]),
      const SizedBox(height: 10),
      _notice(Icons.copy_outlined, 'روابط مكررة', '${audit.duplicates.length} • قد تتكرر الكتب المشتركة بين الصفوف بشكل صحيح', kBlue),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: _busy ? null : _checkRemoteLinks,
        icon: const Icon(Icons.public), label: const Text('اختبر الاتصال بعينة من الروابط (بلا تنزيل)')),
      if (_linkCheckResult != null) Padding(padding: const EdgeInsets.all(10),
        child: Text(_linkCheckResult!, style: const TextStyle(fontSize: 12))),
      const SizedBox(height: 10),
      const Text('وجود خطأ 403 أو 405 في Google Drive لا يعني بالضرورة أن الكتاب غير صالح.',
        style: TextStyle(fontSize: 11, color: Color(0xff8290a8))),
      ...issues.take(70).map((pair) => Card(child: ListTile(
        leading: Icon(pair.$1 == 'بدون رابط' ? Icons.link_off : Icons.report_outlined, color: const Color(0xffd58a43)),
        title: Text(LibraryCatalog.name(pair.$2)), subtitle: Text(pair.$1),
        onTap: () { setState(() { _tab = 2; _search = LibraryCatalog.name(pair.$2); }); },
      ))),
    ]);
  }

  Future<void> _checkRemoteLinks() async {
    if (_busy) return;
    setState(() { _busy = true; _linkCheckResult = null; });
    var reachable = 0, uncertain = 0, failed = 0;
    final client = http.Client();
    try {
      final links = _doc!.books.map((b) => (b['url'] ?? '').toString()).where(LibraryCatalog.validWebUrl).toSet().take(20);
      for (final link in links) {
        try {
          final response = await client.send(http.Request('HEAD', Uri.parse(link)))
              .timeout(const Duration(seconds: 5));
          await response.stream.drain<void>();
          if (response.statusCode >= 200 && response.statusCode < 400) { reachable++; }
          else if ([401,403,405,429].contains(response.statusCode)) { uncertain++; }
          else { failed++; }
        } catch (_) { uncertain++; }
      }
      if (!mounted) return;
      setState(() => _linkCheckResult = 'من عينة 20 رابطاً كحد أقصى: $reachable استجابة ناجحة، $uncertain يحتاج فحصاً يدوياً، $failed استجابة غير ناجحة.');
    } finally {
      client.close();
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _importTool() => ListView(padding: const EdgeInsets.all(16), children: [
    _toolHeader('استيراد كتب كثيرة','CSV / XLSX • فحص قبل حفظ المسودة', Icons.file_upload_outlined,const Color(0xff159c87)),
    _notice(Icons.table_chart_outlined,'تنسيق الملف المطلوب',
      'أربعة أعمدة بالصف الأول: الصف، المادة، الكتاب، الرابط. يجب أن يكون الصف موجوداً، ويمكن إنشاء المادة تلقائياً.',kBlue),
    const SizedBox(height: 14),
    FilledButton.icon(onPressed: _busy ? null : _pickImport,
      icon: const Icon(Icons.folder_open_outlined), label: const Text('اختيار ملف CSV أو Excel')),
    if (_importPreview != null) ...[
      const SizedBox(height: 16),
      _notice(Icons.fact_check_outlined, 'نتيجة فحص الملف',
        '${_importPreview!.items.length} كتاب جاهز • ${_importPreview!.errors.length} مشكلة',const Color(0xff16a48d)),
      const SizedBox(height: 10),
      ..._importPreview!.errors.take(15).map((e) => ListTile(dense:true,
        leading: const Icon(Icons.error_outline, color: Colors.orange), title: Text(e))),
      ..._importPreview!.items.take(12).map((e) => ListTile(dense:true,
        leading: const Icon(Icons.auto_stories_outlined),
        title: Text(e['title'] ?? ''), subtitle: Text('${e['grade']} • ${e['subject']}'))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _importPreview!.items.isEmpty ? null : _applyImportedBooks,
        icon: const Icon(Icons.add_circle_outline), label: const Text('إضافة إلى المسودة (بدون نشر)')),
    ],
  ]);

  Future<void> _pickImport() async {
    try {
      // file_picker 13: pickFile returns a PlatformFile; no legacy
      // use the new API rather than the removed result/size/withData APIs.
      final file = await FilePicker.pickFile(
        type: FileType.custom,
        allowedExtensions: ['csv', 'xlsx'],
      );
      if (file == null) return;
      final size = file.lengthSync() ?? await file.length();
      if (!mounted) return;
      const maxImportBytes = 4 * 1024 * 1024;
      if (size != null && size > maxImportBytes) {
        _toast('حجم الملف أكبر من 4 ميغابايت');
        return;
      }
      final bytes = await file.readAsBytes();
      if (!mounted) return;
      if (bytes.length > maxImportBytes) {
        _toast('حجم الملف أكبر من 4 ميغابايت');
        return;
      }
      final rows = file.name.toLowerCase().endsWith('.xlsx')
          ? BulkBookImport.readXlsx(bytes)
          : BulkBookImport.readCsv(bytes);
      final preview = BulkBookImport.parse(rows);
      if (mounted) setState(() => _importPreview = preview);
    } catch (e) {
      _toast('تعذّر قراءة ملف الكتب: $e');
    }
  }

  Future<void> _applyImportedBooks() async {
    final preview = _importPreview;
    if (preview == null || _doc == null) return;
    try {
      final next = BulkBookImport.apply(_doc!, preview);
      final added = next.books.length - _doc!.books.length;
      await _save(next);
      _toast('أضيف $added كتاباً إلى المسودة. راجعها قبل النشر.');
      if (mounted) setState(() => _importPreview = null);
    } catch (e) { _toast('$e'); }
  }

  Widget _previewTool() {
    final doc = _doc!;
    final visibleStages = doc.sorted(doc.stages, onlyVisible:true);
    return ListView(padding: const EdgeInsets.all(16), children: [
      _toolHeader('معاينة المستخدم','بطاقات تمثل المحتوى المرئي بعد النشر',Icons.phone_android_outlined,kBlue),
      _notice(Icons.visibility_outlined,'هذه معاينة للمحتوى','لا تنشر التعديلات ولا تغيّر فهرس المستخدم؛ راجع ترتيب المراحل والألوان.',const Color(0xff189b87)),
      const SizedBox(height: 13),
      ...visibleStages.map((stage) {
        final color = _hex(stage['color']?.toString());
        final grades = doc.children('stage', stage['id'].toString()).where(LibraryCatalog.visible).toList();
        return Padding(padding: const EdgeInsets.only(bottom: 12), child: Card(child: ExpansionTile(
          leading: Container(width: 45, height: 45, decoration: BoxDecoration(
            color: color.withValues(alpha:.13), borderRadius: BorderRadius.circular(14)),
            child: Icon(Icons.school_outlined, color: color)),
          title: Text(LibraryCatalog.name(stage), style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text('${grades.length} صفوف'),
          children: grades.map((grade) => ListTile(
            leading: CircleAvatar(backgroundColor:_hex(grade['color']?.toString()).withValues(alpha:.13),
              child: Icon(Icons.menu_book_outlined, color:_hex(grade['color']?.toString()))),
            title: Text(LibraryCatalog.name(grade)),
            subtitle: Text('${doc.children('grade',grade['id'].toString()).length} مواد'),
          )).toList(),
        )));
      }),
      FilledButton.icon(onPressed: () => setState(() => _tab = 3),
        icon: const Icon(Icons.publish_outlined), label: const Text('الانتقال لمراجعة النشر')),
    ]);
  }

  Widget _historyTool() => ListView(padding: const EdgeInsets.all(16), children: [
    _toolHeader('سجل إصدارات المكتبة','استعادة إصدار قديم إلى المسودة فقط',Icons.history_rounded,const Color(0xff9c62d3)),
    _notice(Icons.info_outline,'حفظ آمن',
      'استعادة إصدار لا تنشره تلقائياً؛ يمكنك معاينته ومراجعته، ثم نشره يدوياً.',kBlue),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed:_busy ? null : _loadHistory,
      icon:const Icon(Icons.refresh),label:const Text('جلب آخر 15 إصداراً من GitHub')),
    const SizedBox(height: 10),
    ..._history.map((h) => Card(child: ListTile(
      leading: const Icon(Icons.restore_page_outlined,color: Color(0xff8c60d4)),
      title: Text(h['message'] ?? 'تحديث الفهرس',maxLines:2),
      subtitle: Text(h['date'] ?? ''),
      trailing: const Icon(Icons.chevron_left),
      onTap: _busy ? null : () => _restoreRevision(h['sha'] ?? ''),
    ))),
  ]);

  Future<void> _loadHistory() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final history = await _publisher.recentCatalogCommits();
      if (mounted) setState(() => _history = history);
    } catch (e) { _toast('تعذر قراءة سجل GitHub: $e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _restoreRevision(String sha) async {
    if (_dirty) {
      _toast('لديك مسودة غير منشورة. انشرها أو احفظها أولاً قبل استعادة نسخة أقدم.');
      return;
    }
    final agree = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('استعادة نسخة قديمة؟'),
      content: const Text('سيُنسخ هذا الإصدار إلى مسودة محلية جديدة فقط. لن يتغير GitHub إلا بعد النشر.'),
      actions: [TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true), child:const Text('استعادة إلى المسودة'))],
    ));
    if (agree != true) return;
    try {
      final old = await _publisher.fetchCatalogRevision(sha);
      await _save(old);
      if (mounted) setState(() => _tool = 'preview');
    } catch (e) { _toast('تعذرت الاستعادة: $e'); }
  }

  Widget _reviewTool() {
    final reviews = _doc!.reviews;
    return ListView(padding: const EdgeInsets.all(16), children: [
      _toolHeader('أسئلة المراجعة','أسئلة اختيار من متعدد لكل مادة',Icons.quiz_outlined,const Color(0xffdf688b)),
      _notice(Icons.library_books_outlined,'بنك المراجعات المنشور',
        '${reviews.length} سؤال مخصص. يبقى بنك التدريب العام داخل تطبيق المستخدم متاحاً للمواد الأخرى.',kBlue),
      const SizedBox(height: 13),
      FilledButton.icon(onPressed: () => _editQuestion(), icon:const Icon(Icons.add),label:const Text('إضافة سؤال جديد')),
      const SizedBox(height: 12),
      ...reviews.map((q) => Card(child: ListTile(
        leading:const Icon(Icons.help_outline,color:Color(0xffdf688b)),
        title: Text((q['text'] ?? '').toString(),maxLines:2),
        subtitle: Text('الإجابة: ${(q['choices'] as List)[q['answer'] as int]}'),
        onTap:()=>_editQuestion(original:q),
        trailing: IconButton(icon:const Icon(Icons.delete_outline),
          onPressed:() => _removeQuestion(q)),
      ))),
    ]);
  }

  Future<void> _editQuestion({Map<String,dynamic>? original}) async {
    final question = TextEditingController(text:(original?['text'] ?? '').toString());
    final choices = List.generate(4,(i) => TextEditingController(text: original == null ? '' :
      ((original['choices'] as List).length > i ? original['choices'][i] : '').toString()));
    final subjects = _doc!.subjects;
    String? selected = original?['subjectId']?.toString();
    var answer = original?['answer'] is int ? original!['answer'] as int : 0;
    String difficulty = (original?['difficulty'] ?? 'متوسط').toString();
    final result = await showDialog<Map<String,dynamic>>(context:context,
      builder: (ctx) => StatefulBuilder(builder:(ctx,update) => AlertDialog(
        title: Text(original==null?'إضافة سؤال':'تعديل السؤال'),
        content: SingleChildScrollView(child:Column(mainAxisSize: MainAxisSize.min,children:[
          DropdownButtonFormField<String>(initialValue:selected,isExpanded:true,
            decoration:const InputDecoration(labelText:'المادة الدراسية'),
            items: subjects.map((s) {
              final grade = _doc!.grades.where((g)=>g['id']==s['gradeId']).firstOrNull;
              return DropdownMenuItem(value:s['id'].toString(),child:Text(
                '${LibraryCatalog.name(grade ?? {})} • ${LibraryCatalog.name(s)}',overflow:TextOverflow.ellipsis));
            }).toList(),onChanged:(v)=>update(()=>selected=v)),
          const SizedBox(height:9),
          TextField(controller:question,maxLines:3,decoration:const InputDecoration(labelText:'نص السؤال')),
          const SizedBox(height:9),
          for(var i=0;i<4;i++) Padding(padding:const EdgeInsets.only(bottom:7),child:
            TextField(controller:choices[i],decoration:InputDecoration(labelText:'الخيار ${i+1}'))),
          const Text('الإجابة الصحيحة'),
          DropdownButton<int>(value:answer,isExpanded:true,
            items:List.generate(4,(i)=>DropdownMenuItem(value:i,child:Text('الخيار ${i+1}'))),
            onChanged:(v)=>update(()=>answer=v??0)),
          DropdownButton<String>(value:difficulty,isExpanded:true,
            items:['سهل','متوسط','صعب'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v)=>update(()=>difficulty=v??'متوسط')),
        ])),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),
          FilledButton(onPressed:(){
            if(selected==null || question.text.trim().isEmpty || choices.any((e)=>e.text.trim().isEmpty)){
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أكمل المادة والسؤال والخيارات')));
              return;
            }
            Navigator.pop(ctx,{
              'id':original?['id'] ?? LibraryCatalog.newId('review'),
              'subjectId':selected,'text':question.text.trim(),
              'choices':choices.map((c)=>c.text.trim()).toList(),
              'answer':answer,'difficulty':difficulty,
            });
          },child:const Text('حفظ'))],
      )));
    question.dispose(); for(final c in choices){c.dispose();}
    if(result==null)return;
    final next=_doc!.copy();
    next.reviews.removeWhere((q)=>q['id']==result['id']);
    next.reviews.add(result);
    await _save(next);
  }

  Future<void> _removeQuestion(Map<String,dynamic> question) async {
    final next=_doc!.copy()..reviews.removeWhere((q)=>q['id']==question['id']);
    await _save(next);
  }

  Widget _bulkTool() {
    final books=_doc!.sorted(_doc!.books);
    return Column(children:[
      Padding(padding:const EdgeInsets.all(14),child:Column(children:[
        _toolHeader('العمليات الجماعية','اختر كتباً ثم طبّق عملية واحدة عليها',Icons.library_add_check_outlined,const Color(0xff169ba3)),
        _notice(Icons.select_all,'التحديد','${_selectedBooks.length} من ${books.length} كتاباً',kBlue),
        const SizedBox(height:8),
        Row(children:[
          Expanded(child:OutlinedButton(onPressed:()=>setState(()=>_selectedBooks.addAll(books.map((e)=>e['id'].toString()))),
            child:const Text('تحديد الكل'))),const SizedBox(width:8),
          Expanded(child:OutlinedButton(onPressed:()=>setState(()=>_selectedBooks.clear()),child:const Text('إلغاء التحديد'))),
        ]),
        const SizedBox(height:8),
        Wrap(spacing:8,runSpacing:7,children:[
          FilledButton.icon(onPressed:_selectedBooks.isEmpty?null:()=>_bulkVisibility(false),
            icon:const Icon(Icons.visibility_off_outlined),label:const Text('إخفاء')),
          OutlinedButton.icon(onPressed:_selectedBooks.isEmpty?null:()=>_bulkVisibility(true),
            icon:const Icon(Icons.visibility_outlined),label:const Text('إظهار')),
          OutlinedButton.icon(onPressed:_selectedBooks.isEmpty?null:_bulkMove,
            icon:const Icon(Icons.drive_file_move_outline),label:const Text('نقل')),
          OutlinedButton.icon(onPressed:_selectedBooks.isEmpty?null:_bulkDelete,
            icon:const Icon(Icons.delete_outline),label:const Text('حذف')),
        ]),
      ])),
      Expanded(child:ListView.builder(itemCount:books.length,itemBuilder:(ctx,i){
        final book=books[i],id=book['id'].toString();
        return CheckboxListTile(value:_selectedBooks.contains(id),
          title:Text(LibraryCatalog.name(book),maxLines:2),
          subtitle:Text(LibraryCatalog.visible(book)?'ظاهر للمستخدم':'مخفي'),
          secondary:const Icon(Icons.menu_book_outlined),
          onChanged:(checked)=>setState((){
            if(checked==true){_selectedBooks.add(id);}else{_selectedBooks.remove(id);}
          }));
      })),
    ]);
  }

  Future<void> _bulkVisibility(bool visible) async {
    final next=_doc!.copy();
    for (final b in next.books) { if (_selectedBooks.contains(b['id'])) b['visible']=visible; }
    await _save(next);
    if(mounted)setState(()=>_selectedBooks.clear());
  }

  Future<void> _bulkDelete() async {
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('حذف الكتب المحددة؟'),
      content:Text('سيحذف ${_selectedBooks.length} كتاباً من المسودة. بعد النشر سيختفي من قائمة المستخدم.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('تأكيد الحذف'))]));
    if(ok!=true)return;
    final next=_doc!.copy()..books.removeWhere((b)=>_selectedBooks.contains(b['id']));
    await _save(next);
    if(mounted)setState(()=>_selectedBooks.clear());
  }

  Future<void> _bulkMove() async {
    final subjects=_doc!.subjects;
    final selected=await showDialog<String>(context:context,builder:(ctx)=>SimpleDialog(
      title:const Text('انقل الكتب إلى مادة'),
      children:subjects.map((s)=>SimpleDialogOption(
        onPressed:()=>Navigator.pop(ctx,s['id'].toString()),
        child:Text(LibraryCatalog.name(s)))).toList(),
    ));
    if(selected==null)return;
    final next=_doc!.copy();
    for(final b in next.books){if(_selectedBooks.contains(b['id'])) b['subjectId']=selected;}
    await _save(next);
    if(mounted)setState(()=>_selectedBooks.clear());
  }

  Widget _syncTool() {
    final changes=_changes();
    return ListView(padding:const EdgeInsets.all(16),children:[
      _toolHeader('مركز النشر والمزامنة','تحقق من وصول الفهرس للمستخدمين',Icons.cloud_sync_outlined,kBlue),
      _notice(Icons.cloud_done_outlined, 'حالة المسودة',_status,
        _dirty?const Color(0xffdc9546):const Color(0xff18a383)),
      const SizedBox(height:11),
      _notice(Icons.numbers_outlined,'إصدار الفهرس',
        '${_published?.revision ?? 0} منشور • ${_doc?.revision ?? 0} محلي • ${changes.values.fold<int>(0,(a,b)=>a+b)} تعديل',kBlue),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:_busy?null:()=>_refreshFromGitHub(),
        icon:const Icon(Icons.sync),label:const Text('فحص ملف GitHub باستخدام حساب المدير')),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:_busy?null:_checkPublicEndpoint,
        icon:const Icon(Icons.public),label:const Text('اختبار رابط المستخدم العام')),
      if(_publicStatus!=null)Padding(padding:const EdgeInsets.all(12),child:Text(_publicStatus!)),
      const SizedBox(height:13),
      SelectableText(LibraryEndpoint.configured?LibraryEndpoint.rawUrl:'عنوان المزامنة غير مهيأ',
        style:const TextStyle(fontSize:11,color:Color(0xff8290ab))),
    ]);
  }

  Future<void> _checkPublicEndpoint() async {
    if (!LibraryEndpoint.configured) { _toast('عنوان المستودع غير مهيأ'); return; }
    try {
      final public = await _repo.refreshPublic();
      if (!mounted) return;
      setState(() => _publicStatus = public == null ? 'لم يتم الاتصال بالرابط' :
        'الرابط متاح دون تسجيل دخول • الإصدار ${public.revision} • ${public.books.length} كتاباً • ${public.stages.length} مراحل');
    } catch (e) { if(mounted)setState(()=>_publicStatus='فشل الاتصال العام: $e'); }
  }

  Widget _securityTool() => ListView(padding:const EdgeInsets.all(16),children:[
    _toolHeader('حماية تطبيق المدير','صلاحيات GitHub وحماية عملية النشر',Icons.shield_outlined,const Color(0xff8364c6)),
    _notice(Icons.lock_outline,'مفتاح النشر',
      _hasToken?'محفوظ في التخزين الآمن على هذا الجهاز':'غير مربوط؛ لا يمكن نشر أي تعديل',
      _hasToken?const Color(0xff119d86):const Color(0xffd78e42)),
    const SizedBox(height:11),
    Card(child:SwitchListTile.adaptive(
      value:_requireAuth, onChanged:_setAuthRequirement,
      secondary:const Icon(Icons.fingerprint,color:Color(0xff805cd2)),
      title:const Text('تأكيد هوية الهاتف قبل النشر'),
      subtitle:const Text('بصمة أو رمز قفل الجهاز عند دعم النظام'),
    )),
    const SizedBox(height:13),
    OutlinedButton.icon(onPressed:_saveTokenDialog,icon:const Icon(Icons.key_outlined),
      label:Text(_hasToken?'تغيير رمز GitHub':'ربط حساب GitHub')),
    const SizedBox(height:10),
    const Text('لا يتم تخزين رمز الكتابة في تطبيق المستخدم أو في ملف البيانات المنشور. تأكد من تقييد صلاحيات الرمز لمستودع المكتبة فقط.',
      style:TextStyle(fontSize:12,height:1.7,color:Color(0xff7f8da5))),
  ]);

  Future<void> _setAuthRequirement(bool enabled) async {
    if (enabled) {
      try {
        if (!await _localAuth.isDeviceSupported()) {
          _toast('الجهاز لا يدعم تأكيد الهوية المحلي');return;
        }
        if (!await _localAuth.authenticate(localizedReason:'تفعيل حماية نشر المكتبة العراقية')) return;
      } catch(e){_toast('تعذر استخدام قفل الهاتف: $e');return;}
    }
    await _managerPrefs.setBool(_managerLockKey,enabled);
    if(mounted)setState(()=>_requireAuth=enabled);
  }

  Future<bool> _approvePublish() async {
    if (!_requireAuth) return true;
    try {
      return await _localAuth.authenticate(localizedReason:'تأكيد النشر إلى المكتبة العراقية');
    } catch (e) {_toast('تعذّر التحقق من هوية الجهاز: $e');return false;}
  }

  Widget _colorsTool() => ListView(padding:const EdgeInsets.all(16),children:[
    _toolHeader('ألوان وأيقونات المكتبة','خصص ألوان المرحلة والصف والمادة والكتاب',Icons.palette_outlined,const Color(0xffd58942)),
    _notice(Icons.tips_and_updates_outlined,'إدارة الألوان','من بطاقة أي مرحلة أو صف أو مادة أو كتاب، افتح تعديل ثم اختر بطاقة لون صغيرة أو اكتب رمز HEX.',kBlue),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:()=>setState((){_tab=1;_tool='';_path.clear();}),
      icon:const Icon(Icons.account_tree_outlined),label:const Text('الذهاب إلى إدارة المراحل')),
  ]);

  @override
  Widget build(BuildContext context) {
    final doc = _doc;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(
          color: kBlue, borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.local_library, color: Colors.white, size: 19)),
        const SizedBox(width: 10),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('مدير المكتبة العراقية', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          Text('لوحة التحكم الخاصة بك', style: TextStyle(fontSize: 10, color: Color(0xff8995ad))),
        ])),
      ]), actions: [
        if (_busy) const Padding(padding: EdgeInsets.all(14), child: SizedBox(
          height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))),
        if (_tab == 4 && _tool.isNotEmpty) IconButton(tooltip: 'العودة إلى المزيد',
          icon: const Icon(Icons.arrow_back_rounded), onPressed: () => setState(() => _tool = '')),
        IconButton(tooltip: 'نشر', icon: Badge(isLabelVisible: _dirty,
          child: const Icon(Icons.cloud_upload_outlined)), onPressed: () => setState(() => _tab = 3)),
      ]),
      body: doc == null ? const Center(child: CircularProgressIndicator()) :
        IndexedStack(index: _tab, children: [
          _dashboard(), _hierarchy(), _allBooks(), _publishPage(), _moreScreen(),
        ]),
      bottomNavigationBar: NavigationBar(height: 74, selectedIndex: _tab,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xfff0ecff),
        onDestinationSelected: (v) => setState(() {
          _tab = v;
          if (v == 1) _path.clear();
          if (v == 4) _tool = '';
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined,color:Color(0xff4b74ee)),
            selectedIcon: Icon(Icons.dashboard,color:Color(0xff4b74ee)), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.account_tree_outlined,color:Color(0xff925ad0)),
            selectedIcon: Icon(Icons.account_tree,color:Color(0xff925ad0)), label: 'المراحل'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined,color:Color(0xff18a98e)),
            selectedIcon: Icon(Icons.menu_book,color:Color(0xff18a98e)), label: 'الكتب'),
          NavigationDestination(icon: Icon(Icons.cloud_upload_outlined,color:Color(0xffe39a3b)),
            selectedIcon: Icon(Icons.cloud_upload,color:Color(0xffe39a3b)), label: 'النشر'),
          NavigationDestination(icon: Icon(Icons.widgets_outlined,color:Color(0xffd86e94)),
            selectedIcon: Icon(Icons.widgets,color:Color(0xffd86e94)), label: 'المزيد'),
        ]),
    );
  }
}
