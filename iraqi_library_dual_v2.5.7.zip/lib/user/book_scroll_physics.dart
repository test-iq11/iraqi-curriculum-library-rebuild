import 'package:flutter/material.dart';

/// Book scrolling profiles intentionally keep finger motion close to 1:1.
/// Aggressive velocity amplification made the reader difficult to stop.
class BookScrollProfile {
  const BookScrollProfile({
    required this.label,
    required this.physics,
    required this.friction,
  });

  final String label;
  final ControlledBookScrollPhysics physics;
  final double friction;

  static const List<BookScrollProfile> modes = <BookScrollProfile>[
    BookScrollProfile(
      label: 'مريح',
      physics: ControlledBookScrollPhysics(),
      friction: 0.0000135,
    ),
    BookScrollProfile(
      label: 'متوازن',
      physics: ControlledBookScrollPhysics(dragMultiplier: 1.10, flingMultiplier: 1.04),
      friction: 0.0000125,
    ),
    BookScrollProfile(
      label: 'سريع',
      physics: ControlledBookScrollPhysics(dragMultiplier: 1.25, flingMultiplier: 1.10),
      friction: 0.0000115,
    ),
  ];

  static int validMode(int? value) =>
      value != null && value >= 0 && value < modes.length ? value : 0;
}

/// Keeps page panning predictable while allowing modest optional acceleration.
class ControlledBookScrollPhysics extends ClampingScrollPhysics {
  const ControlledBookScrollPhysics({
    super.parent,
    this.dragMultiplier = 1.0,
    this.flingMultiplier = 1.0,
  });

  final double dragMultiplier;
  final double flingMultiplier;

  @override
  ControlledBookScrollPhysics applyTo(ScrollPhysics? ancestor) =>
      ControlledBookScrollPhysics(
        parent: buildParent(ancestor),
        dragMultiplier: dragMultiplier,
        flingMultiplier: flingMultiplier,
      );

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) =>
      super.applyPhysicsToUserOffset(position, offset) * dragMultiplier;

  @override
  Simulation? createBallisticSimulation(ScrollMetrics position, double velocity) =>
      super.createBallisticSimulation(position, velocity * flingMultiplier);
}
