import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/library_catalog.dart';

/// Actual network bytes received while downloading a book. Total size can be
/// unknown when the server uses chunked transfer encoding.
class BookDownloadProgress {
  const BookDownloadProgress({
    required this.receivedBytes,
    this.totalBytes,
  });

  final int receivedBytes;
  final int? totalBytes;

  /// Null means the HTTP response did not provide a usable Content-Length.
  double? get fraction {
    final total = totalBytes;
    if (total == null || total <= 0) return null;
    return (receivedBytes / total).clamp(0.0, 1.0).toDouble();
  }

  int? get percentage {
    final value = fraction;
    return value == null ? null : (value * 100).floor();
  }

  static String formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

class DownloadedBooks {
  static const _key = 'downloads_v2';
  final SharedPreferencesAsync prefs = SharedPreferencesAsync();
  // Multiple books can finish simultaneously; serialize metadata writes so
  // one completed download does not erase another from the saved-books list.
  Future<void> _writeTail = Future<void>.value();

  Future<void> _writeSafely(Future<void> Function() update) {
    final current = _writeTail.then((_) => update());
    _writeTail = current.then<void>((_) {},
      onError: (Object error, StackTrace stackTrace) {});
    return current;
  }

  Future<Map<String, dynamic>> entries() async {
    try {
      final raw = await prefs.getString(_key);
      return raw == null ? {} : Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) { return {}; }
  }

  Future<String?> localFile(String bookId) async {
    final e = (await entries())[bookId];
    if (e is! Map || e['path'] is! String) return null;
    final path = e['path'] as String;
    return File(path).existsSync() ? path : null;
  }

  static Uri directPdfUri(String originalUrl) {
    final uri = Uri.parse(originalUrl);
    final drive = RegExp(r'/file/d/([a-zA-Z0-9_-]+)').firstMatch(uri.path);
    if (uri.host == 'drive.google.com' && drive != null) {
      return Uri.https('drive.google.com', '/uc', {
        'export': 'download', 'id': drive.group(1)!,
      });
    }
    return uri;
  }

  Future<String> download(
    Map<String, dynamic> book, {
    void Function(BookDownloadProgress progress)? onProgress,
  }) async {
    final id = (book['id'] ?? '').toString();
    final url = (book['url'] ?? '').toString();
    if (!LibraryCatalog.validWebUrl(url)) throw StateError('رابط الكتاب غير صالح');
    final dir = Directory('${(await getApplicationDocumentsDirectory()).path}/downloaded_books');
    await dir.create(recursive: true);
    final safeId = id.replaceAll(RegExp('[^a-zA-Z0-9_-]'), '_');
    final dest = File('${dir.path}/$safeId.pdf');
    final temp = File('${dest.path}.part');
    final client = http.Client();
    try {
      final request = http.Request('GET', directPdfUri(url));
      final response = await client.send(request).timeout(const Duration(seconds: 35));
      if (response.statusCode != 200 && response.statusCode != 206) {
        throw StateError('تعذر التحميل: HTTP ${response.statusCode}');
      }
      if (response.contentLength != null && response.contentLength! > 250 * 1024 * 1024) {
        throw StateError('حجم الكتاب أكبر من 250 ميغابايت');
      }
      final expectedLength = response.contentLength;
      final knownLength = expectedLength != null && expectedLength > 0
          ? expectedLength : null;
      onProgress?.call(BookDownloadProgress(
        receivedBytes: 0, totalBytes: knownLength,
      ));
      final sink = temp.openWrite();
      var total = 0;
      try {
        await for (final chunk in response.stream.timeout(const Duration(seconds: 50))) {
          total += chunk.length;
          if (total > 250 * 1024 * 1024) {
            throw StateError('تم تجاوز حد التحميل 250 ميغابايت');
          }
          sink.add(chunk);
          onProgress?.call(BookDownloadProgress(
            receivedBytes: total, totalBytes: knownLength,
          ));
        }
      } finally {
        await sink.close();
      }
      final file = await temp.open();
      final signature = await file.read(5);
      await file.close();
      if (signature.length < 5 || utf8.decode(signature, allowMalformed: true) != '%PDF-') {
        throw StateError('الرابط لا يعيد ملف PDF مباشرة. افتح الكتاب في المتصفح بدلاً من ذلك.');
      }
      if (await dest.exists()) await dest.delete();
      await temp.rename(dest.path);
      await _writeSafely(() async {
        final saved = await entries();
        saved[id] = {'title': book['title'], 'path': dest.path, 'sourceUrl': url};
        await prefs.setString(_key, jsonEncode(saved));
      });
      return dest.path;
    } finally {
      client.close();
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<void> remove(String bookId) => _writeSafely(() async {
    final map = await entries();
    final entry = map.remove(bookId);
    if (entry is Map && entry['path'] is String) {
      final file = File(entry['path'] as String);
      if (await file.exists()) await file.delete();
    }
    await prefs.setString(_key, jsonEncode(map));
  });
}
