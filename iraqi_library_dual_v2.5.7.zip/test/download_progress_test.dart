import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/downloaded_books.dart';

void main() {
  test('progress is calculated using actual downloaded bytes', () {
    const p = BookDownloadProgress(receivedBytes: 512, totalBytes: 1024);
    expect(p.percentage, 50);
    expect(p.fraction, 0.5);
    expect(BookDownloadProgress.formatBytes(512), '512 B');
    expect(BookDownloadProgress.formatBytes(1536), '1.5 KB');
    expect(BookDownloadProgress.formatBytes(2 * 1024 * 1024), '2.0 MB');
  });

  test('unknown server content length produces indeterminate progress', () {
    const p = BookDownloadProgress(receivedBytes: 1000);
    expect(p.fraction, isNull);
    expect(p.percentage, isNull);
  });

  test('zero length and inconsistent lengths stay safe', () {
    const zero = BookDownloadProgress(receivedBytes: 300, totalBytes: 0);
    const over = BookDownloadProgress(receivedBytes: 200, totalBytes: 100);
    expect(zero.percentage, isNull);
    expect(over.fraction, 1.0);
    expect(over.percentage, 100);
  });
}
