import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/book_scroll_physics.dart';

void main() {
  test('comfortable scrolling is one-to-one by default', () {
    final mode = BookScrollProfile.modes.first;
    expect(mode.label, 'مريح');
    expect(mode.physics.dragMultiplier, 1.0);
    expect(mode.physics.flingMultiplier, 1.0);
    expect(mode.friction, 0.0000135);
  });

  test('scroll speed modes grow gradually without uncontrollable fling', () {
    final modes = BookScrollProfile.modes;
    expect(modes, hasLength(3));
    expect(modes[1].physics.dragMultiplier, greaterThan(1.0));
    expect(modes[2].physics.dragMultiplier, greaterThan(modes[1].physics.dragMultiplier));
    expect(modes[2].physics.dragMultiplier, lessThanOrEqualTo(1.25));
    expect(modes[2].physics.flingMultiplier, lessThanOrEqualTo(1.10));
    expect(modes[2].friction, greaterThan(0.00001));
  });

  test('invalid saved mode uses comfortable scrolling', () {
    expect(BookScrollProfile.validMode(null), 0);
    expect(BookScrollProfile.validMode(-1), 0);
    expect(BookScrollProfile.validMode(100), 0);
    expect(BookScrollProfile.validMode(2), 2);
  });
}
