#!/usr/bin/env python3
"""Source preflight for download UI; Flutter tests cover actual Dart behavior."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
client = (root / 'lib/user/downloaded_books.dart').read_text(encoding='utf8')
ui = (root / 'lib/user/user_library_app.dart').read_text(encoding='utf8')
checks = [
    ('Progress DTO', 'class BookDownloadProgress' in client),
    ('progress from actual bytes', 'receivedBytes: total' in client),
    ('unknown length handling', 'knownLength = expectedLength != null && expectedLength > 0' in client),
    ('progress callback', 'onProgress?.call(BookDownloadProgress(' in client),
    ('UI panel', 'Widget _downloadProgressPanel()' in ui),
    ('UI percentage', 'entry.value.percentage' in ui),
    ('UI bytes', 'BookDownloadProgress.formatBytes(entry.value.receivedBytes)' in ui),
    ('progress bar', 'LinearProgressIndicator(' in ui),
    ('double tap guard', 'if (_activeDownloads.containsKey(id))' in ui),
    ('rate-limited progress updates', 'inMilliseconds < 100' in ui),
    ('existing book reader preserved', 'BookPdfScreen(' in ui),
    ('flutter unit tests', (root / 'test/download_progress_test.dart').exists()),
]
for name, passed in checks:
    assert passed, f'Download progress regression: {name}'
print(f'PASS: {len(checks)} download progress preflight checks')
