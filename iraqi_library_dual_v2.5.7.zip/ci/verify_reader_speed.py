#!/usr/bin/env python3
"""Prevent runaway scroll physics while preserving PDF controls and fast page previews."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
reader = (root / 'lib/user/book_pdf_screen.dart').read_text(encoding='utf-8')
physics = (root / 'lib/user/book_scroll_physics.dart').read_text(encoding='utf-8')
controls = (root / 'lib/user/pdf_reader_controls.dart').read_text(encoding='utf-8')
for token in (
    "_scrollModeKey = 'pdf-reader-scroll-mode-v257'",
    'BookScrollProfile.validMode(prefs.getInt(_scrollModeKey))',
    'await prefs.setInt(_scrollModeKey, chosen)',
    'scrollPhysics: scrollProfile.physics',
    'interactionEndFrictionCoefficient: scrollProfile.friction',
    "Text('سرعة تصفح الكتاب'",
    "label: 'مريح'", "label: 'متوازن'", "label: 'سريع'",
    'flingMultiplier: 1.10', 'dragMultiplier: 1.25',
    'static int validMode(int? value)',
    'createBallisticSimulation(', 'applyPhysicsToUserOffset(',
):
    assert token in (physics + reader), f'PDF speed regression: {token}'
for token in (
    'verticalCacheExtent: 1.0',
    'enableLowResolutionPagePreview: true',
    'loadPageDimensionsOnDemand: true',
    'PdfViewerScrollThumb(',
    'orientation: ScrollbarOrientation.left',
    'PdfViewer.file(', 'PdfViewer.uri(',
    '_showBookSearch', '_showThumbnails', '_showContents',
    '_showQuickAccess', '_toggleBookmark', '_addNote', '_saveProgressTimer',
):
    assert token in reader, f'PDF navigation/caching regression: {token}'
for token in (
    'extends StatefulWidget', 'int? _previewPage', 'onChangeEnd:',
    'widget.onGoToPage(page)', 'widget.onPreviewPage(page)',
    'static const double toolbarHeight = 56',
):
    assert token in controls, f'PDF toolbar regression: {token}'
assert '_FastBookScrollPhysics' not in reader
assert 'interactionEndFrictionCoefficient: 0.00000125' not in reader
assert 'dragMultiplier: 2.2' not in physics
assert 'flingMultiplier: 1.8' not in physics
print('PASS: selectable controlled scroll speed, persistent preference, PDF navigation preserved')
