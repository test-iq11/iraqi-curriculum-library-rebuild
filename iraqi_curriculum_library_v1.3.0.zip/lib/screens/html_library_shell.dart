part of '../main.dart';

/// Displays the exact CSS/HTML/JS project design inside Android. The native
/// bridge is exclusively for the original PDF downloads, reader, and reviews.
class ExactHtmlLibraryApp extends StatelessWidget {
  const ExactHtmlLibraryApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'المناهج الدراسية العراقية',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF496AF2)),
          scaffoldBackgroundColor: const Color(0xFFF6F8FF),
        ),
        builder: (context, child) => Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        home: const _ExactLibraryHome(),
      );
}

class _ExactLibraryHome extends StatefulWidget {
  const _ExactLibraryHome();

  @override
  State<_ExactLibraryHome> createState() => _ExactLibraryHomeState();
}

class _ExactLibraryHomeState extends State<_ExactLibraryHome> {
  late final WebViewController _web;
  late final Future<List<SchoolBook>> _catalog;
  bool _loading = true;
  String? _loadError;
  bool _openingBook = false;

  @override
  void initState() {
    super.initState();
    _catalog = _readCatalog();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFF6F8FF))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (url) {
          if (mounted) setState(() { _loading = false; _loadError = null; });
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() { _loading = false; _loadError = error.description; });
          }
        },
        onNavigationRequest: (request) {
          if (request.url.startsWith('file:///android_asset/') ||
              request.url.startsWith('about:blank')) {
            return NavigationDecision.navigate;
          }
          final uri = Uri.tryParse(request.url);
          if (uri != null && (uri.scheme == 'https' || uri.scheme == 'http')) {
            launchUrl(uri, mode: LaunchMode.externalApplication);
          }
          return NavigationDecision.prevent;
        },
      ))
      ..addJavaScriptChannel('NativeLibrary', onMessageReceived: (message) {
        try {
          final data = jsonDecode(message.message);
          if (data is! Map) return;
          switch (data['action']) {
            case 'openBook':
              final id = data['id'];
              if (id is int) _openBookByIndex(id);
            case 'downloads':
              _openDownloads();
            case 'reviews':
              _openReviews();
            case 'exportJson':
              final value = data['data'];
              if (value is String && value.length <= 2000000) {
                _copyBackupToClipboard(value);
              }
            case 'importClipboard':
              _pasteBackupFromClipboard();
            case 'exit':
              SystemNavigator.pop();
          }
        } catch (error) {
          debugPrint('Ignored malformed library action: $error');
        }
      });
    _loadUi();
  }

  Future<List<SchoolBook>> _readCatalog() async {
    final raw = await rootBundle.loadString('assets/library_catalog.json');
    final decoded = jsonDecode(raw) as List<dynamic>;
    return List<SchoolBook>.unmodifiable(decoded.map((entry) {
      final b = Map<String, dynamic>.from(entry as Map);
      return SchoolBook(
        grade: b['grade'] as String,
        subject: b['subject'] as String,
        title: b['title'] as String,
        url: b['url'] as String? ?? '',
      );
    }));
  }

  Future<void> _loadUi() async {
    if (mounted) setState(() { _loading = true; _loadError = null; });
    try {
      await _web.loadFlutterAsset('assets/library_ui.html');
    } catch (error) {
      if (mounted) setState(() { _loading = false; _loadError = '$error'; });
    }
  }

  void _notice(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
      );
    }
  }

  Future<void> _copyBackupToClipboard(String data) async {
    try {
      await Clipboard.setData(ClipboardData(text: data));
      _notice('نُسخت بيانات JSON إلى الحافظة؛ الصقها في ملف نصي للاحتفاظ بها.');
    } catch (error) {
      _notice('تعذّر نسخ البيانات: $error');
    }
  }

  Future<void> _pasteBackupFromClipboard() async {
    try {
      final clip = await Clipboard.getData('text/plain');
      final raw = clip?.text;
      if (raw == null || raw.isEmpty || raw.length > 2000000) {
        _notice('لا توجد نسخة JSON صالحة في الحافظة.');
        return;
      }
      await _web.runJavaScript('window.importBackupFromAndroid(${jsonEncode(raw)});');
    } catch (error) {
      _notice('تعذّر الاستيراد من الحافظة: $error');
    }
  }

  Future<void> _openBookByIndex(int id) async {
    if (_openingBook) return;
    _openingBook = true;
    try {
      final books = await _catalog;
      if (!mounted || id < 0 || id >= books.length) return;
      final book = books[id];
      if (book.url.isEmpty) { _notice('رابط الكتاب غير متوفر.'); return; }
      final stored = await offline.loadOfflineBooks();
      if (!mounted) return;
      offline.OfflineBookInfo? existing;
      for (final item in stored) {
        if (item.key == book.key && item.url == book.url) {
          existing = item;
          break;
        }
      }
      final choice = await showModalBottomSheet<String>(
        context: context,
        showDragHandle: true,
        builder: (sheetContext) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 2, 16, 20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(book.title, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text('${book.subject} • ${book.grade}',
                style: const TextStyle(color: Colors.black54)),
              const SizedBox(height: 12),
              if (existing != null)
                ListTile(
                  leading: const Icon(Icons.auto_stories_rounded, color: Color(0xFF10B69A)),
                  title: const Text('قراءة النسخة المحفوظة'),
                  subtitle: const Text('فتح مباشر دون انتظار الشبكة'),
                  onTap: () => Navigator.pop(sheetContext, 'read'),
                ),
              ListTile(
                leading: const Icon(Icons.download_for_offline_rounded, color: Color(0xFF496AF2)),
                title: Text(existing == null ? 'تنزيل ثم قراءة داخل التطبيق' : 'إعادة تنزيل آخر نسخة'),
                subtitle: const Text('يحفظ PDF محليًا لتصفح أسرع دون إنترنت'),
                onTap: () => Navigator.pop(sheetContext, 'download'),
              ),
              ListTile(
                leading: const Icon(Icons.open_in_browser_rounded),
                title: const Text('فتح رابط Google Drive في المتصفح'),
                onTap: () => Navigator.pop(sheetContext, 'external'),
              ),
            ]),
          ),
        ),
      );
      if (!mounted) return;
      if (choice == 'read' && existing != null) {
        await _openReader(book, existing.path);
      } else if (choice == 'download') {
        await _downloadThenRead(book);
      } else if (choice == 'external') {
        final ok = await launchUrl(Uri.parse(book.url), mode: LaunchMode.externalApplication);
        if (!ok) _notice('تعذر فتح الرابط في المتصفح.');
      }
    } catch (error) {
      _notice('تعذّر فتح الكتاب: $error');
    } finally {
      _openingBook = false;
    }
  }

  Future<void> _downloadThenRead(SchoolBook book) async {
    final cancellation = offline.OfflineDownloadCancellation();
    final progress = ValueNotifier<double?>(null);
    if (!mounted) return;
    // Native progress UI is separate from WebView and never rebuilds the HTML.
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: const Text('تنزيل الكتاب'),
          content: ValueListenableBuilder<double?>(
            valueListenable: progress,
            builder: (context, value, _) => Column(mainAxisSize: MainAxisSize.min, children: [
              LinearProgressIndicator(value: value),
              const SizedBox(height: 12),
              Text(value == null ? 'جارٍ الاتصال بمصدر الملف…' : 'تم تحميل ${(value * 100).round()}%'),
            ]),
          ),
          actions: [TextButton(onPressed: cancellation.cancel, child: const Text('إلغاء التنزيل'))],
        ),
      ),
    );
    offline.OfflineBookInfo? result;
    Object? failure;
    try {
      result = await offline.saveBookOffline(
        key: book.key,
        title: book.title,
        grade: book.grade,
        subject: book.subject,
        url: book.url,
        cancellation: cancellation,
        onProgress: (received, total) {
          if (total != null && total > 0 && !cancellation.isCancelled) {
            progress.value = (received / total).clamp(0.0, 1.0).toDouble();
          }
        },
      );
    } on offline.OfflineDownloadCancelled {
      failure = 'أُلغي التنزيل';
    } catch (error) {
      failure = error;
    } finally {
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
      progress.dispose();
    }
    if (!mounted) return;
    if (result != null) {
      await _openReader(book, result.path);
    } else if (failure != null) {
      _notice('تعذّر تنزيل الكتاب: $failure');
    }
  }

  Future<void> _openReader(SchoolBook book, String path) async {
    if (!mounted) return;
    await Navigator.push<void>(context, MaterialPageRoute(
      builder: (_) => PdfReaderScreen(path: path, bookKey: book.key, title: book.title),
    ));
  }

  Future<void> _openDownloads() async {
    try {
      final list = await _catalog;
      if (!mounted) return;
      await Navigator.push<void>(context, MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: const Text('التنزيلات')),
          body: OfflineCenterScreen(books: list),
        ),
      ));
    } catch (error) {
      _notice('تعذر فتح التنزيلات: $error');
    }
  }

  Future<void> _openReviews() async {
    if (!mounted) return;
    var grade = grades.first;
    var difficulty = 'متوسط';
    await Navigator.push<void>(context, MaterialPageRoute(
      builder: (_) => StatefulBuilder(
        builder: (context, update) => Scaffold(
          appBar: AppBar(title: const Text('المراجعات الدراسية')),
          body: ExamsPage(
            grade: grade,
            difficulty: difficulty,
            onGradeChanged: (value) => update(() => grade = value),
            onDifficultyChanged: (value) => update(() => difficulty = value),
          ),
        ),
      ),
    ));
  }

  Future<void> _goBackInHtml() async {
    try {
      await _web.runJavaScript('''
        if(document.getElementById('dialogMount')?.innerHTML){closeModal();}
        else if(state.section==='books'){pickGrade(gradeIndex(state.grade));}
        else if(state.section==='subjects'){pickStage(state.stage);}
        else if(state.section!=='home'){choose('home');}
        else if(window.NativeLibrary){NativeLibrary.postMessage(JSON.stringify({action:'exit'}));}
      ''');
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) {
          if (!didPop) _goBackInHtml();
        },
        child: Scaffold(
          backgroundColor: const Color(0xFFF6F8FF),
          body: SafeArea(
            child: Stack(children: [
              WebViewWidget(controller: _web),
              if (_loading) const Center(child: CircularProgressIndicator()),
              if (_loadError != null)
                Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.error_outline, color: Colors.redAccent, size: 42),
                    const SizedBox(height: 10),
                    const Text('تعذّر فتح واجهة المكتبة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    SelectableText(_loadError!, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton(onPressed: _loadUi, child: const Text('إعادة المحاولة')),
                  ]),
                )),
            ]),
          ),
        ),
      );
}
