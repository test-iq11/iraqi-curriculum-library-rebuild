import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('exact HTML asset is shipped and Android bridge is present', () async {
    final html = await rootBundle.loadString('assets/library_ui.html');
    expect(html, contains('<html lang="ar" dir="rtl">'));
    expect(html, contains('class="sidebar"'));
    expect(html, contains('class="topbar"'));
    expect(html, contains('NativeLibrary.postMessage'));
    expect(html, contains("openNativeFeature('downloads')"));
    expect(html, contains("openNativeFeature('reviews')"));
    expect(html, contains('const BOOKS='));
  });

  test('first grade reading and activity URLs are exactly the supplied links', () async {
    final raw = await rootBundle.loadString('assets/library_catalog.json');
    final books = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    expect(books.length, 157);
    final read = books.singleWhere((book) =>
      book['grade'] == 'الأول الابتدائي' && book['title'] == 'كتاب القراءة');
    final activity = books.singleWhere((book) =>
      book['grade'] == 'الأول الابتدائي' && book['title'] == 'نشاط القراءة');
    expect(read['url'], 'https://drive.google.com/file/d/10RMSOmVOmJ0I5aUFvQMGH2D5qs3WrmAN/view?usp=drivesdk');
    expect(activity['url'], 'https://drive.google.com/file/d/1Ih3Wm3i-UMhP73VTGtKdgsAQiHa2fQSm/view?usp=drivesdk');
    final seen = <String>{};
    for (final book in books) {
      expect(seen.add('${book['grade']}|${book['title']}'), isTrue);
    }
  });
}
