#!/usr/bin/env python3
"""Static regression checks; flutter analyze/test remains the authoritative compile check."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
model = (root / 'lib/models/library_catalog.dart').read_text()
manager = (root / 'lib/admin/admin_library_app.dart').read_text()
user = (root / 'lib/user/user_library_app.dart').read_text()
reader = (root / 'lib/user/book_pdf_screen.dart').read_text()
controls = (root / 'lib/user/pdf_reader_controls.dart').read_text()
for item in ("subject['color'] != null", "book['color'] != null"):
    assert item in model, f'Optional color validation missing: {item}'
for item in ("edited['color'] = result['color']", "type == 'subject' || type == 'book'", 'colorNames[hex]', '_editorDefaultColor'):
    assert item in manager, f'Manager card color missing: {item}'
for item in ("_color(book['color']", "_color(item['color'], parentAccent)", 'Color.lerp(_accent,', 'ألوان الواجهة والبطاقة الرئيسية'):
    assert item in user, f'User published colors missing: {item}'
for item in ('_nightPagesFilter', 'ColorFiltered(', '_readerNightKey', 'shared_preferences', "'إيقاف القراءة الليلية'", 'darkMode: _readerNight'):
    assert item in reader, f'Night reader feature missing: {item}'
for item in ('final bool darkMode;', 'widget.darkMode ? Colors.white', 'const Color(0xFF17253B)'):
    assert item in controls, f'Night toolbar missing: {item}'
assert 'interactionEndFrictionCoefficient: 0.00000125' in reader
print('PASS: optional subject/book colors, published colors, hero-theme synchronization, night PDF, toolbar contrast and fling inertia')
