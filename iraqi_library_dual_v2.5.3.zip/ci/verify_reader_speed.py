#!/usr/bin/env python3
"""Regression guard for PDF reader momentum, scroll thumb, slider and features."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
reader = (root / 'lib/user/book_pdf_screen.dart').read_text(encoding='utf-8')
controls = (root / 'lib/user/pdf_reader_controls.dart').read_text(encoding='utf-8')

checks = (
    'interactionEndFrictionCoefficient: 0.00000125',
    'verticalCacheExtent: 1.25',
    'enableLowResolutionPagePreview: true',
    'partialImageLoadingDelay: Duration(milliseconds: 90)',
    'loadPageDimensionsOnDemand: true',
    'PdfViewerScrollThumb(',
    'orientation: ScrollbarOrientation.left',
    'PdfViewer.file(',
    'PdfViewer.uri(',
    '_showBookSearch',
    '_showThumbnails',
    '_showContents',
    '_showQuickAccess',
    '_toggleBookmark',
    '_addNote',
    '_saveProgressTimer',
)
for token in checks:
    assert token in reader, f'PDF performance/feature regression: {token}'
for token in (
    'extends StatefulWidget',
    'int? _previewPage',
    'onChangeEnd:',
    'widget.onGoToPage(page)',
    'widget.onPreviewPage(page)',
    'static const double toolbarHeight = 56',
):
    assert token in controls, f'Scrollbar regression: {token}'
print('PASS: fast PDF flings, scrubbing thumb, responsive preview slider and legacy reader tools')
