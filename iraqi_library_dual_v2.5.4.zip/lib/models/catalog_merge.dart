import 'library_catalog.dart';

/// Safely rebases a manager's unpublished edits onto the latest GitHub catalog.
/// Non-overlapping field changes are kept from both sides. Overlapping edits
/// are surfaced to the manager; they are never silently discarded.
class CatalogMergeResult {
  const CatalogMergeResult(this.catalog, this.conflicts);
  final LibraryCatalog catalog;
  final List<String> conflicts;
  bool get hasConflicts => conflicts.isNotEmpty;
}

class CatalogMerger {
  static const Object _missing = Object();

  static bool _equal(Object? a, Object? b) {
    if (identical(a, b)) { return true; }
    if (a is Map && b is Map) {
      if (a.length != b.length) { return false; }
      for (final key in a.keys) {
        if (!b.containsKey(key) || !_equal(a[key], b[key])) { return false; }
      }
      return true;
    }
    if (a is List && b is List) {
      if (a.length != b.length) { return false; }
      for (var i = 0; i < a.length; i++) {
        if (!_equal(a[i], b[i])) { return false; }
      }
      return true;
    }
    return a == b;
  }

  static List<Map<String, dynamic>> _mergeGroup(
    String group,
    List<Map<String, dynamic>> baseline,
    List<Map<String, dynamic>> draft,
    List<Map<String, dynamic>> remote,
    List<String> conflicts, {
    required bool preferLocalConflicts,
  }) {
    final old = {for (final item in baseline) item['id'].toString(): item};
    final mine = {for (final item in draft) item['id'].toString(): item};
    final theirs = {for (final item in remote) item['id'].toString(): item};
    final ids = <String>{...theirs.keys, ...mine.keys, ...old.keys};
    final merged = <Map<String, dynamic>>[];

    for (final id in ids) {
      final a = old[id], b = mine[id], c = theirs[id];
      Map<String, dynamic>? selected;
      if (_equal(b, a)) {
        selected = c;
      } else if (_equal(c, a) || _equal(b, c)) {
        selected = b;
      } else if (b == null || c == null || a == null) {
        // Delete-vs-edit or independently adding the same identifier.
        conflicts.add('$group: ${LibraryCatalog.name(b ?? c ?? a!)}');
        selected = preferLocalConflicts ? b : c;
      } else {
        final values = <String, dynamic>{};
        for (final field in <String>{...a.keys, ...b.keys, ...c.keys}) {
          final before = a.containsKey(field) ? a[field] : _missing;
          final local = b.containsKey(field) ? b[field] : _missing;
          final published = c.containsKey(field) ? c[field] : _missing;
          Object? chosen;
          if (_equal(local, before)) {
            chosen = published;
          } else if (_equal(published, before) || _equal(local, published)) {
            chosen = local;
          } else {
            conflicts.add('$group: ${LibraryCatalog.name(b)} ($field)');
            chosen = preferLocalConflicts ? local : published;
          }
          if (!identical(chosen, _missing)) { values[field] = chosen; }
        }
        selected = values;
      }
      if (selected != null) { merged.add(Map<String, dynamic>.from(selected)); }
    }
    return merged;
  }

  static CatalogMergeResult merge({
    required LibraryCatalog base,
    required LibraryCatalog local,
    required LibraryCatalog remote,
    bool preferLocalConflicts = false,
  }) {
    final conflicts = <String>[];
    final next = LibraryCatalog(
      revision: remote.revision,
      updatedAt: remote.updatedAt,
      stages: _mergeGroup('مرحلة', base.stages, local.stages, remote.stages, conflicts,
          preferLocalConflicts: preferLocalConflicts),
      grades: _mergeGroup('صف', base.grades, local.grades, remote.grades, conflicts,
          preferLocalConflicts: preferLocalConflicts),
      subjects: _mergeGroup('مادة', base.subjects, local.subjects, remote.subjects, conflicts,
          preferLocalConflicts: preferLocalConflicts),
      books: _mergeGroup('كتاب', base.books, local.books, remote.books, conflicts,
          preferLocalConflicts: preferLocalConflicts),
      reviews: _mergeGroup('سؤال', base.reviews, local.reviews, remote.reviews, conflicts,
          preferLocalConflicts: preferLocalConflicts),
    );
    // A conflict preview can be returned even if its default preference would
    // yield a temporary invalid catalog; only validate the final chosen merge.
    if (conflicts.isEmpty || preferLocalConflicts) { next.validate(); }
    return CatalogMergeResult(next, conflicts);
  }
}
