import 'dart:convert';
import 'dart:math';

/// Single contract shared between both APKs and data/library.json.
/// Admin keeps a local unpublished draft; public APK only consumes published data.
class LibraryCatalog {
  LibraryCatalog({
    required this.revision,
    required this.updatedAt,
    required this.stages,
    required this.grades,
    required this.subjects,
    required this.books,
    List<Map<String, dynamic>>? reviews,
  }) : reviews = reviews ?? [];

  int revision;
  String updatedAt;
  final List<Map<String, dynamic>> stages;
  final List<Map<String, dynamic>> grades;
  final List<Map<String, dynamic>> subjects;
  final List<Map<String, dynamic>> books;
  /// Optional review-question bank. An old schemaVersion=2 catalog stays readable.
  final List<Map<String, dynamic>> reviews;

  static List<Map<String, dynamic>> _items(dynamic source) {
    if (source is! List) throw const FormatException('قائمة بيانات غير صحيحة');
    return source.map((e) {
      if (e is! Map) throw const FormatException('عنصر فهرس غير صحيح');
      return Map<String, dynamic>.from(e);
    }).toList();
  }

  factory LibraryCatalog.fromJson(Map<String, dynamic> json) {
    if (json['schemaVersion'] != 2) {
      throw const FormatException('نسخة ملف المكتبة غير مدعومة؛ يلزم schemaVersion=2');
    }
    final catalog = LibraryCatalog(
      revision: json['revision'] is int ? json['revision'] as int : 0,
      updatedAt: (json['updatedAt'] ?? '').toString(),
      stages: _items(json['stages']),
      grades: _items(json['grades']),
      subjects: _items(json['subjects']),
      books: _items(json['books']),
      reviews: _items(json['reviews'] ?? []),
    );
    catalog.validate();
    return catalog;
  }

  Map<String, dynamic> toJson() => {
        'schemaVersion': 2,
        'revision': revision,
        'updatedAt': updatedAt,
        'stages': stages,
        'grades': grades,
        'subjects': subjects,
        'books': books,
        if (reviews.isNotEmpty) 'reviews': reviews,
      };

  LibraryCatalog copy() => LibraryCatalog.fromJson(
        Map<String, dynamic>.from(jsonDecode(jsonEncode(toJson())) as Map),
      );

  static bool visible(Map<String, dynamic> item) => item['visible'] != false;

  static String newId(String type) =>
      '$type-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';

  static String name(Map<String, dynamic> item) => (item['name'] ?? item['title'] ?? '').toString();

  static bool validWebUrl(String url) {
    final parsed = Uri.tryParse(url.trim());
    return parsed != null &&
        (parsed.scheme == 'https' || parsed.scheme == 'http') &&
        parsed.host.isNotEmpty &&
        parsed.userInfo.isEmpty;
  }

  /// Validation is applied to *remote* data too; dangerous schemes are never opened.
  void validate() {
    if (revision < 0) throw const FormatException('رقم الإصدار غير صحيح');
    if (stages.length > 300 || grades.length > 2000 ||
        subjects.length > 10000 || books.length > 30000) {
      throw const FormatException('حجم الفهرس أكبر من الحد المسموح');
    }
    if (reviews.length > 20000) throw const FormatException('عدد أسئلة المراجعة يتجاوز الحد');
    final globalIds = <String>{};
    final stageNames = <String>{};
    final gradeNames = <String>{};
    for (final group in [stages, grades, subjects, books]) {
      for (final item in group) {
        final id = item['id'];
        if (id is! String || id.isEmpty || id.length > 120 || !globalIds.add(id)) {
          throw const FormatException('معرّف مكرر أو غير صالح');
        }
        final title = name(item).trim();
        if (title.isEmpty || title.length > 180) {
          throw const FormatException('اسم عنصر فارغ أو طويل جداً');
        }
        if (item['order'] is! int || (item['order'] as int) < 0) {
          throw const FormatException('ترتيب غير صالح');
        }
      }
    }
    for (final s in stages) {
      if (!stageNames.add(name(s).trim())) throw const FormatException('اسم مرحلة مكرر');
      if (!isColor(s['color'])) throw const FormatException('لون مرحلة غير صحيح');
    }
    final stageIds = stages.map((e) => e['id']).toSet();
    for (final g in grades) {
      if (!stageIds.contains(g['stageId'])) throw const FormatException('صف بلا مرحلة');
      if (!gradeNames.add(name(g).trim())) throw const FormatException('اسم صف مكرر');
      if (!isColor(g['color'])) throw const FormatException('لون صف غير صحيح');
    }
    final gradeIds = grades.map((e) => e['id']).toSet();
    final subjectNames = <String>{};
    for (final s in subjects) {
      if (!gradeIds.contains(s['gradeId'])) throw const FormatException('مادة بلا صف');
      if (!subjectNames.add('${s['gradeId']}|${name(s).trim()}')) {
        throw const FormatException('مادة مكررة في الصف نفسه');
      }
    }
    // Existing catalogs (schemaVersion 2) may omit these optional colors.
    // Reject malformed new values while remaining backward compatible.
    for (final subject in subjects) {
      if (subject['color'] != null && !isColor(subject['color'])) {
        throw const FormatException('لون المادة غير صحيح');
      }
    }
    final subjectIds = subjects.map((e) => e['id']).toSet();
    for (final b in books) {
      if (!subjectIds.contains(b['subjectId'])) throw const FormatException('كتاب بلا مادة');
      final url = (b['url'] ?? '').toString().trim();
      if (url.isNotEmpty && (url.length > 2500 || !validWebUrl(url))) {
        throw FormatException('رابط غير صحيح في: ${name(b)}');
      }
    }
    for (final book in books) {
      if (book['color'] != null && !isColor(book['color'])) {
        throw const FormatException('لون الكتاب غير صحيح');
      }
    }
    for (final q in reviews) {
      final id = q['id'];
      if (id is! String || id.isEmpty || id.length > 120 || !globalIds.add(id)) {
        throw const FormatException('معرف سؤال مراجعة مكرر');
      }
      if (!subjectIds.contains(q['subjectId'])) {
        throw const FormatException('سؤال مراجعة بلا مادة صحيحة');
      }
      if (q['text'] is! String || (q['text'] as String).trim().isEmpty ||
          (q['text'] as String).length > 500) {
        throw const FormatException('نص سؤال غير صحيح');
      }
      final choices = q['choices'];
      if (choices is! List || choices.length < 2 || choices.length > 6 ||
          choices.any((e) => e is! String || e.trim().isEmpty || e.length > 250)) {
        throw const FormatException('خيارات سؤال غير صحيحة');
      }
      final answer = q['answer'];
      if (answer is! int || answer < 0 || answer >= choices.length) {
        throw const FormatException('الإجابة الصحيحة خارج الخيارات');
      }
    }
  }

  static bool isColor(Object? c) => c is String && RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(c);

  List<Map<String, dynamic>> sorted(List<Map<String, dynamic>> group, {bool onlyVisible = false}) {
    final copy = group.where((e) => !onlyVisible || visible(e)).toList();
    copy.sort((a, b) => (a['order'] as int).compareTo(b['order'] as int));
    return copy;
  }

  List<Map<String, dynamic>> children(String parentType, String parentId) {
    switch (parentType) {
      case 'stage': return sorted(grades.where((g) => g['stageId'] == parentId).toList());
      case 'grade': return sorted(subjects.where((s) => s['gradeId'] == parentId).toList());
      case 'subject': return sorted(books.where((b) => b['subjectId'] == parentId).toList());
      default: return [];
    }
  }

  List<Map<String, dynamic>> group(String type) => switch (type) {
        'stage' => stages,
        'grade' => grades,
        'subject' => subjects,
        'book' => books,
        _ => throw ArgumentError('Unknown catalog group: $type'),
      };

  /// Cascade deletion happens only after explicit confirmation from the manager.
  int deleteTree(String type, String id) {
    int total = 1;
    for (final child in children(type, id).toList()) {
      final nextType = switch (type) {
        'stage' => 'grade', 'grade' => 'subject', 'subject' => 'book', _ => '',
      };
      if (nextType.isNotEmpty) total += deleteTree(nextType, child['id'] as String);
    }
    if (type == 'subject') reviews.removeWhere((q) => q['subjectId'] == id);
    group(type).removeWhere((e) => e['id'] == id);
    return total;
  }

  int descendants(String type, String id) {
    int count = 0;
    if (type == 'subject') count += reviews.where((q) => q['subjectId'] == id).length;
    for (final child in children(type, id)) {
      count++;
      final nextType = switch (type) {
        'stage' => 'grade', 'grade' => 'subject', 'subject' => 'book', _ => '',
      };
      if (nextType.isNotEmpty) count += descendants(nextType, child['id'] as String);
    }
    return count;
  }

  int get bookCount => books.where(visible).length;
  int get stageCount => stages.where(visible).length;
}
