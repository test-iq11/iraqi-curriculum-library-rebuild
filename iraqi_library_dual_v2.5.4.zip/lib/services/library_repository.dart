import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/library_catalog.dart';

/// Configured once by the build workflow from the repository containing the APK source.
/// No API token or write secret exists in the public app.
class LibraryEndpoint {
  static const owner = String.fromEnvironment('LIBRARY_OWNER');
  static const repo = String.fromEnvironment('LIBRARY_REPO');
  static const branch = String.fromEnvironment('LIBRARY_BRANCH', defaultValue: 'main');
  static const path = 'data/library.json';
  static bool get configured => owner.trim().isNotEmpty && repo.trim().isNotEmpty;

  static String get rawUrl =>
      'https://raw.githubusercontent.com/$owner/$repo/${Uri.encodeComponent(branch)}/$path';
  static String get apiUrl =>
      'https://api.github.com/repos/$owner/$repo/contents/$path';
}

class LibraryRepository {
  static const _cacheKey = 'public_library_catalog_schema_v2';
  static const _draftKey = 'manager_unpublished_draft_schema_v2';
  static const _baseKey = 'manager_draft_base_catalog_v254';
  static const _draftDirtyKey = 'manager_draft_dirty_v2';
  final http.Client client;
  final SharedPreferencesAsync prefs;

  LibraryRepository({http.Client? client, SharedPreferencesAsync? prefs})
      : client = client ?? http.Client(), prefs = prefs ?? SharedPreferencesAsync();

  Future<LibraryCatalog> packaged() async {
    final text = await rootBundle.loadString('assets/library_seed.json');
    return decode(text);
  }

  static LibraryCatalog decode(String jsonText) {
    if (utf8.encode(jsonText).length > 2 * 1024 * 1024) {
      throw const FormatException('حجم فهرس الكتب غير آمن');
    }
    final data = jsonDecode(jsonText);
    if (data is! Map<String, dynamic>) throw const FormatException('ملف المكتبة غير صحيح');
    return LibraryCatalog.fromJson(data);
  }

  Future<LibraryCatalog> cachedOrPackaged() async {
    final cached = await prefs.getString(_cacheKey);
    if (cached != null) {
      try { return decode(cached); } catch (_) { /* fallback to embedded seed */ }
    }
    return packaged();
  }

  Future<LibraryCatalog?> refreshPublic() async {
    if (!LibraryEndpoint.configured) return null;
    final uri = Uri.parse(LibraryEndpoint.rawUrl).replace(
      queryParameters: {'v': '${DateTime.now().millisecondsSinceEpoch}'},
    );
    final response = await client.get(uri, headers: {
      'Cache-Control': 'no-cache', 'Accept': 'application/json',
    }).timeout(const Duration(seconds: 14));
    if (response.statusCode != 200) {
      throw StateError('تعذّر جلب الفهرس المنشور (${response.statusCode})');
    }
    final fresh = decode(utf8.decode(response.bodyBytes));
    await prefs.setString(_cacheKey, jsonEncode(fresh.toJson()));
    return fresh;
  }

  Future<LibraryCatalog?> loadDraft() async {
    final s = await prefs.getString(_draftKey);
    if (s == null) return null;
    try { return decode(s); } catch (_) { return null; }
  }

  Future<LibraryCatalog?> loadDraftBase() async {
    final value = await prefs.getString(_baseKey);
    if (value == null) { return null; }
    try { return decode(value); } catch (_) { return null; }
  }

  Future<bool> hasDraft() async => await prefs.getBool(_draftDirtyKey) ?? false;

  Future<void> saveDraft(LibraryCatalog value, {LibraryCatalog? base}) async {
    value.validate();
    if (base != null) {
      await prefs.setString(_baseKey, jsonEncode(base.toJson()));
    }
    await prefs.setString(_draftKey, jsonEncode(value.toJson()));
    await prefs.setBool(_draftDirtyKey, true);
  }

  Future<void> markPublished(LibraryCatalog value) async {
    await prefs.setString(_cacheKey, jsonEncode(value.toJson()));
    await prefs.setString(_draftKey, jsonEncode(value.toJson()));
    await prefs.setString(_baseKey, jsonEncode(value.toJson()));
    await prefs.setBool(_draftDirtyKey, false);
  }
}
