import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/library_catalog.dart';
import '../services/library_repository.dart';
import 'downloaded_books.dart';
import 'restored_reviews_page.dart';
import 'book_pdf_screen.dart';

/// Native Flutter interface: no WebView, HTML navigation or JS bridge.
/// The administrator and users still share the same published catalog schema.
class IraqiLibraryUserApp extends StatefulWidget {
  const IraqiLibraryUserApp({super.key});

  /// Shared academic icon mapping used by both the UI and widget tests.
  /// Keep this public facade so test code does not depend on private State.
  static IconData gradeIcon(String grade) =>
      _IraqiLibraryUserAppState.gradeIcon(grade);

  @override
  State<IraqiLibraryUserApp> createState() => _IraqiLibraryUserAppState();
}

class _IraqiLibraryUserAppState extends State<IraqiLibraryUserApp>
    with WidgetsBindingObserver {
  static const _blue = Color(0xff496af2);
  static const _ink = Color(0xff192b4e);
  static const _bg = Color(0xfff5f7ff);
  static const _prefsFav = 'native_user_favorites_v23';
  static const _prefsNotes = 'native_user_notes_v23';
  static const _prefsDark = 'native_user_dark_v23';
  static const _prefsScale = 'native_user_text_scale_v23';
  static const _prefsAccent = 'native_user_accent_v24';
  static const _prefsCompact = 'native_user_compact_v24';
  static const _prefsNoMotion = 'native_user_reduce_motion_v24';

  final _repository = LibraryRepository();
  final _downloads = DownloadedBooks();
  final _prefs = SharedPreferencesAsync();
  final _messenger = GlobalKey<ScaffoldMessengerState>();
  final _navigator = GlobalKey<NavigatorState>();
  final _searchController = TextEditingController();

  LibraryCatalog? _catalog;
  final Set<String> _favorites = {};
  final List<String> _notes = [];
  bool _dark = false;
  bool _compact = false, _noMotion = false;
  Color _accent = _blue;
  final _noteController = TextEditingController();
  String _noteFilter = '';
  bool _syncing = false;
  double _fontScale = 1.0;
  String _section = 'home';
  String? _stageId;
  String? _gradeId;
  String? _subjectId;
  String? _syncError;
  DateTime? _lastSync;
  String _search = '';


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      final cached = await _repository.cachedOrPackaged();
      final fav = await _prefs.getString(_prefsFav);
      final notes = await _prefs.getString(_prefsNotes);
      final dark = await _prefs.getBool(_prefsDark) ?? false;
      final scale = await _prefs.getDouble(_prefsScale) ?? 1.0;
      final accent = await _prefs.getInt(_prefsAccent);
      final compact = await _prefs.getBool(_prefsCompact) ?? false;
      final noMotion = await _prefs.getBool(_prefsNoMotion) ?? false;
      if (!mounted) return;
      setState(() {
        _catalog = cached;
        _dark = dark;
        _compact = compact;
        _noMotion = noMotion;
        if (accent != null) _accent = Color(accent);
        _fontScale = scale.clamp(.9, 1.25).toDouble();
        if (fav != null) {
          final items = jsonDecode(fav);
          if (items is List) _favorites.addAll(items.map((e) => e.toString()));
        }
        if (notes != null) {
          final items = jsonDecode(notes);
          if (items is List) _notes.addAll(items.map((e) => e.toString()));
        }
      });
      await _refresh();
    } catch (e) {
      _toast('تعذر فتح الفهرس المحلي: $e');
    }
  }

  Future<void> _refresh({bool notify = false}) async {
    if (_syncing || !LibraryEndpoint.configured) {
      if (notify && !LibraryEndpoint.configured) _toast('المزامنة غير مهيأة في نسخة APK');
      return;
    }
    setState(() => _syncing = true);
    try {
      final fresh = await _repository.refreshPublic();
      if (!mounted) return;
      setState(() {
        if (fresh != null) _catalog = fresh;
        _syncError = null;
        _lastSync = DateTime.now();
        _syncing = false;
      });
      if (notify) _toast('تم تحديث الكتب والمراحل بنجاح');
    } catch (e) {
      if (!mounted) return;
      setState(() { _syncError = e.toString(); _syncing = false; });
      if (notify) _toast('تعذرت المزامنة؛ تُعرض آخر نسخة محفوظة');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        (_lastSync == null || DateTime.now().difference(_lastSync!).inMinutes >= 2)) {
      _refresh();
    }
  }

  void _toast(String msg) {
    _messenger.currentState?.showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 3)),
    );
  }

  Future<void> _saveFavorites() => _prefs.setString(_prefsFav, jsonEncode(_favorites.toList()));
  Future<void> _saveNotes() => _prefs.setString(_prefsNotes, jsonEncode(_notes));

  void _toggleFavorite(String id) {
    setState(() {
      if (!_favorites.add(id)) _favorites.remove(id);
    });
    _saveFavorites();
  }

  void _go(String section, {String? stageId, String? gradeId, String? subjectId}) {
    FocusManager.instance.primaryFocus?.unfocus();
    _searchController.clear();
    setState(() {
      _section = section;
      _stageId = stageId;
      _gradeId = gradeId;
      _subjectId = subjectId;
      _search = '';
    });
  }

  void _back() {
    switch (_section) {
      case 'books': _go('subjects', stageId: _stageId, gradeId: _gradeId); break;
      case 'subjects': _go('grades', stageId: _stageId); break;
      case 'grades': _go('home'); break;
      default: _go('home');
    }
  }

  Map<String, dynamic>? _lookup(List<Map<String, dynamic>> group, String? id) {
    if (id == null) return null;
    for (final item in group) { if (item['id'] == id) return item; }
    return null;
  }

  List<Map<String, dynamic>> _visibleStages() =>
      _catalog?.sorted(_catalog!.stages, onlyVisible: true) ?? [];

  List<Map<String, dynamic>> _visibleGrades({String? stageId}) =>
      _catalog?.sorted(_catalog!.grades.where((g) =>
        (stageId == null || g['stageId'] == stageId) &&
        _visibleStages().any((s) => s['id'] == g['stageId'])).toList(), onlyVisible: true) ?? [];

  List<Map<String, dynamic>> _visibleSubjects({String? gradeId}) {
    final catalog = _catalog;
    if (catalog == null) return [];
    final gradeIds = _visibleGrades().map((g) => g['id']).toSet();
    return catalog.sorted(catalog.subjects.where((s) =>
      (gradeId == null || s['gradeId'] == gradeId) && gradeIds.contains(s['gradeId'])).toList(), onlyVisible: true);
  }

  List<Map<String, dynamic>> _visibleBooks({String? subjectId}) {
    final catalog = _catalog;
    if (catalog == null) return [];
    final subjectIds = _visibleSubjects().map((s) => s['id']).toSet();
    return catalog.sorted(catalog.books.where((b) =>
      (subjectId == null || b['subjectId'] == subjectId) && subjectIds.contains(b['subjectId'])).toList(), onlyVisible: true);
  }

  static Color _color(Object? value, [Color fallback = _blue]) {
    if (!LibraryCatalog.isColor(value)) return fallback;
    return Color(int.parse('FF${(value as String).substring(1)}', radix: 16));
  }

  static IconData _stageIcon(String? name) => switch (name) {
    'school' => Icons.school_outlined,
    'star' => Icons.workspace_premium_outlined,
    'pencil' => Icons.edit_outlined,
    'ruler' => Icons.straighten,
    'compass' => Icons.explore_outlined,
    'globe' => Icons.public_outlined,
    'science' => Icons.science_outlined,
    'calculator' => Icons.calculate_outlined,
    'history' => Icons.history_edu_outlined,
    _ => Icons.menu_book_outlined,
  };

  /// School-related grade pictograms (replaces the broken 'ال' abbreviation).
  /// New grades also receive a stable academic icon by name.
  static IconData gradeIcon(String grade) {
    const defined = <String, IconData>{
      'الأول الابتدائي': Icons.edit_outlined,
      'الثاني الابتدائي': Icons.auto_stories_outlined,
      'الثالث الابتدائي': Icons.straighten,
      'الرابع الابتدائي': Icons.explore_outlined,
      'الخامس الابتدائي': Icons.public_outlined,
      'السادس الابتدائي': Icons.calculate_outlined,
      'الأول المتوسط': Icons.menu_book_outlined,
      'الثاني المتوسط': Icons.science_outlined,
      'الثالث المتوسط': Icons.biotech_outlined,
      'الرابع العلمي': Icons.science_outlined,
      'الخامس العلمي': Icons.biotech_outlined,
      'السادس العلمي': Icons.travel_explore_outlined,
      'الرابع الأدبي': Icons.history_edu_outlined,
      'الخامس الأدبي': Icons.library_books_outlined,
      'السادس الأدبي': Icons.lightbulb_outline,
    };
    if (defined.containsKey(grade)) return defined[grade]!;
    const extra = [Icons.edit_outlined, Icons.menu_book_outlined,
      Icons.science_outlined, Icons.calculate_outlined, Icons.public_outlined];
    var sum = 0;
    for (final rune in grade.runes) { sum = (sum * 31 + rune) & 0x7fffffff; }
    return extra[sum % extra.length];
  }

  IconData _gradeSymbol(Map<String,dynamic> grade) {
    final icon = grade['icon']?.toString();
    return icon == null || icon.isEmpty ? gradeIcon(LibraryCatalog.name(grade)) : _stageIcon(icon);
  }

  IconData _subjectIcon(String name) {
    if (name.contains('رياضيات')) return Icons.calculate_outlined;
    if (name.contains('فيزياء')) return Icons.bolt_outlined;
    if (name.contains('كيمياء')) return Icons.science_outlined;
    if (name.contains('أحياء') || name.contains('علوم')) return Icons.biotech_outlined;
    if (name.contains('اجتماع') || name.contains('جغرا')) return Icons.public_outlined;
    if (name.contains('إنكليزية') || name.contains('انكليزي')) return Icons.translate_outlined;
    if (name.contains('تاريخ')) return Icons.history_edu_outlined;
    if (name.contains('حاسوب')) return Icons.computer_outlined;
    return Icons.auto_stories_outlined;
  }

  String _headerTitle() {
    final cat = _catalog;
    if (cat == null) return 'المكتبة العراقية';
    switch (_section) {
      case 'grades': return LibraryCatalog.name(_lookup(cat.stages, _stageId) ?? {});
      case 'subjects': return LibraryCatalog.name(_lookup(cat.grades, _gradeId) ?? {});
      case 'books': return LibraryCatalog.name(_lookup(cat.subjects, _subjectId) ?? {});
      case 'favorites': return 'المفضلة';
      case 'notes': return 'ملاحظاتي';
      case 'downloads': return 'التنزيلات';
      case 'reviews': return 'بطاقات المراجعة';
      case 'settings': return 'الإعدادات';
      default: return 'المكتبة العراقية';
    }
  }

  bool get _nested => const ['grades', 'subjects', 'books', 'downloads', 'reviews'].contains(_section);

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: _accent,
        brightness: _dark ? Brightness.dark : Brightness.light),
      scaffoldBackgroundColor: _dark ? const Color(0xff101a2d) : _bg,
      pageTransitionsTheme: _noMotion ? const PageTransitionsTheme(builders: {
        TargetPlatform.android: _InstantPageTransitionsBuilder(),
      }) : const PageTransitionsTheme(),
      cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero,
        color: _dark ? const Color(0xff172640) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _dark ? const Color(0xff293b58) : const Color(0xffe4eaf5)))),
      appBarTheme: AppBarTheme(backgroundColor: _dark ? const Color(0xff101a2d) : _bg,
        foregroundColor: _dark ? Colors.white : _ink,
        elevation: 0, centerTitle: false),
    );
    return MaterialApp(
      title: 'المكتبة العراقية',
      debugShowCheckedModeBanner: false,
      theme: theme,
      navigatorKey: _navigator,
      scaffoldMessengerKey: _messenger,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: MediaQuery(data: MediaQuery.of(context).copyWith(
          textScaler: TextScaler.linear(_fontScale)), child: child ?? const SizedBox.shrink()),
      ),
      home: Scaffold(
        appBar: AppBar(
          leading: _nested ? IconButton(tooltip: 'رجوع', onPressed: _back,
            icon: const Icon(Icons.arrow_forward_rounded)) : null,
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_headerTitle(), maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            if (_section == 'home') Text('تعلم بذكاء وتصفح براحة',
              style: const TextStyle(fontSize: 11, color: Color(0xff8c98b0))),
          ]),
          actions: [
            if (_syncing) const Padding(padding: EdgeInsets.all(15),
              child: SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2)))
            else IconButton(tooltip: 'مزامنة الكتب', onPressed: () => _refresh(notify: true),
              icon: const Icon(Icons.sync_rounded)),
            IconButton(tooltip: 'الوضع الليلي', icon: Icon(_dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
              onPressed: () { setState(() => _dark = !_dark); _prefs.setBool(_prefsDark, _dark); }),
          ],
        ),
        body: _catalog == null ? const Center(child: CircularProgressIndicator()) : _body(),
        bottomNavigationBar: NavigationBar(
          backgroundColor: _dark ? const Color(0xff172640) : Colors.white,
          indicatorColor: _accent.withValues(alpha:.10),
          selectedIndex: switch (_section) {
            'favorites' => 1, 'notes' => 2, 'settings' => 3, _ => 0,
          },
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) => _go(['home','favorites','notes','settings'][i]),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined,color: Color(0xff4d75ed)), selectedIcon: Icon(Icons.home_rounded,color: Color(0xff4d75ed)), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.favorite_border,color: Color(0xffe76799)), selectedIcon: Icon(Icons.favorite,color: Color(0xffe76799)), label: 'المفضلة'),
            NavigationDestination(icon: Icon(Icons.notes_outlined,color: Color(0xff9a65d6)), selectedIcon: Icon(Icons.notes_rounded,color: Color(0xff9a65d6)), label: 'الملاحظات'),
            NavigationDestination(icon: Icon(Icons.settings_outlined,color: Color(0xff18a78d)), selectedIcon: Icon(Icons.settings,color: Color(0xff18a78d)), label: 'الإعدادات'),
          ],
        ),
      ),
    );
  }

  Widget _body() => switch (_section) {
    'grades' => _gradesPage(),
    'subjects' => _subjectsPage(),
    'books' => _booksPage(),
    'favorites' => _favoritesPage(),
    'downloads' => _downloadsPage(),
    'reviews' => _reviewsPage(),
    'notes' => _notesPage(),
    'settings' => _settingsPage(),
    _ => _homePage(),
  };

  Widget _title(String title, [String? subtitle]) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 17, 2, 11),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
      if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 4),
        child: Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xff8e9bb0)))),
    ]),
  );

  Widget _homePage() {
    final stages = _visibleStages();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 9, 16, 24), children: [
      Container(
        constraints: const BoxConstraints(minHeight: 174),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(colors: [
            Color.lerp(_accent, const Color(0xFF152848), .13)!,
            Color.lerp(_accent, const Color(0xFF55C0E2), .24)!,
          ])),
        padding: const EdgeInsets.all(22),
        child: Stack(children: [
          Positioned(left: 2, top: 12, child: Icon(Icons.menu_book_rounded,
            size: 97, color: Colors.white.withValues(alpha: .16))),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('المناهج الدراسية العراقية', style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            const Text('كل كتبك الدراسية\nفي مكان واحد',
              style: TextStyle(color: Colors.white, fontSize: 23, height: 1.4, fontWeight: FontWeight.w900)),
            const SizedBox(height: 11),
            FilledButton.icon(onPressed: () { if (stages.isNotEmpty) _go('grades', stageId: stages.first['id'].toString()); },
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: _accent),
              icon: const Icon(Icons.auto_stories_outlined), label: const Text('ابدأ التصفح')),
          ]),
        ]),
      ),
      const SizedBox(height: 17),
      TextField(controller: _searchController, onChanged: (v) => setState(() => _search = v),
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search),
          hintText: 'ابحث عن كتاب أو مادة أو صف...', filled: true,
          fillColor: _dark ? const Color(0xff172640) : Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(17),
            borderSide: BorderSide.none)),
      ),
      if (_search.trim().isNotEmpty) ...[
        _title('نتائج البحث'),
        ..._searchResults(),
      ] else ...[
        _title('المراحل الدراسية', 'اختر المرحلة للوصول إلى الصفوف والكتب'),
        ...stages.map((s) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _stageCard(s))),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _quickCard('التنزيلات', 'كتبك المحفوظة', Icons.download_outlined,
            const Color(0xff10aa8d), () => _go('downloads'))),
          const SizedBox(width: 10),
          Expanded(child: _quickCard('بطاقات المراجعة', 'أسئلة للتدريب', Icons.style_outlined,
            const Color(0xff8b5bd7), () => _go('reviews'))),
        ]),
      ],
    ]);
  }

  List<Widget> _searchResults() {
    final term = _search.trim().toLowerCase();
    final results = _visibleBooks().where((b) {
      final subject = _lookup(_catalog!.subjects, b['subjectId']?.toString());
      final grade = _lookup(_catalog!.grades, subject?['gradeId']?.toString());
      final bookName = LibraryCatalog.name(b);
      final subjectName = LibraryCatalog.name(subject ?? <String, dynamic>{});
      final gradeName = LibraryCatalog.name(grade ?? <String, dynamic>{});
      return '$bookName $subjectName $gradeName'.toLowerCase().contains(term);
    }).take(50).toList();
    if (results.isEmpty) return [const ListTile(title: Text('لا توجد نتائج مطابقة'))];
    return results.map((b) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _bookCard(b))).toList();
  }

  Widget _stageCard(Map<String, dynamic> item, {bool header = false}) {
    final accent = _color(item['color']);
    final id = item['id'].toString();
    final n = _visibleGrades(stageId: id).length;
    final foreground = header ? null : Colors.white;
    final detail = header ? const Color(0xff8491a7) : Colors.white70;
    return Card(child: InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _go('grades', stageId: id),
      child: Container(constraints: BoxConstraints(minHeight: header ? 103 : 119),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
          gradient: header ? null : LinearGradient(colors: [
            Color.lerp(accent, Colors.white, .08)!,
            Color.lerp(accent, const Color(0xff142654), .18)!,
          ]),
          border: header ? Border(right: BorderSide(color: accent, width: 5)) : null),
        child: Row(children: [
          if (header) _iconTile(_stageIcon(item['icon']?.toString()), accent, size: 54)
          else Container(width: 54, height: 54,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .2),
              borderRadius: BorderRadius.circular(15)),
            child: Icon(_stageIcon(item['icon']?.toString()), color: Colors.white, size: 30)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(LibraryCatalog.name(item), style: TextStyle(color: foreground,
              fontWeight: FontWeight.w900, fontSize: 17)),
            const SizedBox(height: 4),
            Text((item['description'] ?? '$n صفوف').toString(),
              maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: detail)),
          ])),
          Column(children: [Icon(Icons.chevron_left, color: foreground ?? accent),
            Text('$n صفوف', style: TextStyle(color: foreground ?? accent,
              fontSize: 10, fontWeight: FontWeight.w800))]),
        ]),
      ),
    ));
  }

  Widget _quickCard(String title, String detail, IconData symbol, Color accent, VoidCallback action) =>
    Card(child: InkWell(onTap: action, borderRadius: BorderRadius.circular(19),
      child: Padding(padding: const EdgeInsets.all(14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          _iconTile(symbol, accent, size: 47),
          const SizedBox(height: 12),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 3),
          Text(detail, style: const TextStyle(color: Color(0xff8e9bb0), fontSize: 10)),
        ])),
    ));

  Widget _iconTile(IconData symbol, Color accent, {double size = 52}) => Container(
    width: size, height: size,
    decoration: BoxDecoration(color: accent.withValues(alpha: .11),
      borderRadius: BorderRadius.circular(15)),
    child: Icon(symbol, color: accent, size: size * .49),
  );

  Widget _gradesPage() {
    final stage = _lookup(_catalog!.stages, _stageId);
    final grades = _visibleGrades(stageId: _stageId);
    return Column(children: [
      if (stage != null) Padding(padding: const EdgeInsets.fromLTRB(15, 12, 15, 0),
        child: _stageCard(stage, header: true)),
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 25),
        itemCount: grades.length + 1,
        itemBuilder: (ctx, index) {
          if (index == 0) return _title('اختر الصف الدراسي', 'لكل صف أيقونة دراسية ولون مميز');
          final grade = grades[index - 1];
          final accent = _color(grade['color']);
          final gradeId = grade['id'].toString();
          final subjects = _visibleSubjects(gradeId: gradeId);
          final books = subjects.expand((s) => _visibleBooks(subjectId: s['id'].toString())).length;
          return Padding(padding: const EdgeInsets.only(bottom: 11), child: Card(
            child: InkWell(onTap: () => _go('subjects', stageId: _stageId, gradeId: gradeId),
              borderRadius: BorderRadius.circular(20),
              child: Container(constraints: const BoxConstraints(minHeight: 95),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
                  border: Border(right: BorderSide(color: accent, width: 6))),
                child: Row(children: [
                  _iconTile(_gradeSymbol(grade), accent, size: 62),
                  const SizedBox(width: 15),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(LibraryCatalog.name(grade), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 5),
                    Text('$books كتب مدرجة', style: const TextStyle(color: Color(0xff8897a9), fontSize: 12)),
                  ])),
                  Icon(Icons.chevron_left_rounded, color: accent),
                ]),
              ),
            ),
          ));
        },
      )),
    ]);
  }

  Widget _subjectsPage() {
    final subjects = _visibleSubjects(gradeId: _gradeId);
    final grade = _lookup(_catalog!.grades, _gradeId);
    final parentAccent = _color(grade?['color']);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 30), children: [
      _title('المواد الدراسية', 'اختر المادة للوصول إلى كتبها'),
      LayoutBuilder(builder: (ctx, constraints) => GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: subjects.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: constraints.maxWidth > 620 ? 3 : 2,
          crossAxisSpacing: 12, mainAxisSpacing: 12, mainAxisExtent: _compact ? 124 : 149),
        itemBuilder: (ctx, index) {
          final item = subjects[index];
          final accent = _color(item['color'], parentAccent);
          final n = _visibleBooks(subjectId: item['id'].toString()).length;
          return Card(child: InkWell(onTap: () => _go('books', stageId: _stageId,
            gradeId: _gradeId, subjectId: item['id'].toString()),
            borderRadius: BorderRadius.circular(20), child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                _iconTile(_subjectIcon(LibraryCatalog.name(item)), accent, size: _compact ? 40 : 50),
                const SizedBox(height: 8),
                Text(LibraryCatalog.name(item), textAlign: TextAlign.center, maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('$n كتب', style: const TextStyle(fontSize: 10,color:Color(0xff8c99ae))),
              ]),
            )));
        },
      )),
    ]);
  }

  Widget _booksPage() {
    final books = _visibleBooks(subjectId: _subjectId).where((b) =>
      LibraryCatalog.name(b).toLowerCase().contains(_search.toLowerCase())).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 13, 16, 3), child: TextField(
        controller: _searchController, onChanged: (v) => setState(() => _search = v),
        decoration: InputDecoration(prefixIcon: const Icon(Icons.search),
          hintText: 'ابحث في كتب المادة', border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14))),
      )),
      Expanded(child: books.isEmpty ? const Center(child: Text('لا توجد كتب مطابقة')) :
        LayoutBuilder(builder: (ctx, constraints) => GridView.builder(
          padding: const EdgeInsets.fromLTRB(16, 13, 16, 25),
          itemCount: books.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: constraints.maxWidth > 620 ? 3 : 2,
            crossAxisSpacing: 11, mainAxisSpacing: 11,
            mainAxisExtent: _compact ? 169 : 198),
          itemBuilder: (ctx, index) => _bookGridCard(books[index]),
        ))),
    ]);
  }

  Widget _bookGridCard(Map<String, dynamic> book) {
    final subject = _lookup(_catalog!.subjects, book['subjectId']?.toString());
    final grade = _lookup(_catalog!.grades, subject?['gradeId']?.toString());
    final accent = _color(book['color'], _color(subject?['color'], _color(grade?['color'])));
    final id = book['id'].toString();
    return Card(child: InkWell(onTap: () => _bookActions(book),
      borderRadius: BorderRadius.circular(20),
      child: Padding(padding: const EdgeInsets.all(12), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
            Container(width:44,height:53,decoration:BoxDecoration(
              gradient:LinearGradient(colors:[accent,Color.lerp(accent,const Color(0xff162748),.30)!]),
              borderRadius:BorderRadius.circular(12)),
              child:const Icon(Icons.auto_stories_rounded,color:Colors.white,size:26)),
            IconButton(visualDensity: VisualDensity.compact,
              onPressed:()=>_toggleFavorite(id),
              icon:Icon(_favorites.contains(id)?Icons.favorite:Icons.favorite_border,
                color:_favorites.contains(id)?const Color(0xffe95e88):accent)),
          ]),
          const SizedBox(height: 8),
          Expanded(child:Text(LibraryCatalog.name(book),maxLines:3,
            overflow:TextOverflow.ellipsis,
            style:const TextStyle(fontWeight:FontWeight.w900,fontSize:13,height:1.45))),
          Text(LibraryCatalog.name(subject ?? {}),maxLines:1,overflow:TextOverflow.ellipsis,
            style:const TextStyle(fontSize:10,color:Color(0xff8996aa))),
          const SizedBox(height:6),
          Row(children:[
            Expanded(child:Container(padding:const EdgeInsets.symmetric(vertical:7),
              decoration:BoxDecoration(color:accent.withValues(alpha:.10),borderRadius:BorderRadius.circular(10)),
              child:Text('فتح • تحميل • رابط',textAlign:TextAlign.center,
                style:TextStyle(color:accent,fontSize:10,fontWeight:FontWeight.w800)))),
          ]),
        ]),
      )));
  }

  Widget _bookCard(Map<String, dynamic> book) {
    final subject = _lookup(_catalog!.subjects, book['subjectId']?.toString());
    final grade = _lookup(_catalog!.grades, subject?['gradeId']?.toString());
    final accent = _color(book['color'], _color(subject?['color'], _color(grade?['color'])));
    final id = book['id'].toString();
    final subjectName = LibraryCatalog.name(subject ?? <String, dynamic>{});
    final gradeName = LibraryCatalog.name(grade ?? <String, dynamic>{});
    final location = '$subjectName • $gradeName';
    return Card(child: InkWell(borderRadius: BorderRadius.circular(19),
      onTap: () => _bookActions(book),
      child: Padding(padding: const EdgeInsets.all(11), child: Row(children: [
        _iconTile(Icons.auto_stories_outlined, accent, size: 56),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(LibraryCatalog.name(book), maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13)),
          const SizedBox(height: 5),
          Text(location,
            maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10.5, color: Color(0xff8693a8))),
          const SizedBox(height: 4),
          Text('اضغط لفتح خيارات الكتاب', style: TextStyle(color: accent, fontSize: 10)),
        ])),
        IconButton(tooltip: _favorites.contains(id) ? 'إزالة من المفضلة' : 'إضافة للمفضلة',
          onPressed: () => _toggleFavorite(id),
          icon: Icon(_favorites.contains(id) ? Icons.favorite : Icons.favorite_border,
            color: _favorites.contains(id) ? const Color(0xffe95e88) : accent)),
        Icon(Icons.chevron_left_rounded, color: accent),
      ])),
    ));
  }

  Future<void> _bookActions(Map<String, dynamic> book) async {
    final id = book['id'].toString();
    final url = (book['url'] ?? '').toString();
    final valid = LibraryCatalog.validWebUrl(url);
    final ctx = _navigator.currentContext;
    if (ctx == null) return;
    await showModalBottomSheet<void>(context: ctx, isScrollControlled: true,
      showDragHandle: true, useSafeArea: true,
      builder: (sheet) => Padding(padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(LibraryCatalog.name(book), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 13),
          FilledButton.icon(onPressed: valid ? () {
            Navigator.pop(sheet); _read(book);
          } : null, icon: const Icon(Icons.chrome_reader_mode_outlined), label: const Text('فتح الكتاب')),
          OutlinedButton.icon(onPressed: valid ? () {
            Navigator.pop(sheet); _download(book);
          } : null, icon: const Icon(Icons.download_outlined), label: const Text('تحميل الكتاب')),
          OutlinedButton.icon(onPressed: valid ? () async {
            await Clipboard.setData(ClipboardData(text: url));
            if (sheet.mounted) Navigator.pop(sheet);
            _toast('تم نسخ رابط الكتاب');
          } : null, icon: const Icon(Icons.copy_outlined), label: const Text('نسخ الرابط')),
          TextButton.icon(onPressed: () {
            Navigator.pop(sheet); _toggleFavorite(id);
          }, icon: Icon(_favorites.contains(id) ? Icons.favorite : Icons.favorite_border),
            label: Text(_favorites.contains(id) ? 'إزالة من المفضلة' : 'إضافة للمفضلة')),
        ]),
      ),
    );
  }

  Future<void> _read(Map<String, dynamic> book) async {
    final url = (book['url'] ?? '').toString();
    if (!LibraryCatalog.validWebUrl(url)) { _toast('رابط الكتاب غير صالح'); return; }
    final file = await _downloads.localFile(book['id'].toString());
    if (!mounted) return;
    await _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
      title: LibraryCatalog.name(book), url: url, bookKey: book['id'].toString(), localPath: file)));
  }

  Future<void> _download(Map<String, dynamic> book) async {
    _toast('بدأ تنزيل الكتاب');
    try {
      final path = await _downloads.download(book);
      if (!mounted) return;
      _toast('اكتمل التنزيل بنجاح');
      await _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
        title: LibraryCatalog.name(book), url: (book['url'] ?? '').toString(), bookKey: book['id'].toString(), localPath: path)));
    } catch (e) { _toast('تعذر التنزيل: $e'); }
  }

  Widget _favoritesPage() {
    final books = _visibleBooks().where((b) => _favorites.contains(b['id'])).toList();
    return books.isEmpty ? const Center(child: Text('لم تُضف كتباً إلى المفضلة بعد')) :
      ListView.builder(padding: const EdgeInsets.all(15), itemCount: books.length,
        itemBuilder: (ctx, i) => Padding(padding: const EdgeInsets.only(bottom: 9),
          child: _bookCard(books[i])));
  }

  Widget _downloadsPage() => FutureBuilder<Map<String, dynamic>>(
    future: _downloads.entries(),
    builder: (context, snapshot) {
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final items = snapshot.data!.entries.toList();
      if (items.isEmpty) return const Center(child: Text('لم تحمّل كتباً بعد'));
      return ListView.builder(padding: const EdgeInsets.all(15), itemCount: items.length,
        itemBuilder: (ctx, i) {
          final entry = items[i];
          final book = Map<String, dynamic>.from(entry.value as Map);
          return Padding(padding: const EdgeInsets.only(bottom: 8), child: Card(
            child: ListTile(leading: const Icon(Icons.picture_as_pdf_outlined, color: _blue),
              title: Text((book['title'] ?? 'كتاب').toString()),
              subtitle: const Text('محفوظ للقراءة دون إنترنت'),
              onTap: () => _navigator.currentState?.push(MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
                title: (book['title'] ?? 'كتاب').toString(), url: (book['sourceUrl'] ?? '').toString(), bookKey: entry.key,
                localPath: (book['path'] ?? '').toString()))),
              trailing: IconButton(tooltip: 'حذف النسخة المحمّلة', icon: const Icon(Icons.delete_outline),
                onPressed: () async { await _downloads.remove(entry.key); if (mounted) setState(() {}); }),
            ),
          ));
        },
      );
    },
  );

  Widget _reviewsPage() => RestoredReviewsPage(
    catalog: _catalog!,
    grades: _visibleGrades(),
    subjects: _visibleSubjects(),
    books: _visibleBooks(),
    accent: _accent,
    reduceMotion: _noMotion,
  );

  Future<void> _editNote({int? index}) async {
    final controller = TextEditingController(text: index == null ? '' : _notes[index]);
    final ctx = _navigator.currentContext;
    if (ctx == null) { controller.dispose(); return; }
    final result = await showDialog<String>(context: ctx, builder: (dialog) => AlertDialog(
      title: Text(index == null ? 'ملاحظة جديدة' : 'تعديل الملاحظة'),
      content: TextField(controller: controller, maxLength: 1500, minLines: 3, maxLines: 7,
        decoration: const InputDecoration(hintText: 'اكتب ملاحظتك...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(dialog, controller.text.trim()),
          child: const Text('حفظ')),
      ],
    ));
    controller.dispose();
    if (result == null || result.isEmpty || !mounted) return;
    setState(() { if (index == null) { _notes.insert(0, result); } else { _notes[index] = result; } });
    await _saveNotes();
  }

  Widget _notesPage() {
    final visible = _notes.asMap().entries.where((e) =>
      e.value.toLowerCase().contains(_noteFilter.toLowerCase())).toList();
    const colors = [Color(0xfffff0c9),Color(0xffe3f2ff),Color(0xffe5f8ea),
      Color(0xfff2eaff),Color(0xffffe9ee),Color(0xffe9f6f6)];
    const ink = Color(0xff243551);
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 26), children: [
      _title('ملاحظاتي', 'دفتر ملون لأفكارك وواجباتك اليومية'),
      Card(child:Padding(padding: const EdgeInsets.all(14), child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Row(children:[
            const Icon(Icons.sticky_note_2_outlined,color:Color(0xffa06bd7)),
            const SizedBox(width:9),
            const Text('اكتب ملاحظة جديدة',style:TextStyle(fontWeight:FontWeight.w900)),
            const Spacer(),
            Text('${_notes.length} ملاحظة',style:const TextStyle(fontSize:11,color:Color(0xff8b99b0))),
          ]),
          const SizedBox(height:11),
          TextField(controller:_noteController, minLines:3, maxLines:5,maxLength:1500,
            decoration:InputDecoration(hintText:'ماذا تريد أن تتذكر اليوم؟',
              filled:true, fillColor:_dark?const Color(0xff223250):const Color(0xfff7f8fc),
              border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none))),
          const SizedBox(height:6),
          FilledButton.icon(onPressed:(){
            final value=_noteController.text.trim();
            if(value.isEmpty){_toast('اكتب ملاحظتك أولاً');return;}
            setState((){_notes.insert(0,value);_noteController.clear();});
            _saveNotes();
            FocusManager.instance.primaryFocus?.unfocus();
          },icon:const Icon(Icons.add_rounded),label:const Text('حفظ الملاحظة')),
        ]))),
      const SizedBox(height:14),
      TextField(onChanged:(text)=>setState(()=>_noteFilter=text),
        decoration:InputDecoration(prefixIcon:const Icon(Icons.search),
          hintText:'ابحث في ملاحظاتك',filled:true,
          border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none))),
      const SizedBox(height:9),
      if(_notes.isEmpty) Padding(padding:const EdgeInsets.all(35),child:Column(children:[
        Icon(Icons.note_alt_outlined,size:43,color:_accent),
        const SizedBox(height:13),
        const Text('ابدأ بإضافة أول ملاحظة',textAlign:TextAlign.center),
      ])) else LayoutBuilder(builder:(context,constraints)=>GridView.builder(
        shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
        itemCount:visible.length,
        gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:constraints.maxWidth>600?3:2,
          crossAxisSpacing:11,mainAxisSpacing:11,mainAxisExtent: _compact?165:194),
        itemBuilder:(ctx,i){
          final index=visible[i].key;
          return Material(color:colors[index%colors.length],borderRadius:BorderRadius.circular(21),
            child:InkWell(onTap:()=>_editNote(index:index),borderRadius:BorderRadius.circular(21),
              child:Padding(padding:const EdgeInsets.all(13),child:Column(
                crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Row(children:[
                    const Icon(Icons.push_pin_outlined,color:Color(0xff92755f),size:17),
                    const Spacer(),
                    IconButton(tooltip:'تعديل',visualDensity:VisualDensity.compact,
                      onPressed:()=>_editNote(index:index),
                      icon:const Icon(Icons.edit_outlined,color:ink,size:17)),
                    IconButton(tooltip:'حذف',visualDensity:VisualDensity.compact,
                      onPressed:()=>_confirmDeleteNote(index),
                      icon:const Icon(Icons.delete_outline,color:ink,size:17)),
                  ]),
                  Expanded(child:Text(visible[i].value,maxLines:_compact?4:6,
                    overflow:TextOverflow.ellipsis,style:const TextStyle(
                      fontSize:12.5,fontWeight:FontWeight.w700,height:1.6,color:ink))),
                  const Text('اضغط للتعديل',style:TextStyle(fontSize:10,color:Color(0xff7e8b9d))),
                ])),
            ));
        },
      )),
    ]);
  }

  Future<void> _confirmDeleteNote(int index) async {
    final ctx=_navigator.currentContext;
    if(ctx==null)return;
    final confirmed=await showDialog<bool>(context:ctx,builder:(dialog)=>AlertDialog(
      title:const Text('حذف الملاحظة؟'),
      content:const Text('سيتم حذفها من هذا الهاتف فقط.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(dialog,false),child:const Text('إلغاء')),
        FilledButton(onPressed:()=>Navigator.pop(dialog,true),child:const Text('حذف'))],
    ));
    if(confirmed!=true||!mounted)return;
    setState(()=>_notes.removeAt(index));
    await _saveNotes();
  }

  Widget _settingsPanel(String title,String sub,List<Widget> children,{IconData icon=Icons.tune_rounded}) =>
    Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[
          _iconTile(icon,_accent,size:41),const SizedBox(width:10),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:14)),
            Text(sub,style:const TextStyle(color:Color(0xff8a97ae),fontSize:11)),
          ])),
        ]),
        const Divider(height:22),
        ...children,
      ])));

  Widget _settingsPage() {
    const colors=[Color(0xff496af2),Color(0xff8e59cc),Color(0xff13a993),
      Color(0xffe37f62),Color(0xff4c8fb4),Color(0xffdb6992)];
    return ListView(padding:const EdgeInsets.fromLTRB(16,7,16,30),children:[
      _title('الإعدادات','خصص مكتبتك بطريقة مريحة ومنظمة'),
      _settingsPanel('المظهر والألوان','هوية المكتبة على هذا الجهاز فقط',[
        SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,
          secondary:Icon(_dark?Icons.dark_mode:Icons.light_mode_outlined,color:_accent),
          title:const Text('الوضع الليلي'),subtitle:const Text('حفظ المظهر بعد إغلاق التطبيق'),
          value:_dark,onChanged:(v){setState(()=>_dark=v);_prefs.setBool(_prefsDark,v);}),
        const SizedBox(height:8),
        const Text('ألوان الواجهة والبطاقة الرئيسية',
          style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),
        const SizedBox(height:10),
        Wrap(spacing:9,runSpacing:9,children:colors.asMap().entries.map((entry){
          final color=entry.value;
          final selected=_accent==color;
          const names=['أزرق','بنفسجي','أخضر','مرجاني','سماوي','وردي'];
          return Tooltip(message:names[entry.key],child:InkWell(
            onTap:(){setState(()=>_accent=color);_prefs.setInt(_prefsAccent,color.toARGB32());},
            borderRadius:BorderRadius.circular(15),
            child:AnimatedContainer(duration:const Duration(milliseconds:160),
              width:64,height:72,padding:const EdgeInsets.all(6),
              decoration:BoxDecoration(
                color:selected?color.withValues(alpha:.13):(_dark?const Color(0xff223450):Colors.white),
                borderRadius:BorderRadius.circular(15),
                border:Border.all(color:selected?color:(_dark?Colors.white24:const Color(0xffE6EAF4)),
                  width:selected?2.5:1)),
              child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                Container(width:34,height:34,
                  decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(11)),
                  child:selected?const Icon(Icons.check_rounded,color:Colors.white,size:20):null),
                const SizedBox(height:4),
                Text(names[entry.key],style:const TextStyle(fontSize:10,fontWeight:FontWeight.w800)),
              ]),
            ),
          ));
        }).toList()),
        const SizedBox(height:13),
        const Text('حجم الكتابة',style:TextStyle(fontWeight:FontWeight.w800,fontSize:12)),
        Row(children:[
          const Icon(Icons.text_fields,size:19),
          Expanded(child:Slider(value:_fontScale,min:.9,max:1.25,divisions:7,
            label:'${(_fontScale*100).round()}%',onChanged:(v){
              setState(()=>_fontScale=v);_prefs.setDouble(_prefsScale,v);
            })),
          Text('${(_fontScale*100).round()}%',style:const TextStyle(fontWeight:FontWeight.w800)),
        ]),
        SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,
          secondary:Icon(Icons.view_compact_outlined,color:_accent),
          title:const Text('بطاقات مدمجة'),subtitle:const Text('تقليل ارتفاع بعض البطاقات'),
          value:_compact,onChanged:(v){setState(()=>_compact=v);_prefs.setBool(_prefsCompact,v);}),
        SwitchListTile.adaptive(contentPadding:EdgeInsets.zero,
          secondary:Icon(Icons.motion_photos_off_outlined,color:_accent),
          title:const Text('تقليل الحركة'),subtitle:const Text('تقليل مؤثرات الانتقال'),
          value:_noMotion,onChanged:(v){setState(()=>_noMotion=v);_prefs.setBool(_prefsNoMotion,v);}),
      ],icon:Icons.palette_outlined),
      const SizedBox(height:13),
      _settingsPanel('الكتب والمزامنة','تابع أحدث إصدارات فهرس المكتبة',[ 
        ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(Icons.cloud_sync_outlined,color:_accent),
          title:const Text('آخر مزامنة'),
          subtitle:Text(_syncError==null?(_lastSync==null?'لم تتم المزامنة بعد':
            '${_lastSync!.year}/${_lastSync!.month}/${_lastSync!.day}  ${_lastSync!.hour}:${_lastSync!.minute.toString().padLeft(2,'0')}'):
            'خطأ في الاتصال: $_syncError',maxLines:3),
          trailing:IconButton(onPressed:_syncing?null:()=>_refresh(notify:true),
            icon:const Icon(Icons.refresh))),
        const Divider(height:1),
        ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(Icons.auto_stories_outlined,color:_accent),
          title:const Text('الفهرس الحالي'),
          subtitle:Text('الإصدار ${_catalog?.revision??0} • ${_visibleStages().length} مراحل • ${_visibleBooks().length} كتاباً')),
        const Divider(height:1),
        const ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(Icons.wifi_off_outlined),
          title:Text('التصفح دون إنترنت'),
          subtitle:Text('تبقى قائمة الكتب والملاحظات والمفضلة محفوظة محلياً. القراءة دون إنترنت تتطلب تنزيل الكتاب.')),
      ],icon:Icons.cloud_done_outlined),
      const SizedBox(height:13),
      _settingsPanel('بياناتي الشخصية','محفوظة على هاتفك ولا تُرسل إلى المدير',[
        ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(Icons.favorite_outline,color:_accent),
          title:const Text('المفضلة'),subtitle:Text('${_favorites.length} كتاباً')),
        ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(Icons.sticky_note_2_outlined,color:_accent),
          title:const Text('الملاحظات'),subtitle:Text('${_notes.length} ملاحظة')),
      ],icon:Icons.lock_person_outlined),
    ]);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _searchController.dispose();
    _noteController.dispose();
    super.dispose();
  }
}

/// Optional reduced-motion route transitions for readers sensitive to animation.
class _InstantPageTransitionsBuilder extends PageTransitionsBuilder {
  const _InstantPageTransitionsBuilder();
  @override
  Widget buildTransitions<T>(PageRoute<T> route, BuildContext context,
      Animation<double> animation, Animation<double> secondaryAnimation, Widget child) => child;
}
