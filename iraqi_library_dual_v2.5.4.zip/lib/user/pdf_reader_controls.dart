import 'package:flutter/material.dart';

/// Compact reader controls with a bounded height and safe-area padding.
class PdfReaderControls extends StatefulWidget {
  static const double toolbarHeight = 56;

  final bool darkMode;
  final int pageNumber;
  final int pageCount;
  final ValueChanged<int> onPreviewPage;
  final ValueChanged<int> onGoToPage;
  final VoidCallback onShowThumbnails;

  const PdfReaderControls({
    super.key,
    this.darkMode = false,
    required this.pageNumber,
    required this.pageCount,
    required this.onPreviewPage,
    required this.onGoToPage,
    required this.onShowThumbnails,
  });

  @override
  State<PdfReaderControls> createState() => _PdfReaderControlsState();
}

class _PdfReaderControlsState extends State<PdfReaderControls> {
  // Keep a drag preview locally: the real page updates only when released.
  // This avoids a stream of PDF viewer rebuilds and makes the slider usable.
  int? _previewPage;

  @override
  void didUpdateWidget(covariant PdfReaderControls oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.pageCount != widget.pageCount) _previewPage = null;
  }

  @override
  Widget build(BuildContext context) {
    final pageCount = widget.pageCount;
    final ready = pageCount > 0;
    final maxPage = ready ? pageCount : 1;
    final current = (_previewPage ?? widget.pageNumber).clamp(1, maxPage).toInt();
    final progress = maxPage <= 1 ? 0.0 : (current - 1) / (maxPage - 1);
    return SafeArea(
      top: false,
      child: Container(
        // Scaffold gives its bottom bar the available screen height. A Slider
        // inside a Row consumes that height unless we explicitly bound it.
        // Keep this constraint even while the document is still loading.
        height: PdfReaderControls.toolbarHeight,
        padding: const EdgeInsets.fromLTRB(10, 3, 10, 4),
        decoration: BoxDecoration(
          color: widget.darkMode ? const Color(0xFF17253B) : Colors.white,
          border: Border(top: BorderSide(color: widget.darkMode
            ? Colors.white24 : const Color(0xFF10253F).withValues(alpha: .08))),
          boxShadow: [BoxShadow(color: const Color(0xFF10253F).withValues(alpha: .08), blurRadius: 18, offset: const Offset(0, -5))],
        ),
        child: Row(children: [
          _CompactPageButton(
            darkMode: widget.darkMode,
            tooltip: 'الصفحة السابقة',
            icon: Icons.chevron_right_rounded,
            onPressed: ready && current > 1 ? () => widget.onGoToPage(current - 1) : null,
          ),
          const SizedBox(width: 4),
          OutlinedButton.icon(
            onPressed: ready ? widget.onShowThumbnails : null,
            icon: const Icon(Icons.grid_view_rounded, size: 16),
            label: Text(
              ready ? '$current / $pageCount' : '…',
              textDirection: TextDirection.ltr,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: widget.darkMode ? Colors.white : const Color(0xFF10253F),
              backgroundColor: widget.darkMode ? const Color(0xFF283A53) : const Color(0xFFF5F8FB),
              side: BorderSide(color: widget.darkMode ? Colors.white24
                : const Color(0xFF10253F).withValues(alpha: .10)),
              shape: const StadiumBorder(),
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
              visualDensity: VisualDensity.compact,
            ),
          ),
          const SizedBox(width: 5),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                trackHeight: 3,
                activeTrackColor: const Color(0xFF16A89A),
                inactiveTrackColor: widget.darkMode ? Colors.white30
                  : const Color(0xFF10253F).withValues(alpha: .10),
                thumbColor: const Color(0xFF16A89A),
                overlayColor: const Color(0xFF16A89A).withValues(alpha: .10),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 13),
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                trackShape: const RoundedRectSliderTrackShape(),
              ),
              child: Slider(
                min: 1,
                max: maxPage.toDouble(),
                divisions: maxPage > 1 ? maxPage - 1 : null,
                value: current.toDouble(),
                onChanged: maxPage > 1 ? (value) {
                  final page = value.round();
                  if (page != _previewPage) {
                    setState(() => _previewPage = page);
                    widget.onPreviewPage(page);
                  }
                } : null,
                onChangeEnd: maxPage > 1 ? (value) {
                  final page = value.round();
                  setState(() => _previewPage = null);
                  widget.onGoToPage(page);
                } : null,
              ),
            ),
          ),
          SizedBox(
            width: 38,
              child: Text('${(progress * 100).round()}%', textAlign: TextAlign.center,
                style: TextStyle(color: widget.darkMode ? const Color(0xFF66E3CB)
                  : const Color(0xFF087C72), fontSize: 11, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 3),
          _CompactPageButton(
            darkMode: widget.darkMode,
            tooltip: 'الصفحة التالية',
            icon: Icons.chevron_left_rounded,
            onPressed: ready && current < pageCount ? () => widget.onGoToPage(current + 1) : null,
          ),
        ]),
      ),
    );
  }
}

class _CompactPageButton extends StatelessWidget {
  final bool darkMode;
  final String tooltip;
  final IconData icon;
  final VoidCallback? onPressed;

  const _CompactPageButton({required this.darkMode,
    required this.tooltip, required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: tooltip,
        onPressed: onPressed,
        icon: Icon(icon, size: 21),
        style: IconButton.styleFrom(
          minimumSize: const Size(34, 34),
          maximumSize: const Size(34, 34),
          padding: EdgeInsets.zero,
          backgroundColor: darkMode ? const Color(0xFF244B53)
            : const Color(0xFF16A89A).withValues(alpha: .09),
          foregroundColor: darkMode ? const Color(0xFF83F1DD) : const Color(0xFF087C72),
          disabledForegroundColor: darkMode ? Colors.white38 : const Color(0xFF9AA6B2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
        ),
      );
}
