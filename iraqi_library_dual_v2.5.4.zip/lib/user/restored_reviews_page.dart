import 'package:flutter/material.dart';

import '../models/library_catalog.dart';
import 'review_session.dart';

/// Review layout and controls restored from the first application; does not
/// replace the modern native navigation, settings or administrator functions.
class RestoredReviewsPage extends StatefulWidget {
  const RestoredReviewsPage({
    super.key,
    required this.catalog,
    required this.grades,
    required this.subjects,
    required this.books,
    required this.accent,
    required this.reduceMotion,
  });
  final LibraryCatalog catalog;
  final List<Map<String, dynamic>> grades;
  final List<Map<String, dynamic>> subjects;
  final List<Map<String, dynamic>> books;
  final Color accent;
  final bool reduceMotion;

  @override
  State<RestoredReviewsPage> createState() => _RestoredReviewsPageState();
}

class _RestoredReviewsPageState extends State<RestoredReviewsPage> {
  String? _gradeId;
  final Set<String> _selectedBooks = {};
  List<ReviewCardEntry> _cards = [];
  int _index = 0;
  bool _flipped = false;

  Map<String, dynamic>? _selectedGrade() {
    for (final g in widget.grades) {
      if (g['id'] == _gradeId) return g;
    }
    return null;
  }

  Map<String, dynamic>? _subjectFor(Map<String, dynamic> book) {
    for (final s in widget.subjects) {
      if (s['id'] == book['subjectId']) return s;
    }
    return null;
  }

  List<Map<String, dynamic>> _gradeBooks() => widget.books.where((book) {
    final subject = _subjectFor(book);
    return subject != null && subject['gradeId'] == _gradeId;
  }).toList();

  @override
  void initState() {
    super.initState();
    if (widget.grades.isNotEmpty) {
      _gradeId = widget.grades.first['id'].toString();
      _selectAllForGrade();
    }
  }

  @override
  void didUpdateWidget(covariant RestoredReviewsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.grades.isEmpty) return;
    if (_selectedGrade() == null) {
      _gradeId = widget.grades.first['id'].toString();
      _selectAllForGrade();
    }
  }

  void _selectAllForGrade() {
    _selectedBooks
      ..clear()
      ..addAll(_gradeBooks().map((b) => b['id'].toString()));
    _createCards();
  }

  void _createCards() {
    final grade = _selectedGrade();
    _cards = grade == null ? [] : createReviewSession(
      grade: LibraryCatalog.name(grade),
      selectedBooks: _gradeBooks().where((b) => _selectedBooks.contains(b['id'])).toList(),
      subjects: widget.subjects,
      adminQuestions: widget.catalog.reviews,
    );
    _index = 0;
    _flipped = false;
  }

  Color _subjectColor(String name) {
    if (name.contains('رياضيات')) return const Color(0xFF3184D9);
    if (name.contains('إنكليزية') || name.contains('انكليزي')) return const Color(0xFF8B58D4);
    if (name.contains('علوم') || name.contains('أحياء')) return const Color(0xFF0FA891);
    if (name.contains('إسلامية')) return const Color(0xFF0E9989);
    if (name.contains('عربية') || name == 'القواعد') return const Color(0xFFE38A34);
    return widget.accent;
  }

  @override
  Widget build(BuildContext context) {
    final books = _gradeBooks();
    final current = _cards.isEmpty ? null : _cards[_index];
    final active = _subjectColor(current?.subjectName ?? '');
    final answer = current == null ? '' : current.question.choices[current.question.answer];
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 10, 16, 28), children: [
      const Text('مراجعة مواد صفّك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 5),
      Text('اختر الكتب التي تريد مراجعتها؛ ستتجدد الأسئلة وترتيب الإجابات مع كل جلسة.',
        style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(
        key: ValueKey('review_grade_${_gradeId ?? ''}'),
        initialValue: _gradeId,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'الصف الدراسي', border: OutlineInputBorder()),
        items: widget.grades.map((g) => DropdownMenuItem(
          value: g['id'].toString(), child: Text(LibraryCatalog.name(g)))).toList(),
        onChanged: (id) {
          if (id != null) {
            setState(() {
              _gradeId = id;
              _selectAllForGrade();
            });
          }
        },
      ),
      const SizedBox(height: 14),
      Card(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(14, 12, 14, 9),
          child: Row(children: [
            Icon(Icons.menu_book_rounded, color: widget.accent),
            const SizedBox(width: 9),
            const Expanded(child: Text('كتب المراجعة', style: TextStyle(fontWeight: FontWeight.w900))),
            Text('${_selectedBooks.length} / ${books.length}', style: TextStyle(fontSize: 12, color: muted)),
          ])),
        const Divider(height: 1),
        if (books.isEmpty) const Padding(padding: EdgeInsets.all(16),
          child: Text('لا توجد كتب لهذا الصف حالياً.')),
        ...books.map((book) {
          final subject = _subjectFor(book);
          final name = LibraryCatalog.name(subject ?? {});
          final color = _subjectColor(name);
          return CheckboxListTile(
            dense: true,
            controlAffinity: ListTileControlAffinity.leading,
            value: _selectedBooks.contains(book['id']),
            onChanged: (selected) => setState(() {
              if (selected == true) { _selectedBooks.add(book['id'].toString()); }
              else { _selectedBooks.remove(book['id'].toString()); }
              _createCards();
            }),
            secondary: Container(
              width: 37, height: 37,
              decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(11)),
              child: Icon(Icons.auto_stories_outlined, color: color, size: 20)),
            title: Text(LibraryCatalog.name(book), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
            subtitle: Text(name, style: TextStyle(fontSize: 11, color: color)),
          );
        }),
        Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 9),
          child: Row(children: [
            Expanded(child: TextButton.icon(
              onPressed: books.isEmpty ? null : () => setState(_selectAllForGrade),
              icon: const Icon(Icons.done_all_rounded, size: 17), label: const Text('تحديد الكل'))),
            Expanded(child: TextButton.icon(
              onPressed: _selectedBooks.isEmpty ? null : () => setState(() {
                _selectedBooks.clear(); _createCards();
              }), icon: const Icon(Icons.remove_done_rounded, size: 17), label: const Text('إلغاء التحديد'))),
          ]),
        ),
      ])),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('جلسة المراجعة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          Text('${_cards.length} بطاقة من الكتب المحددة', style: TextStyle(color: muted, fontSize: 12)),
        ])),
        FilledButton.icon(
          onPressed: _selectedBooks.isEmpty ? null : () => setState(_createCards),
          icon: const Icon(Icons.shuffle_rounded, size: 18), label: const Text('جلسة جديدة')),
      ]),
      const SizedBox(height: 14),
      if (current == null) Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
        const Icon(Icons.style_outlined, size: 42),
        const SizedBox(height: 10),
        Text(_selectedBooks.isEmpty ? 'اختر كتاباً لبدء المراجعة' : 'لا تتوفر أسئلة تدريبية لهذه الكتب',
          textAlign: TextAlign.center),
      ]))) else ...[
        Row(children: [
          Expanded(child: Text('البطاقة ${_index + 1} من ${_cards.length}', style: const TextStyle(fontWeight: FontWeight.w800))),
          Flexible(child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
            decoration: BoxDecoration(color: active.withValues(alpha: .10), borderRadius: BorderRadius.circular(10)),
            child: Text(current.subjectName, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: active)),
          )),
        ]),
        const SizedBox(height: 5),
        Text(current.bookTitle, style: TextStyle(fontSize: 12, color: muted)),
        const SizedBox(height: 9),
        ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(
          value: (_index + 1) / _cards.length, minHeight: 6, color: active)),
        const SizedBox(height: 15),
        GestureDetector(
          onTap: () => setState(() => _flipped = !_flipped),
          child: AnimatedSwitcher(
            duration: widget.reduceMotion ? Duration.zero : const Duration(milliseconds: 260),
            transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
            child: Container(
              key: ValueKey('${_index}_${_flipped}_${current.bookId}_${current.question.text}'),
              width: double.infinity,
              constraints: const BoxConstraints(minHeight: 275),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
                  colors: _flipped
                      ? [const Color(0xFFE0F7EF), const Color(0xFFCCF0E6)]
                      : [const Color(0xFFE5ECFF), const Color(0xFFF2F5FF)]),
                borderRadius: BorderRadius.circular(27),
                border: Border.all(color: (_flipped ? const Color(0xFF0FA891) : active).withValues(alpha: .25)),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(_flipped ? Icons.check_circle_rounded : Icons.style_rounded,
                  size: 36, color: _flipped ? const Color(0xFF0FA891) : active),
                const SizedBox(height: 17),
                Text(_flipped ? 'الإجابة' : 'السؤال', style: TextStyle(
                  color: _flipped ? const Color(0xFF0FA891) : active, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Text(_flipped ? answer : current.question.text,
                  textAlign: TextAlign.center, style: const TextStyle(
                    fontSize: 21, color: Color(0xFF24334B), fontWeight: FontWeight.w900, height: 1.5)),
                const SizedBox(height: 20),
                const Text('اضغط على البطاقة لقلبها', style: TextStyle(color: Color(0xFF60738B), fontSize: 12)),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            onPressed: _index == 0 ? null : () => setState(() { _index--; _flipped = false; }),
            icon: const Icon(Icons.chevron_right_rounded), label: const Text('السابقة'))),
          const SizedBox(width: 7),
          Expanded(child: FilledButton.icon(
            onPressed: () => setState(() => _flipped = !_flipped),
            icon: const Icon(Icons.flip_rounded), label: const Text('اقلب البطاقة'))),
          const SizedBox(width: 7),
          Expanded(child: OutlinedButton.icon(
            onPressed: _index == _cards.length - 1 ? null : () => setState(() {
              _index++; _flipped = false;
            }), icon: const Icon(Icons.chevron_left_rounded), label: const Text('التالية'))),
        ]),
      ],
      const SizedBox(height: 16),
      Text('أسئلة تدريبية لمساعدتك على التذكر؛ راجع الكتاب الوزاري أيضاً.',
        textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11)),
    ]);
  }
}
