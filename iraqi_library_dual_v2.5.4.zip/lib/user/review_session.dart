import 'dart:math';

import '../models/library_catalog.dart';
import 'review_bank.dart';

/// A review card retains the original book title and subject, just as in the
/// first Iraqi Curriculum Library. The catalog (including admin-added books)
/// remains the sole source for the grade/subject/book relationships.
class ReviewCardEntry {
  final String bookId;
  final String bookTitle;
  final String subjectName;
  final QuizQuestion question;

  const ReviewCardEntry({
    required this.bookId,
    required this.bookTitle,
    required this.subjectName,
    required this.question,
  });
}

List<ReviewCardEntry> createReviewSession({
  required String grade,
  required List<Map<String, dynamic>> selectedBooks,
  required List<Map<String, dynamic>> subjects,
  required List<Map<String, dynamic>> adminQuestions,
  Random? random,
}) {
  final rng = random ?? Random();
  final bySubject = {for (final s in subjects) s['id'].toString(): s};
  final cards = <ReviewCardEntry>[];
  final processedSubjects = <String>{};
  final seenPrompts = <String>{};
  for (final book in selectedBooks) {
    final subjectId = book['subjectId']?.toString();
    if (subjectId == null || !processedSubjects.add(subjectId)) continue;
    final subject = bySubject[subjectId];
    if (subject == null) continue;
    final subjectName = LibraryCatalog.name(subject);
    // Preserve the original built-in bank even when an administrator adds new
    // questions. The previous implementation dropped it on first custom Q.
    final originalQuestions = makeQuizQuestions(grade, subjectName)..shuffle(rng);
    final customQuestions = <QuizQuestion>[
      for (final raw in adminQuestions.where((q) => q['subjectId'] == subjectId))
        if (raw['choices'] is List && raw['answer'] is int &&
            (raw['answer'] as int) >= 0 &&
            (raw['answer'] as int) < (raw['choices'] as List).length)
          _questionFromCatalog(raw, grade, subjectName, rng),
    ]..shuffle(rng);
    // Reserve some places for published manager questions, otherwise an 8-card
    // draw from a 120-question maths bank would almost never display them.
    final questions = <QuizQuestion>[
      ...customQuestions.take(4),
      ...originalQuestions,
      ...customQuestions.skip(4),
    ];
    var accepted = 0;
    for (final question in questions) {
      if (!seenPrompts.add(question.text.trim())) continue;
      cards.add(ReviewCardEntry(
        bookId: book['id'].toString(),
        bookTitle: LibraryCatalog.name(book),
        subjectName: subjectName,
        question: question,
      ));
      accepted++;
      if (accepted == 8) break; // First application's per-subject limit.
    }
  }
  cards.shuffle(rng);
  return cards.take(60).toList(); // First application's full-session limit.
}

QuizQuestion _questionFromCatalog(
    Map<String, dynamic> raw, String grade, String subject, Random rng) {
  final options = List<String>.from(raw['choices'] as List);
  final correct = options[raw['answer'] as int];
  options.shuffle(rng);
  return QuizQuestion(
    (raw['text'] ?? '').toString(), options, options.indexOf(correct),
    grade: grade, subject: subject, difficulty: 'متوسط',
    source: 'أسئلة أضافها مدير المكتبة',
  );
}
