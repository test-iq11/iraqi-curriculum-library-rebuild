#!/usr/bin/env python3
"""Static guards for item colors, dashboard theme, dark toolbar and natural PDF pages."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
model=(root/'lib/models/library_catalog.dart').read_text()
manager=(root/'lib/admin/admin_library_app.dart').read_text()
user=(root/'lib/user/user_library_app.dart').read_text()
reader=(root/'lib/user/book_pdf_screen.dart').read_text()
controls=(root/'lib/user/pdf_reader_controls.dart').read_text()
for token in ("subject['color'] != null", "book['color'] != null"):
    assert token in model, token
for token in ("edited['color'] = result['color']", "type == 'subject' || type == 'book'", 'colorNames[hex]', '_editorDefaultColor'):
    assert token in manager, token
for token in ("_color(book['color']", "_color(item['color'], parentAccent)", 'Color.lerp(_accent,', 'ألوان الواجهة والبطاقة الرئيسية'):
    assert token in user, token
for token in ('_readerNightKey', 'darkMode: _readerNight', 'RepaintBoundary(child: _buildDocumentViewer())'):
    assert token in reader, token
assert 'ColorFiltered(' not in reader and '_nightPagesFilter' not in reader
for token in ('final bool darkMode;', 'widget.darkMode ? Colors.white', 'const Color(0xFF17253B)'):
    assert token in controls, token
print('PASS: colors, themed dashboard, dark UI while original PDF page colors remain unchanged')
