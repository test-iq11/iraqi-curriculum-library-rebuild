#!/usr/bin/env python3
"""Reader speed, gesture physics and original controls regression guard."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
reader = (root/'lib/user/book_pdf_screen.dart').read_text(encoding='utf-8')
controls = (root/'lib/user/pdf_reader_controls.dart').read_text(encoding='utf-8')
for token in (
    'scrollPhysics: const _FastBookScrollPhysics()',
    'static const double dragSpeed = 2.2',
    'static const double flingSpeed = 1.8',
    'super.applyPhysicsToUserOffset(position, offset) * dragSpeed',
    'super.createBallisticSimulation(position, velocity * flingSpeed)',
    'verticalCacheExtent: 1.0',
    'enableLowResolutionPagePreview: true',
    'partialImageLoadingDelay: Duration(milliseconds: 90)',
    'loadPageDimensionsOnDemand: true',
    'PdfViewerScrollThumb(',
    'orientation: ScrollbarOrientation.left',
    'PdfViewer.file(', 'PdfViewer.uri(',
    '_showBookSearch', '_showThumbnails', '_showContents',
    '_showQuickAccess', '_toggleBookmark', '_addNote', '_saveProgressTimer',
):
    assert token in reader, f'PDF regression: {token}'
for token in ('extends StatefulWidget', 'int? _previewPage', 'onChangeEnd:',
              'widget.onGoToPage(page)', 'widget.onPreviewPage(page)',
              'static const double toolbarHeight = 56'):
    assert token in controls, f'PDF controls regression: {token}'
print('PASS: accelerated drag/fling and intact navigation, search, notes and bookmarks')
