#!/usr/bin/env python3
"""Source-level guards. flutter analyze + flutter test are authoritative."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
reader = (root/'lib/user/book_pdf_screen.dart').read_text()
manager = (root/'lib/admin/admin_library_app.dart').read_text()
repo = (root/'lib/services/library_repository.dart').read_text()
merger = (root/'lib/models/catalog_merge.dart').read_text()
assert 'ColorFiltered(' not in reader, 'PDF page pixels must not be inverted in dark mode'
assert '_nightPagesFilter' not in reader, 'Do not recolor the textbook'
assert 'scrollPhysics: const _FastBookScrollPhysics()' in reader
assert 'dragSpeed = 2.2' in reader
assert 'flingSpeed = 1.8' in reader
for token in ['_FastBookScrollPhysics applyTo(', 'applyPhysicsToUserOffset(', 'createBallisticSimulation(']:
    assert token in reader, token
for token in ['CatalogMerger.merge(', '_confirmOverlappingChanges(', 'await _publisher.fetch();',
              'await _repo.saveDraft(pending, base: latest.catalog!)', '_repo.markPublished(published)']:
    assert token in manager, token
assert 'if (_remoteConflict) {' not in manager, 'Never block publishing without a conflict review'
for token in ['loadDraftBase()', 'saveDraft(LibraryCatalog value, {LibraryCatalog? base})', "static const _baseKey"]:
    assert token in repo, token
assert 'preferLocalConflicts: true' in manager
assert 'class CatalogMerger' in merger
assert (root/'test/catalog_merge_test.dart').exists()
print('PASS: three-way catalog merge with confirmation, persisted baseline, unmodified PDF pages and amplified touch scrolling')
