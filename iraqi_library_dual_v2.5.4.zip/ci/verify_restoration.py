#!/usr/bin/env python3
"""Offline regression guard for source files that used to disappear between releases."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
bank = (root / 'lib/user/review_bank.dart').read_text(encoding='utf-8')
reader = (root / 'lib/user/book_pdf_screen.dart').read_text(encoding='utf-8')
app = (root / 'lib/user/user_library_app.dart').read_text(encoding='utf-8')
reviews = (root / 'lib/user/restored_reviews_page.dart').read_text(encoding='utf-8')
expected = {
    'الإسلامية': 18, 'الأخلاقية': 12, 'اللغة العربية': 22,
    'اللغة الإنكليزية': 22, 'أدب الإنكليزي': 14, 'العلوم': 16,
    'الاجتماعيات': 15, 'الحاسوب': 15, 'الفيزياء': 15,
    'الكيمياء': 15, 'الأحياء': 15, 'التاريخ': 12,
    'الجغرافية': 15, 'الاقتصاد': 15, 'علم الاجتماع': 12,
    'الفلسفة': 12, 'علم الأرض': 12, 'جرائم البعث': 10,
}
part = bank.split('final pools = ', 1)[1].split('final subjectPool =', 1)[0]
actual = {}
headers = list(re.finditer(r"^    '([^']+)': \[\n", part, re.MULTILINE))
for i, header in enumerate(headers):
    segment = part[header.end():headers[i+1].start() if i+1<len(headers) else len(part)]
    actual[header.group(1)] = len(re.findall(r"^      \['", segment, re.MULTILINE))
assert actual == expected, f'Restored bank mismatch: {actual}'
assert sum(actual.values()) == 267
for f in ('class BookPdfScreen', 'PdfViewer.file(', 'PdfViewer.uri(',
          'onPageChanged: _onPageChanged', '_showThumbnails', '_showContents',
          '_showBookSearch', '_showQuickAccess', '_toggleBookmark',
          '_addNote', 'loadPageDimensionsOnDemand: true',
          'loadPagesProgressively()', 'Timer(const Duration(milliseconds: 700)',
          'errorBannerBuilder:'):
    assert f in reader, f'Missing reader feature: {f}'
assert 'RestoredReviewsPage(' in app
for f in ('CheckboxListTile(', 'LinearProgressIndicator(', 'AnimatedSwitcher(',
          'تحديد الكل', 'اقلب البطاقة'):
    assert f in reviews, f'Missing review feature: {f}'
assert 'return cards.take(60).toList()' in (root/'lib/user/review_session.dart').read_text()
print('PASS: 267 fixed questions in 18 subjects, 120 grade-based maths, legacy multi-book cards and complete PDF reader')
