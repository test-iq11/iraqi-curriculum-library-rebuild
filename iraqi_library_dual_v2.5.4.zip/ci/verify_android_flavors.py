#!/usr/bin/env python3
"""Prevent the 2.0.1 Android Gradle flavor-resource build regression."""
from pathlib import Path
import re
import hashlib
import struct

root = Path(__file__).resolve().parents[1]
gradle = root / 'android/app/build.gradle.kts'
manifest = root / 'android/app/src/main/AndroidManifest.xml'
assert gradle.is_file(), 'Run flutter create and tool/configure_android.py first'
s = gradle.read_text(encoding='utf-8')
m = manifest.read_text(encoding='utf-8')
assert re.search(r'\bbuildFeatures\s*\{[^}]*\bresValues\s*=\s*true\b', s), 'Missing buildFeatures { resValues = true }'
for flavor in ('user', 'admin'):
    assert s.count(f'create("{flavor}")') == 1, f'Missing/duplicate flavor: {flavor}'
assert s.count('resValue("string", "app_name"') == 2, 'Expected app names for both flavors'
assert 'android:label="@string/app_name"' in m, 'Missing flavor-specific application label'
assert 'android.permission.INTERNET' in m, 'Network permission missing'
assert 'android:icon="@mipmap/ic_launcher"' in m, 'Launcher icon resource not referenced in manifest'
assert 'android:roundIcon="@mipmap/ic_launcher"' in m, 'Round icon not configured correctly'
assert 'applicationId = "com.school.app.iraqi_curriculum_library"' in s
assert 'applicationId = "com.school.app.iraqi_curriculum_library.admin"' in s
for density in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
    hashes = []
    for flavor in ('user','admin'):
        source = root / 'tool/launcher_res' / flavor / f'mipmap-{density}' / 'ic_launcher.png'
        target = root / 'android/app/src' / flavor / 'res' / f'mipmap-{density}' / 'ic_launcher.png'
        assert source.is_file() and target.is_file(), f'Missing icon: {flavor}/{density}'
        expected_px = {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}[density]
        raw_png = target.read_bytes()
        assert raw_png[:8] == b'\x89PNG\r\n\x1a\n', f'Not a PNG: {flavor}/{density}'
        width, height = struct.unpack('>II', raw_png[16:24])
        assert (width, height) == (expected_px, expected_px), f'Wrong icon dimensions: {flavor}/{density}'
        original_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        installed_hash = hashlib.sha256(raw_png).hexdigest()
        assert original_hash == installed_hash, f'Wrong icon: {flavor}/{density}'
        hashes.append(installed_hash)
    assert hashes[0] != hashes[1], f'Flavors share the same launcher icon: {density}'
print('PASS: both Android flavors, generated string resources, and 10 distinct correct icons.')
