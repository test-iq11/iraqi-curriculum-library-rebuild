import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/pdf_reader_controls.dart';

void main() {
  // Exercise the real toolbar inside Scaffold: an unconstrained Slider used to
  // make bottomNavigationBar cover the screen and leave the PDF a zero-height body.
  for (final size in [const Size(320, 640), const Size(393, 851), const Size(800, 360)]) {
    for (final pageCount in [0, 120]) {
      testWidgets('reader keeps PDF visible at $size with $pageCount pages', (tester) async {
        tester.view.devicePixelRatio = 1;
        tester.view.physicalSize = size;
        tester.view.padding = const FakeViewPadding(bottom: 24);
        addTearDown(tester.view.resetDevicePixelRatio);
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetPadding);

        const bodyKey = ValueKey('pdf-viewport');
        await tester.pumpWidget(MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              appBar: AppBar(title: const Text('الكتاب')),
              body: const SizedBox.expand(key: bodyKey),
              bottomNavigationBar: PdfReaderControls(
                pageNumber: pageCount == 0 ? 1 : 25,
                pageCount: pageCount,
                onPreviewPage: (_) {},
                onGoToPage: (_) {},
                onShowThumbnails: () {},
              ),
            ),
          ),
        ));

        expect(tester.takeException(), isNull);
        final toolbar = tester.getRect(find.byType(PdfReaderControls));
        final body = tester.getRect(find.byKey(bodyKey));
        final header = tester.getRect(find.byType(AppBar));
        expect(toolbar.height, lessThanOrEqualTo(80));
        expect(toolbar.bottom, closeTo(size.height, .1));
        expect(body.height, greaterThan(size.height * .5));
        expect(body.top, greaterThanOrEqualTo(header.bottom));
        expect(body.bottom, lessThanOrEqualTo(toolbar.top + .1));
        expect(find.text('الكتاب').hitTestable(), findsOneWidget);
      });
    }
  }

  testWidgets('night reader controls have a dark surface and readable text', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(360, 740);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPhysicalSize);
    await tester.pumpWidget(MaterialApp(
      theme: ThemeData.dark(),
      home: Scaffold(
        body: const SizedBox.expand(),
        bottomNavigationBar: PdfReaderControls(
          darkMode: true,
          pageNumber: 81,
          pageCount: 120,
          onPreviewPage: (_) {},
          onGoToPage: (_) {},
          onShowThumbnails: () {},
        ),
      ),
    ));
    expect(find.text('81 / 120'), findsOneWidget);
    expect(tester.takeException(), isNull);
    final toolbar = tester.getRect(find.byType(PdfReaderControls));
    expect(toolbar.height, lessThanOrEqualTo(80));
  });

  testWidgets('slider previews instantly and navigates once when released', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(420, 800);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPhysicalSize);
    final previews = <int>[];
    final jumps = <int>[];
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: const SizedBox.expand(),
      bottomNavigationBar: PdfReaderControls(
        pageNumber: 1,
        pageCount: 200,
        onPreviewPage: previews.add,
        onGoToPage: jumps.add,
        onShowThumbnails: () {},
      ),
    )));
    final slider = find.byType(Slider);
    // Slider drag changes only the preview; the PDF jump waits for release.
    final gesture = await tester.startGesture(tester.getCenter(slider));
    await gesture.moveBy(const Offset(42, 0));
    await tester.pump();
    expect(previews, isNotEmpty);
    expect(jumps, isEmpty);
    expect(find.textContaining('/ 200'), findsOneWidget);
    await gesture.up();
    await tester.pump();
    expect(jumps, hasLength(1));
    expect(jumps.single, inInclusiveRange(1, 200));
    expect(tester.takeException(), isNull);
  });

}
