import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/review_bank.dart';
import 'package:iraqi_school_library_dual/user/review_session.dart';
import 'package:iraqi_school_library_dual/user/pdf_reader_controls.dart';

void main() {
  test('restore all original 267 fixed questions across 18 subject banks', () {
    const expected = <String, int>{
      'الإسلامية': 18, 'الأخلاقية': 12, 'اللغة العربية': 22,
      'اللغة الإنكليزية': 22, 'أدب الإنكليزي': 14,
      'العلوم': 16, 'الاجتماعيات': 15, 'الحاسوب': 15,
      'الفيزياء': 15, 'الكيمياء': 15, 'الأحياء': 15,
      'التاريخ': 12, 'الجغرافية': 15, 'الاقتصاد': 15,
      'علم الاجتماع': 12, 'الفلسفة': 12, 'علم الأرض': 12,
      'جرائم البعث': 10,
    };
    expect(expected.values.reduce((a, b) => a + b), 267);
    for (final item in expected.entries) {
      final questions = makeQuizQuestions('السادس العلمي', item.key);
      expect(questions.length, item.value, reason: '${item.key} has lost questions');
      expect(questions.map((q) => q.text).toSet().length, questions.length);
      for (final q in questions) {
        expect(q.choices, hasLength(4));
        expect(q.answer, inInclusiveRange(0, 3));
      }
    }
    expect(makeQuizQuestions('الأول الابتدائي', 'مادة غير موجودة'), isEmpty);
  });

  test('mathematics generator depends on grade and still creates 120 questions', () {
    final first = makeQuizQuestions('الأول الابتدائي', 'الرياضيات');
    final secondary = makeQuizQuestions('السادس العلمي', 'الرياضيات');
    expect(first.length, 120);
    expect(secondary.length, 120);
    expect(first.map((q) => q.text).toSet().length, 120);
    expect(secondary.map((q) => q.text).toSet().length, 120);
    expect(first.map((q) => q.text).toSet(), isNot(equals(secondary.map((q) => q.text).toSet())));
  });

  test('restored sessions support multiple books and merge admin questions', () {
    final subjects = <Map<String, dynamic>>[
      {'id':'math','name':'الرياضيات'}, {'id':'arabic','name':'اللغة العربية'},
    ];
    final books = <Map<String, dynamic>>[
      {'id':'math1','title':'كتاب الرياضيات','subjectId':'math'},
      {'id':'math2','title':'نشاط الرياضيات','subjectId':'math'},
      {'id':'arabic1','title':'كتاب القراءة','subjectId':'arabic'},
    ];
    final admin = <Map<String, dynamic>>[
      {'subjectId':'math','text':'سؤال خاص من المدير','choices':['نعم','لا'],'answer':0},
    ];
    final session = createReviewSession(
      grade: 'الرابع الابتدائي', selectedBooks: books,
      subjects: subjects, adminQuestions: admin, random: Random(1));
    expect(session, isNotEmpty);
    expect(session.length, lessThanOrEqualTo(60));
    expect(session.length, lessThanOrEqualTo(16));
    expect(session.map((e) => e.subjectName).toSet(), {'الرياضيات', 'اللغة العربية'});
    expect(session.map((e) => e.question.text).toSet().length, session.length);
    expect(session.any((e) => e.question.text == 'سؤال خاص من المدير'), isTrue);
  });

  testWidgets('reader compact toolbar leaves visible space for PDF viewport', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(360, 780);
    addTearDown(tester.view.resetDevicePixelRatio);
    addTearDown(tester.view.resetPhysicalSize);
    const key = ValueKey('pdf-viewport');
    await tester.pumpWidget(MaterialApp(home: Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('كتاب الرياضيات')),
        body: const SizedBox.expand(key: key),
        bottomNavigationBar: PdfReaderControls(
          pageNumber: 45, pageCount: 160,
          onPreviewPage: (_) {}, onGoToPage: (_) {},
          onShowThumbnails: () {},
        ),
      ),
    )));
    expect(tester.takeException(), isNull);
    expect(tester.getRect(find.byKey(key)).height, greaterThan(350));
    expect(tester.getRect(find.byType(PdfReaderControls)).height, lessThanOrEqualTo(80));
  });
}
