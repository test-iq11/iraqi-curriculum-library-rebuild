import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/models/library_catalog.dart';
import 'package:iraqi_school_library_dual/models/catalog_merge.dart';

LibraryCatalog sample() => LibraryCatalog.fromJson({
  'schemaVersion': 2,
  'revision': 1,
  'updatedAt': '2026-11-07T00:00:00Z',
  'stages': [
    {'id': 'stage1', 'name': 'ابتدائية', 'color': '#123456', 'order': 0},
  ],
  'grades': [
    {'id': 'grade1', 'stageId': 'stage1', 'name': 'الأول', 'color': '#123456', 'order': 0},
  ],
  'subjects': [
    {'id': 'subject1', 'gradeId': 'grade1', 'name': 'رياضيات', 'order': 0},
  ],
  'books': [
    {'id': 'book1', 'subjectId': 'subject1', 'title': 'الكتاب', 'order': 0},
  ],
});

void main() {
  test('remote revision or timestamp alone does not block manager edits', () {
    final base = sample();
    final local = base.copy();
    local.grades.first['color'] = '#998877';
    final remote = base.copy()
      ..revision = 14
      ..updatedAt = '2026-11-09T00:00:00Z';
    final result = CatalogMerger.merge(base: base, local: local, remote: remote);
    expect(result.conflicts, isEmpty);
    expect(result.catalog.grades.single['color'], '#998877');
    expect(result.catalog.revision, 14);
  });

  test('independent edits to the same item merge field by field', () {
    final base = sample();
    final local = base.copy();
    local.grades.first['color'] = '#998877';
    final remote = base.copy();
    remote.grades.first['name'] = 'الصف الأول';
    final result = CatalogMerger.merge(base: base, local: local, remote: remote);
    expect(result.conflicts, isEmpty);
    expect(result.catalog.grades.single['color'], '#998877');
    expect(result.catalog.grades.single['name'], 'الصف الأول');
  });

  test('locally added subject survives remote book addition', () {
    final base = sample();
    final local = base.copy()..subjects.add({
      'id': 'subject2', 'gradeId': 'grade1', 'name': 'علوم', 'order': 1,
    });
    final remote = base.copy()..books.add({
      'id': 'book2', 'subjectId': 'subject1', 'title': 'كتاب إضافي', 'order': 1,
    });
    final result = CatalogMerger.merge(base: base, local: local, remote: remote);
    expect(result.conflicts, isEmpty);
    expect(result.catalog.subjects.length, 2);
    expect(result.catalog.books.length, 2);
  });

  test('overlapping changes require explicit confirmation', () {
    final base = sample();
    final local = base.copy();
    local.grades.first['name'] = 'أولي';
    final remote = base.copy();
    remote.grades.first['name'] = 'الأول الابتدائي';
    final preview = CatalogMerger.merge(base: base, local: local, remote: remote);
    expect(preview.conflicts, isNotEmpty);
    expect(preview.catalog.grades.first['name'], 'الأول الابتدائي');
    final approved = CatalogMerger.merge(
      base: base, local: local, remote: remote, preferLocalConflicts: true,
    );
    expect(approved.catalog.grades.single['name'], 'أولي');
  });

  test('remote deletion and local change are flagged, not discarded', () {
    final base = sample();
    final local = base.copy();
    local.books.single['title'] = 'كتابي';
    final remote = base.copy()..books.clear();
    final preview = CatalogMerger.merge(base: base, local: local, remote: remote);
    expect(preview.hasConflicts, isTrue);
    final approved = CatalogMerger.merge(
      base: base, local: local, remote: remote, preferLocalConflicts: true,
    );
    expect(approved.catalog.books.single['title'], 'كتابي');
  });
}
