import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/models/library_catalog.dart';

Map<String, dynamic> seed() => {
  'schemaVersion': 2, 'revision': 1, 'updatedAt': '2026-11-07T00:00:00Z',
  'stages': [{'id':'s','name':'الابتدائية','color':'#123456','icon':'book','order':0}],
  'grades': [{'id':'g','stageId':'s','name':'الأول','color':'#123456','order':0}],
  'subjects': [{'id':'x','gradeId':'g','name':'رياضيات','order':0}],
  'books': [{'id':'b','subjectId':'x','title':'كتاب الرياضيات','url':'https://example.org/book.pdf','order':0}],
};

void main() {
  test('accepts nested stages, grades, subjects, books', () {
    final catalog = LibraryCatalog.fromJson(seed());
    expect(catalog.stageCount, 1);
    expect(catalog.bookCount, 1);
    expect(catalog.children('stage', 's').length, 1);
    expect(catalog.children('grade', 'g').length, 1);
    expect(catalog.children('subject', 'x').length, 1);
    expect(catalog.copy().toJson(), catalog.toJson());
  });
  test('adding a new stage allows new grades/subjects/books', () {
    final catalog = LibraryCatalog.fromJson(seed());
    catalog.stages.add({'id':'s2','name':'التدريب المهني','color':'#8B5CF6','icon':'book','order':1});
    catalog.grades.add({'id':'g2','stageId':'s2','name':'المستوى الأول','color':'#8B5CF6','order':1});
    catalog.subjects.add({'id':'sub2','gradeId':'g2','name':'الحاسوب','order':1});
    catalog.books.add({'id':'b2','subjectId':'sub2','title':'دليل الحاسوب','url':'https://example.org/new.pdf','order':1});
    catalog.validate();
    final roundTrip = LibraryCatalog.fromJson(jsonDecode(jsonEncode(catalog.toJson())) as Map<String, dynamic>);
    expect(roundTrip.books.length, 2);
    expect(roundTrip.children('stage', 's2').single['name'], 'المستوى الأول');
  });
  test('deleting parent cascades only on explicit call', () {
    final doc = LibraryCatalog.fromJson(seed());
    expect(doc.descendants('stage', 's'), 3);
    expect(doc.deleteTree('stage', 's'), 4);
    doc.validate();
    expect(doc.books, isEmpty);
  });
  test('rejects duplicate, dangling and unsafe links', () {
    final d = LibraryCatalog.fromJson(seed());
    d.books.first['url'] = 'javascript:alert(1)';
    expect(d.validate, throwsFormatException);
    d.books.first['url'] = 'https://example.org/book.pdf';
    d.grades.first['stageId'] = 'missing';
    expect(d.validate, throwsFormatException);
  });
  test('revisions are versioned and hidden items remain valid', () {
    final d = LibraryCatalog.fromJson(seed());
    d.books.first['visible'] = false;
    d.revision = 2;
    d.validate();
    expect(d.bookCount, 0);
  });
}
