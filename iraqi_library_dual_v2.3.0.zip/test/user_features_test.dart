import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/review_bank.dart';
import 'package:iraqi_school_library_dual/user/user_library_app.dart';

void main() {
  test('primary grade 3 and 4 have different school-themed icons', () {
    expect(IraqiLibraryUserApp.gradeIcon('الثالث الابتدائي'), Icons.straighten);
    expect(IraqiLibraryUserApp.gradeIcon('الرابع الابتدائي'), Icons.explore_outlined);
    expect(IraqiLibraryUserApp.gradeIcon('الثالث الابتدائي'),
      isNot(IraqiLibraryUserApp.gradeIcon('الرابع الابتدائي')));
    expect(IraqiLibraryUserApp.gradeIcon('مرحلة تدريبية جديدة'), isA<IconData>());
  });

  test('restored study question banks are non-empty and do not repeat prompts', () {
    for (final name in ['الرياضيات', 'اللغة العربية', 'الإسلامية', 'اللغة الإنكليزية',
      'العلوم', 'الاجتماعيات', 'الحاسوب', 'الأحياء']) {
      final questions = makeQuizQuestions('الأول الابتدائي', name);
      expect(questions, isNotEmpty);
      expect(questions.map((q) => q.text).toSet().length, questions.length);
      for (final q in questions) {
        expect(q.answer, inInclusiveRange(0, q.choices.length - 1));
        expect(q.choices, hasLength(4));
      }
    }
    expect(makeQuizQuestions('', 'مادة جديدة بلا بنك أسئلة'), isEmpty);
  });
}
