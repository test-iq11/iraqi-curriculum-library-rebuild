#!/usr/bin/env python3
"""Run after flutter create; add two Android flavors, package IDs, Internet permission."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
p = root/'android/app/build.gradle.kts'
if not p.exists(): raise SystemExit('Missing Android Gradle file: run flutter create first')
s=p.read_text()
# Android Gradle Plugin disables generated resource values for new projects.
# Both flavors declare resValue("string", "app_name", ...), so enable the
# feature in the *generated* Gradle file before assembling either APK.
if not re.search(r'\bresValues\s*=\s*true\b', s):
    if re.search(r'\bresValues\s*=\s*false\b', s):
        s = re.sub(r'\bresValues\s*=\s*false\b', 'resValues = true', s, count=1)
    elif re.search(r'\bbuildFeatures\s*\{', s):
        s = re.sub(r'(\bbuildFeatures\s*\{)', r'\1\n        resValues = true', s, count=1)
    else:
        if 'android {' not in s:
            raise SystemExit('Android Gradle file does not contain android block')
        s = s.replace('android {', 'android {\n    buildFeatures {\n        resValues = true\n    }\n', 1)
if 'productFlavors {' not in s:
    insert = '''
    // Two APKs, one shared Flutter codebase and a single catalog contract.
    flavorDimensions += "edition"
    productFlavors {
        create("user") {
            dimension = "edition"
            applicationId = "com.school.app.iraqi_curriculum_library"
            resValue("string", "app_name", "المكتبة العراقية")
        }
        create("admin") {
            dimension = "edition"
            applicationId = "com.school.app.iraqi_curriculum_library.admin"
            resValue("string", "app_name", "مدير المكتبة العراقية")
        }
    }
'''
    assert 'android {' in s
    s=s.replace('android {','android {'+insert,1)
s=s.replace('minSdk = flutter.minSdkVersion', 'minSdk = 24')
p.write_text(s)
manifest=root/'android/app/src/main/AndroidManifest.xml'
m=manifest.read_text()
m=re.sub(r'android:label="[^"]+"',r'android:label="@string/app_name"',m,count=1)
if 'android.permission.INTERNET' not in m:
    m=m.replace('<application', '<uses-permission android:name="android.permission.INTERNET" />\n    <application', 1)
if 'android:allowBackup=' not in m:
    m=m.replace('<application', '<application android:allowBackup="false"',1)
manifest.write_text(m)
wrapper = root/'android/gradle/wrapper/gradle-wrapper.properties'
if wrapper.exists():
    st=wrapper.read_text()
    match=re.search(r'gradle-(\d+)\.(\d+)(?:\.\d+)?-(?:all|bin)\.zip',st)
    if match and (int(match.group(1)),int(match.group(2)))<(8,14):
        st=re.sub(r'gradle-[\d.]+-(?:all|bin)\.zip', 'gradle-8.14-bin.zip',st)
        wrapper.write_text(st)
assert re.search(r'\bresValues\s*=\s*true\b', s), 'Android generated resource values are not enabled'
print('Android user/admin flavors and resValues feature configured successfully')
