#!/usr/bin/env python3
"""Preserve v1.7 original UI and add the schema-v2 live catalog hook."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
source=Path(__file__).resolve().parent/'original_v1_7.html'
s=source.read_text(encoding='utf-8')
for old,new in [('const BOOKS=','let BOOKS='),('const GRADES=','let GRADES='),('const STAGES=','let STAGES='),('const GRADE_COLORS=','let GRADE_COLORS=')]:
 assert old in s,old
 s=s.replace(old,new,1)
old="const gradeStage=g=>g.includes('الابتدائي')?STAGES[0]:g.includes('المتوسط')?STAGES[1]:STAGES[2];"
new="let stageIdByGrade={};const gradeStage=g=>STAGES.find(s=>s.id===stageIdByGrade[g]) || (g.includes('الابتدائي')?STAGES[0]:g.includes('المتوسط')?STAGES[1]:STAGES[2]);"
assert old in s;s=s.replace(old,new,1)
old="function subjectsForGrade(){return [...new Set(BOOKS.filter(b=>b.grade===state.grade).map(b=>b.subject))]}"
new="let publishedSubjects=[];function subjectsForGrade(){return publishedSubjects.length?publishedSubjects.filter(s=>s.grade===state.grade).map(s=>s.name):[...new Set(BOOKS.filter(b=>b.grade===state.grade).map(b=>b.subject))]}"
assert old in s;s=s.replace(old,new,1)
s=s.replace('style="--stage-color:${prefs.stageColors[i]}"','style="--stage-color:${prefs.stageColors[i]||s.color}"')
s=s.replace('heroHeader(s.name,s.desc,prefs.stageColors[state.stage],s.icon','heroHeader(s.name,s.desc,prefs.stageColors[state.stage]||s.color,s.icon')
s=s.replace("function gradeColor(g){return prefs.gradeColors[Math.max(0,gradeIndex(g))]||prefs.brand}", "function gradeColor(g){const i=gradeIndex(g);return prefs.gradeColors[i]||GRADE_COLORS[i]||prefs.brand}")
s=s.replace("for(const field of ['brand','hero','end'])", "const userStageOverrides=new Set(getStored('personal-stage-colors',[]));const userGradeOverrides=new Set(getStored('personal-grade-colors',[]));\nfor(const field of ['brand','hero','end'])", 1)
s=s.replace("  prefs[key][index]=value;", "  prefs[key][index]=value;\n  if(key==='stageColors'&&STAGES[index]){userStageOverrides.add(STAGES[index].id);store('personal-stage-colors',[...userStageOverrides])}\n  if(key==='gradeColors'&&GRADES[index]){userGradeOverrides.add(GRADES[index]);store('personal-grade-colors',[...userGradeOverrides])}")
s=s.replace("prefs.stageColors=[...p.colors];persistPrefs()", "prefs.stageColors=STAGES.map((s,i)=>p.colors[i%p.colors.length]);STAGES.forEach(s=>userStageOverrides.add(s.id));store('personal-stage-colors',[...userStageOverrides]);persistPrefs()")
s=s.replace("persistPrefs();render();toast('تمت إعادة الألوان الافتراضية')", "userStageOverrides.clear();userGradeOverrides.clear();store('personal-stage-colors',[]);store('personal-grade-colors',[]);prefs.stageColors=STAGES.map(s=>s.color);prefs.gradeColors=[...GRADE_COLORS];persistPrefs();render();toast('تمت إعادة الألوان الافتراضية')")
s=s.replace("function resetGradeColors(){prefs.gradeColors=[...DEFAULTS.gradeColors];persistPrefs()", "function resetGradeColors(){userGradeOverrides.clear();store('personal-grade-colors',[]);prefs.gradeColors=[...GRADE_COLORS];persistPrefs()")
s=s.replace(" return `<label class=\"mini-color-card\"", " return `<label class=\"mini-color-card\"")
s=s.replace("function miniColor(label,key,value,index,hint=''){", "function miniColor(label,key,value,index,hint=''){value=hexOK(value)?value:'#496af2';")
s=s.replace('3 مراحل</span></div><div class="color-mini-grid">${STAGES.map', '${STAGES.length} مراحل</span></div><div class="color-mini-grid">${STAGES.map')
s=s.replace("[['all','الكل'],['0','الابتدائية'],['1','المتوسطة'],['2','الإعدادية']]", "[['all','الكل'],...STAGES.map((s,i)=>[String(i),s.name])]")
s=s.replace('${s.name}</strong><small>${s.desc}</small>','${safe(s.name)}</strong><small>${safe(s.desc)}</small>')
s=s.replace("NativeLibrary.postMessage(JSON.stringify({action:'readBook',id}))", "NativeLibrary.postMessage(JSON.stringify({action:'readBook',bookId:b.uid||`book-${String(id+1).padStart(3,'0')}`}))")
s=s.replace("NativeLibrary.postMessage(JSON.stringify({action:'downloadBook',id}))", "NativeLibrary.postMessage(JSON.stringify({action:'downloadBook',bookId:b.uid||`book-${String(id+1).padStart(3,'0')}`}))")
s=s.replace("NativeLibrary.postMessage(JSON.stringify({action:'copyBookLink',id}))", "NativeLibrary.postMessage(JSON.stringify({action:'copyBookLink',bookId:BOOKS[id].uid||`book-${String(id+1).padStart(3,'0')}`}))")
patch=r'''
// Cloud-synchronized v2 catalog. Changing data never changes executable UI code.
// Native Flutter calls this after loading the cached data, then on resume/refresh.
BOOKS.forEach((b,i)=>b.uid='book-'+String(i+1).padStart(3,'0'));
window.applyRemoteLibrary=function(doc){
 if(!doc||doc.schemaVersion!==2||!Array.isArray(doc.stages)||!Array.isArray(doc.grades)||!Array.isArray(doc.subjects)||!Array.isArray(doc.books))return false;
 const visible=(x)=>x && x.visible!==false;
 const oldBooks=BOOKS;
 const oldStageColors=new Map(STAGES.map((s,i)=>[s.id||['stage-primary','stage-middle','stage-secondary'][i],prefs.stageColors[i]]));
 const oldGradeColors=new Map(GRADES.map((g,i)=>[g,prefs.gradeColors[i]]));
 const rekey=(ids)=>new Set([...ids].map(i=>oldBooks[i]?.uid).filter(Boolean));
 const savedFavs=getStored('cloud-fav-ids',null),savedRead=getStored('cloud-read-ids',null),savedHistory=getStored('cloud-history-ids',null);
 const favIds=Array.isArray(savedFavs)?new Set(savedFavs):rekey(state.favs);
 const readIds=Array.isArray(savedRead)?new Set(savedRead):rekey(state.read);
 const historyIds=Array.isArray(savedHistory)?savedHistory:state.history.map(i=>oldBooks[i]?.uid).filter(Boolean);
 const isColor=(v)=>typeof v==='string'&&/^#[\da-fA-F]{6}$/.test(v);
 const validStage=doc.stages.filter(visible);
 const names=new Set(),ids=new Set();
 STAGES=validStage.map((s,i)=>({id:s.id,name:String(s.name||''),desc:String(s.description||''),color:isColor(s.color)?s.color:['#4777f2','#10b69a','#f8a24c'][i%3],cls:['blue','green','orange'][i%3],icon:['book','school','star'].includes(s.icon)?s.icon:'book'}));
 const sIds=new Set(STAGES.map(x=>x.id));
 const grades=doc.grades.filter(g=>visible(g)&&sIds.has(g.stageId));
 stageIdByGrade={};GRADES=[];GRADE_COLORS=[];
 grades.forEach(g=>{if(typeof g.name!=='string'||names.has(g.name))return; names.add(g.name);GRADES.push(g.name);GRADE_COLORS.push(isColor(g.color)?g.color:'#5279ed');stageIdByGrade[g.name]=g.stageId;});
 prefs.stageColors=STAGES.map(s=>userStageOverrides.has(s.id)&&oldStageColors.has(s.id)?oldStageColors.get(s.id):s.color);
 prefs.gradeColors=GRADES.map((g,i)=>userGradeOverrides.has(g)&&oldGradeColors.has(g)?oldGradeColors.get(g):GRADE_COLORS[i]);
 const gradeById=new Map(grades.map(g=>[g.id,g]));
 const subjectById=new Map();publishedSubjects=[];
 doc.subjects.filter(visible).forEach(x=>{const g=gradeById.get(x.gradeId);if(!g||!names.has(g.name))return;subjectById.set(x.id,{grade:g.name,name:String(x.name||'')});publishedSubjects.push({grade:g.name,name:String(x.name||'')});});
 const next=[];doc.books.filter(visible).forEach(b=>{const s=subjectById.get(b.subjectId);if(!s)return;next.push({uid:String(b.id),grade:s.grade,subject:s.name,title:String(b.title||''),url:String(b.url||'')});});
 BOOKS=next;
 const nextIds=new Map(BOOKS.map((b,i)=>[b.uid,i]));
 state.favs=new Set([...favIds].map(id=>nextIds.get(id)).filter(Number.isInteger));
 state.read=new Set([...readIds].map(id=>nextIds.get(id)).filter(Number.isInteger));
 state.history=historyIds.map(id=>nextIds.get(id)).filter(Number.isInteger).slice(0,25);
 if(state.stage!==null&&!STAGES[state.stage]){state.stage=null;state.section='home';}
 if(state.grade&&!GRADES.includes(state.grade)){state.grade=null;state.section='home';}
 if(state.subject&&!subjectsForGrade().includes(state.subject)){state.subject=null;state.section=state.grade?'subjects':'home';}
 store('cloud-fav-ids',[...favIds]);store('cloud-read-ids',[...readIds]);store('cloud-history-ids',historyIds);
 persistPrefs();render({keepScroll:true});return true;
};
const _toggleFavOriginal=toggleFav;toggleFav=function(id){_toggleFavOriginal(id);store('cloud-fav-ids',[...state.favs].map(i=>BOOKS[i]?.uid).filter(Boolean))};
const _toggleReadOriginal=toggleRead;toggleRead=function(id){_toggleReadOriginal(id);store('cloud-read-ids',[...state.read].map(i=>BOOKS[i]?.uid).filter(Boolean))};
const _openBookActionsOriginal=openBookActions;openBookActions=function(id){_openBookActionsOriginal(id);store('cloud-history-ids',state.history.map(i=>BOOKS[i]?.uid).filter(Boolean))};
'''
assert '</script>' in s
s=s.replace('</script>',patch+'\n</script>',1)
(root/'assets/library_ui.html').write_text(s,encoding='utf-8')
print('Patched HTML source',len(s),'characters')
