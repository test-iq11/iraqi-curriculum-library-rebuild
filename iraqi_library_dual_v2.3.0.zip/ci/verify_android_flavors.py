#!/usr/bin/env python3
"""Prevent the 2.0.1 Android Gradle flavor-resource build regression."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
gradle = root / 'android/app/build.gradle.kts'
manifest = root / 'android/app/src/main/AndroidManifest.xml'
assert gradle.is_file(), 'Run flutter create and tool/configure_android.py first'
s = gradle.read_text(encoding='utf-8')
m = manifest.read_text(encoding='utf-8')
assert re.search(r'\bbuildFeatures\s*\{[^}]*\bresValues\s*=\s*true\b', s), 'Missing buildFeatures { resValues = true }'
for flavor in ('user', 'admin'):
    assert s.count(f'create("{flavor}")') == 1, f'Missing/duplicate flavor: {flavor}'
assert s.count('resValue("string", "app_name"') == 2, 'Expected app names for both flavors'
assert 'android:label="@string/app_name"' in m, 'Missing flavor-specific application label'
assert 'android.permission.INTERNET' in m, 'Network permission missing'
print('PASS: both Android product flavors have generated string resources enabled.')
