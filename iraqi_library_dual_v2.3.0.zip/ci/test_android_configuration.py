#!/usr/bin/env python3
"""Run Android-configurator smoke tests without Flutter/Android SDK."""
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
config = (root / 'tool/configure_android.py').read_text(encoding='utf-8')
check = (root / 'ci/verify_android_flavors.py').read_text(encoding='utf-8')

for has_build_features in (False, True):
    with TemporaryDirectory() as temp:
        working = Path(temp)
        (working / 'tool').mkdir()
        (working / 'ci').mkdir()
        (working / 'android/app/src/main').mkdir(parents=True)
        (working / 'android/gradle/wrapper').mkdir(parents=True)
        (working / 'tool/configure_android.py').write_text(config, encoding='utf-8')
        (working / 'ci/verify_android_flavors.py').write_text(check, encoding='utf-8')
        features = '    buildFeatures {\n        viewBinding = true\n    }\n' if has_build_features else ''
        original = '''plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}
android {
    namespace = "com.example.original"
%s    defaultConfig {
        applicationId = "com.example.original"
        minSdk = flutter.minSdkVersion
    }
}
''' % features
        gradle = working / 'android/app/build.gradle.kts'
        gradle.write_text(original, encoding='utf-8')
        manifest = working / 'android/app/src/main/AndroidManifest.xml'
        manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <application android:label="Example"></application>\n</manifest>', encoding='utf-8')
        (working / 'android/gradle/wrapper/gradle-wrapper.properties').write_text('distributionUrl=https\\://services.gradle.org/distributions/gradle-8.13-bin.zip')
        for n in (1, 2):
            subprocess.run([sys.executable, str(working / 'tool/configure_android.py')], check=True, capture_output=True, text=True)
            subprocess.run([sys.executable, str(working / 'ci/verify_android_flavors.py')], check=True, capture_output=True, text=True)
        output = gradle.read_text(encoding='utf-8')
        assert output.count('resValues = true') == 1, 'Duplicate Gradle resValues'
        assert output.count('create("user")') == 1, 'Duplicate user flavor'
        assert output.count('create("admin")') == 1, 'Duplicate admin flavor'
        assert 'minSdk = 24' in output
        assert '8.14-bin.zip' in (working/'android/gradle/wrapper/gradle-wrapper.properties').read_text()
print('PASS: both Android Gradle layouts and repeated configuration')
