#!/usr/bin/env python3
import json, pathlib, re, sys
root=pathlib.Path(__file__).resolve().parents[1]
model=json.loads((root/'assets/library_seed.json').read_text())
other=json.loads((root/'data/library.json').read_text())
assert model==other, 'Embedded catalog and repository starter catalog differ'
assert model['schemaVersion']==2
assert len(model['stages'])==3
assert len(model['grades'])==15
assert len(model['subjects'])==118
assert len(model['books'])==157
for typ, parent, previous in [('grades','stageId','stages'),('subjects','gradeId','grades'),('books','subjectId','subjects')]:
 ids={o['id'] for o in model[previous]}
 assert all(x[parent] in ids for x in model[typ]),f'Broken {typ} references'
html=(root/'assets/library_ui.html').read_text()
assert 'window.applyRemoteLibrary=function(doc)' in html
assert 'function openBookActions(id)' in html
assert "action:'readBook'" in html
assert "action:'downloadBook'" in html
assert "action:'copyBookLink'" in html
assert 'reviews-original-card' in html
assert 'min-height:122px' in html
assert 'native-android' in html
# Grade cards must always display vector pictograms, never the broken 'ال' text.
assert 'class=\"grade-token\">${icon(pictogramForGrade(g))}' in html
assert 'gradeName(g).slice(0,2)' not in html
assert html.count('<symbol id=\"i-grade-') >= 15
assert 'OTHER_GRADE_PICTOGRAMS' in html  # support grades added remotely by manager
assert "const BOOKS=" not in html, 'The catalog cannot be constant'
for tag in ('flutter','http','pdfrx','flutter_secure_storage'):
 assert tag in (root/'pubspec.yaml').read_text()
for file in ['lib/main_admin.dart','lib/main_user.dart','lib/admin/admin_library_app.dart','lib/user/user_library_app.dart','lib/services/github_publisher.dart','tool/configure_android.py']:
 assert (root/file).exists(),f'Missing {file}'
native=(root/'lib/user/user_library_app.dart').read_text()
review=(root/'lib/user/review_bank.dart').read_text()
admin=(root/'lib/admin/admin_library_app.dart').read_text()
assert 'WebViewController' not in native and 'WebViewWidget' not in native, 'User UI must be native Flutter'
for v in ('ListView.builder', 'NavigationBar(', 'بطاقات المراجعة', 'التنزيلات', 'gradeIcon(', 'Icons.straighten', 'Icons.explore_outlined'):
 assert v in native, f'Missing native user feature: {v}'
assert 'subjectPool == null' in review and 'bank.add(QuizQuestion' in review
assert 'رمز اللون HEX' in admin and 'اختيار لون البطاقة' in admin and 'HSVColor.fromColor' in admin
assert "'الثالث الابتدائي':'grade-ruler','الرابع الابتدائي':'grade-compass'" in html
assert 'webview_flutter' not in (root/'pubspec.yaml').read_text()
print('VERIFIED: schema v2, 3 stages, 15 grades, 118 subjects, 157 books; native Flutter user, review cards, academic grade icons, administrator color picker, both flavors.')
