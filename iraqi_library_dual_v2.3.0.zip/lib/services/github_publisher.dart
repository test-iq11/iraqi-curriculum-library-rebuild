import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../models/library_catalog.dart';
import 'library_repository.dart';

class RemoteSnapshot {
  const RemoteSnapshot(this.catalog, this.sha);
  final LibraryCatalog? catalog;
  final String? sha;
}

/// Uses repository-scoped, fine-grained PAT stored only on the manager device.
/// Never supply this credential to a webview or a user APK.
class GitHubPublisher {
  GitHubPublisher({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  static const _key = 'github_manager_fine_grained_access_token';

  Future<bool> get hasToken async => (await _secure.read(key: _key) ?? '').isNotEmpty;
  Future<void> saveToken(String token) async {
    if (token.trim().isEmpty) throw ArgumentError('الرمز فارغ');
    await _secure.write(key: _key, value: token.trim());
  }
  Future<void> clearToken() => _secure.delete(key: _key);

  Future<Map<String, String>> _headers() async {
    final token = await _secure.read(key: _key);
    if (token == null || token.isEmpty) throw StateError('أدخل رمز GitHub الخاص بالمدير أولاً');
    return {
      'Authorization': 'Bearer $token',
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'IraqiSchoolLibrary-Manager',
    };
  }

  Future<RemoteSnapshot> fetch() async {
    if (!LibraryEndpoint.configured) {
      throw StateError('لم تُحدد بيانات مستودع GitHub أثناء بناء التطبيق');
    }
    final uri = Uri.parse(LibraryEndpoint.apiUrl).replace(queryParameters: {
      'ref': LibraryEndpoint.branch,
    });
    final response = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (response.statusCode == 404) return const RemoteSnapshot(null, null);
    if (response.statusCode != 200) {
      throw StateError(_errorMessage('قراءة الفهرس', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final encoded = (payload['content'] ?? '').toString().replaceAll('\n', '');
    final text = utf8.decode(base64Decode(base64.normalize(encoded)));
    return RemoteSnapshot(LibraryRepository.decode(text), payload['sha'] as String?);
  }

  Future<RemoteSnapshot> publish({
    required LibraryCatalog draft,
    required String? baseSha,
  }) async {
    if (!LibraryEndpoint.configured) throw StateError('المستودع غير مهيأ');
    draft.validate();
    // Read-before-write plus GitHub SHA CAS protects against concurrent editors.
    final latest = await fetch();
    if (latest.sha != baseSha) {
      throw StateError('تغير ملف الكتب على GitHub منذ آخر مزامنة؛ راجع أحدث نسخة قبل النشر حتى لا تفقد تعديلات أخرى.');
    }
    final next = draft.copy();
    next.revision = (latest.catalog?.revision ?? draft.revision) + 1;
    next.updatedAt = DateTime.now().toUtc().toIso8601String();
    final body = <String, dynamic>{
      'message': 'Update Iraqi library catalog (revision ${next.revision})',
      'content': base64Encode(utf8.encode(const JsonEncoder.withIndent('  ').convert(next.toJson()))),
      'branch': LibraryEndpoint.branch,
      'sha': ?baseSha,
    };
    final response = await _client.put(Uri.parse(LibraryEndpoint.apiUrl),
      headers: {...await _headers(), 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 30));
    if (response.statusCode != 200 && response.statusCode != 201) {
      throw StateError(_errorMessage('نشر التعديلات', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final content = payload['content'];
    final sha = content is Map ? content['sha'] as String? : null;
    return RemoteSnapshot(next, sha);
  }

  String _errorMessage(String action, http.Response response) {
    final status = response.statusCode;
    if (status == 401) return '$action: رمز GitHub غير صالح أو انتهت صلاحيته (401)';
    if (status == 403) return '$action: لا تمتلك إذن Contents: Read and write أو المستودع غير مسموح (403)';
    if (status == 409) return '$action: تعارض في نسخة الملف (409)، حمّل النسخة الحالية';
    if (status == 404) return '$action: المستودع غير موجود أو الرمز لا يملك صلاحية الوصول (404)';
    return '$action: خطأ GitHub ($status)';
  }
}
