import 'package:flutter/material.dart';
import 'user/user_library_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const IraqiLibraryUserApp());
}
