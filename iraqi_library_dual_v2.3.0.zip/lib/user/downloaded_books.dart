import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/library_catalog.dart';

class DownloadedBooks {
  static const _key = 'downloads_v2';
  final SharedPreferencesAsync prefs = SharedPreferencesAsync();

  Future<Map<String, dynamic>> entries() async {
    try {
      final raw = await prefs.getString(_key);
      return raw == null ? {} : Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) { return {}; }
  }

  Future<String?> localFile(String bookId) async {
    final e = (await entries())[bookId];
    if (e is! Map || e['path'] is! String) return null;
    final path = e['path'] as String;
    return File(path).existsSync() ? path : null;
  }

  static Uri directPdfUri(String originalUrl) {
    final uri = Uri.parse(originalUrl);
    final drive = RegExp(r'/file/d/([a-zA-Z0-9_-]+)').firstMatch(uri.path);
    if (uri.host == 'drive.google.com' && drive != null) {
      return Uri.https('drive.google.com', '/uc', {
        'export': 'download', 'id': drive.group(1)!,
      });
    }
    return uri;
  }

  Future<String> download(Map<String, dynamic> book) async {
    final id = (book['id'] ?? '').toString();
    final url = (book['url'] ?? '').toString();
    if (!LibraryCatalog.validWebUrl(url)) throw StateError('رابط الكتاب غير صالح');
    final dir = Directory('${(await getApplicationDocumentsDirectory()).path}/downloaded_books');
    await dir.create(recursive: true);
    final safeId = id.replaceAll(RegExp('[^a-zA-Z0-9_-]'), '_');
    final dest = File('${dir.path}/$safeId.pdf');
    final temp = File('${dest.path}.part');
    final client = http.Client();
    try {
      final request = http.Request('GET', directPdfUri(url));
      final response = await client.send(request).timeout(const Duration(seconds: 35));
      if (response.statusCode != 200 && response.statusCode != 206) {
        throw StateError('تعذر التحميل: HTTP ${response.statusCode}');
      }
      if (response.contentLength != null && response.contentLength! > 250 * 1024 * 1024) {
        throw StateError('حجم الكتاب أكبر من 250 ميغابايت');
      }
      final sink = temp.openWrite();
      var total = 0;
      try {
        await for (final chunk in response.stream.timeout(const Duration(seconds: 50))) {
          total += chunk.length;
          if (total > 250 * 1024 * 1024) throw StateError('تم تجاوز حد التحميل 250 ميغابايت');
          sink.add(chunk);
        }
      } finally {
        await sink.close();
      }
      final file = await temp.open();
      final signature = await file.read(5);
      await file.close();
      if (signature.length < 5 || utf8.decode(signature, allowMalformed: true) != '%PDF-') {
        throw StateError('الرابط لا يعيد ملف PDF مباشرة. افتح الكتاب في المتصفح بدلاً من ذلك.');
      }
      if (await dest.exists()) await dest.delete();
      await temp.rename(dest.path);
      final saved = await entries();
      saved[id] = {'title': book['title'], 'path': dest.path, 'sourceUrl': url};
      await prefs.setString(_key, jsonEncode(saved));
      return dest.path;
    } finally {
      client.close();
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<void> remove(String bookId) async {
    final map = await entries();
    final entry = map.remove(bookId);
    if (entry is Map && entry['path'] is String) {
      final file = File(entry['path'] as String);
      if (await file.exists()) await file.delete();
    }
    await prefs.setString(_key, jsonEncode(map));
  }
}
