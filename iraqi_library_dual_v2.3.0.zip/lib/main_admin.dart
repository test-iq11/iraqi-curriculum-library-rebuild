import 'package:flutter/material.dart';
import 'admin/admin_library_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const IraqiLibraryAdminApp());
}
