// Fallback entrypoint for local development; CI uses the explicit flavored mains.
import 'main_user.dart' as user;
void main() => user.main();
