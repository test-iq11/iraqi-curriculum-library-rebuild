#!/usr/bin/env python3
"""Guard against published dependency conflicts and file_picker API regressions.

This is a static preflight. Actual pub resolution happens in Flutter CI.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
pubspec = (root / 'pubspec.yaml').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/build-dual-apk.yml').read_text(encoding='utf-8')
admin = (root / 'lib/admin/admin_library_app.dart').read_text(encoding='utf-8')
importer = (root / 'lib/admin/catalog_tools.dart').read_text(encoding='utf-8')

def dependency(name):
    match = re.search(r'^  ' + re.escape(name) + r':\s*([^\s#]+)', pubspec, re.MULTILINE)
    return match.group(1) if match else None

assert dependency('file_picker') == '13.3.2', 'file_picker must be compatible with secure storage 11.x'
assert dependency('flutter_secure_storage') == '^11.2.0', 'Do not downgrade encrypted GitHub token storage'
assert dependency('excel_plus') == '2.29.2', 'Use the XLSX reader compatible with archive 4.x'
assert dependency('pdfrx') == '^2.12.0', 'Preserve PDF reader engine'
assert dependency('excel') is None, 'excel 4.x requires archive 3.x, incompatible with pdfrx'
assert 'FilePicker.pickFile(' in admin, 'Use new file_picker 13 API'
for old in ('FilePicker.platform', 'withData: true', 'file.size', 'picked.files'):
    assert old not in admin, f'Legacy file_picker API remains: {old}'
assert 'file.readAsBytes()' in admin, 'File content must be read asynchronously'
assert "package:excel_plus/excel_plus.dart" in importer, 'Wrong XLSX import'
assert "package:excel/excel.dart" not in importer, 'Legacy excel import found'
assert "cell?.displayText" in importer, 'TextCellValue.value is TextSpan in excel_plus; use displayText'
assert 'flutter-version: "3.47.9"' in workflow
assert 'flutter create --no-pub' in workflow
assert 'flutter pub get' in workflow
assert 'flutter analyze --no-fatal-infos' in workflow
assert 'flutter test --reporter expanded' in workflow
assert 'iraqi_library_dual_v2.4.2.zip' in workflow
print('PASS: picker 13 API; secure storage 11; excel_plus archive 4; pdfrx; matching ZIP and CI.')
