#!/usr/bin/env python3
"""Preflight for the pubspec regression that blocked the 2.4.0 build.

This is a static guard. It does not replace pub.dev resolution / `flutter pub get`.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
pubspec = (root / 'pubspec.yaml').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/build-dual-apk.yml').read_text(encoding='utf-8')

picker = re.search(r'^\s{2}file_picker:\s*([^\s#]+)', pubspec, re.MULTILINE)
assert picker is not None, 'Missing file_picker dependency'
assert picker.group(1) == '10.3.10', (
    f'file_picker must be pinned to known published 10.3.10; got {picker.group(1)!r}. '
    'The previously selected 10.3.11 is retracted on pub.dev.'
)
assert 'file_picker: ^10.3.11' not in pubspec, 'Retracted dependency is still present'
assert '  excel: ^4.0.6' not in pubspec, 'Old Excel dependency conflicts with pdfrx_engine archive 4'
assert '  excel_community: 2.6.2' in pubspec, 'Expected archive-4 compatible Excel fork'
assert '  pdfrx: 2.6.6' in pubspec, 'Restore version used by original v1.7 PDF reader'
assert 'package:excel_community/excel_community.dart' in (root/'lib/admin/catalog_tools.dart').read_text(encoding='utf-8')
assert 'package:excel/excel.dart' not in (root/'lib/admin/catalog_tools.dart').read_text(encoding='utf-8')
reader = (root/'lib/screens/pdf_reader_screen.dart').read_text(encoding='utf-8')
assert 'class PdfReaderScreen' in reader and 'PdfViewer.uri(' in reader and 'PdfViewer.file(' in reader
assert 'PdfViewerScrollThumb(' in reader and 'PdfTextSearcher' in reader
user = (root/'lib/user/user_library_app.dart').read_text(encoding='utf-8')
assert 'return PdfReaderScreen(' in user, 'User app must launch restored reader'
assert 'bookKey: entry.key' in user, 'Offline book keys must be retained for reading progress'
assert 'flutter-version: "3.47.9"' in workflow, 'Expected tested Flutter version not pinned'
assert 'flutter create --no-pub' in workflow, 'Flutter create must not auto-resolve dependencies'
assert "flutter pub get" in workflow, 'Missing explicit dependency resolution'
assert 'flutter analyze --no-fatal-infos' in workflow, 'Analyzer step must be retained'
assert 'flutter test --reporter expanded' in workflow, 'Test step must be retained'
assert 'iraqi_library_dual_v2.4.2.zip' in workflow, 'Workflow ZIP filename mismatch'
assert "data/library.json" not in re.findall(r'^\s*-\s+[\'\"]([^\'\"]+)', workflow, re.M), 'Data must not be overwritten'
print('PASS: Excel/PDF dependencies, original reader, file_picker, Flutter, workflow ZIP, preflight')
