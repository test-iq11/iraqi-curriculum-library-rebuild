import 'dart:convert';
import 'dart:typed_data';

import 'package:csv/csv.dart';
import 'package:excel_community/excel_community.dart';

import '../models/library_catalog.dart';

class LinkAudit {
  LinkAudit(this.missing, this.invalid, this.duplicates, this.ready);
  final List<Map<String, dynamic>> missing;
  final List<Map<String, dynamic>> invalid;
  final List<Map<String, dynamic>> duplicates;
  final int ready;

  static LinkAudit run(LibraryCatalog catalog) {
    final missing = <Map<String, dynamic>>[];
    final invalid = <Map<String, dynamic>>[];
    final duplicates = <Map<String, dynamic>>[];
    final known = <String, String>{};
    var ready = 0;
    for (final b in catalog.books) {
      final url = (b['url'] ?? '').toString().trim();
      if (url.isEmpty) { missing.add(b); continue; }
      if (!LibraryCatalog.validWebUrl(url)) { invalid.add(b); continue; }
      final old = known[url];
      if (old != null) duplicates.add(b);
      known[url] = b['id'].toString();
      ready++;
    }
    return LinkAudit(missing, invalid, duplicates, ready);
  }
}

class ImportPreview {
  const ImportPreview(this.items, this.errors);
  final List<Map<String, String>> items;
  final List<String> errors;
}

class BulkBookImport {
  static List<List<String>> readCsv(Uint8List bytes) {
    final text = utf8.decode(bytes, allowMalformed: true).replaceFirst('\uFEFF', '');
    final rows = const CsvToListConverter(shouldParseNumbers: false).convert(text);
    return rows.map((row) => row.map((e) => e.toString()).toList()).toList();
  }

  static List<List<String>> readXlsx(Uint8List bytes) {
    final wb = Excel.decodeBytes(bytes);
    if (wb.tables.isEmpty) throw const FormatException('لم يُعثر على ورقة داخل ملف Excel');
    final sheet = wb.tables.values.first;
    // The community fork provides displayText for plain text, numeric,
    // formatted and formula cells. Its TextCellValue.value is a TextSpan,
    // not a String, so do not return that property directly.
    return sheet.rows.map((row) => row.map((cell) => cell?.displayText ?? '').toList()).toList();
  }

  static ImportPreview parse(List<List<String>> rows) {
    if (rows.isEmpty) return const ImportPreview([], ['الملف فارغ']);
    String norm(String s) => s.trim().toLowerCase().replaceAll('أ', 'ا').replaceAll('إ', 'ا').replaceAll('ة', 'ه');
    final headings = rows.first.map(norm).toList();
    int column(List<String> names) => headings.indexWhere((h) => names.contains(h));
    final gradeIdx = column(['الصف', 'الصف الدراسي', 'grade']);
    final subjectIdx = column(['الماده', 'الماده الدراسيه', 'subject']);
    final titleIdx = column(['الكتاب', 'عنوان الكتاب', 'اسم الكتاب', 'title', 'book']);
    final urlIdx = column(['الرابط', 'رابط الكتاب', 'url', 'link']);
    if ([gradeIdx, subjectIdx, titleIdx, urlIdx].any((i) => i < 0)) {
      return const ImportPreview([], ['الأعمدة المطلوبة: الصف، المادة، الكتاب، الرابط']);
    }
    String cell(List<String> r, int i) => i < r.length ? r[i].trim() : '';
    final items = <Map<String, String>>[];
    final errors = <String>[];
    for (var i = 1; i < rows.length; i++) {
      final r = rows[i];
      if (r.every((v) => v.trim().isEmpty)) continue;
      final g = cell(r, gradeIdx), s = cell(r, subjectIdx);
      final t = cell(r, titleIdx), u = cell(r, urlIdx);
      if ([g,s,t].any((v) => v.isEmpty) || (u.isNotEmpty && !LibraryCatalog.validWebUrl(u))) {
        errors.add('السطر ${i+1}: صف أو مادة أو عنوان ناقص، أو رابط غير صالح');
        continue;
      }
      items.add({'grade':g,'subject':s,'title':t,'url':u});
    }
    return ImportPreview(items,errors);
  }

  /// Import into a copy. Existing stage/grade structure is never overwritten.
  /// Missing subjects are created under existing grades; no rows are published here.
  static LibraryCatalog apply(LibraryCatalog original, ImportPreview preview) {
    final next = original.copy();
    for (final row in preview.items) {
      final gradeName = row['grade']!;
      final grade = next.grades.where((e) => LibraryCatalog.name(e) == gradeName).firstOrNull;
      if (grade == null) throw FormatException('الصف «$gradeName» غير موجود؛ أضفه من إدارة المراحل أولاً');
      final subjectName = row['subject']!;
      var subject = next.subjects.where((e) => e['gradeId'] == grade['id'] && LibraryCatalog.name(e) == subjectName).firstOrNull;
      if (subject == null) {
        subject = {
          'id': LibraryCatalog.newId('subject'), 'gradeId': grade['id'], 'name': subjectName,
          'order': next.subjects.where((e) => e['gradeId'] == grade['id']).length,
          'visible': true,
        };
        next.subjects.add(subject);
      }
      final duplicate = next.books.any((e) => e['subjectId'] == subject!['id'] &&
        LibraryCatalog.name(e) == row['title'] && (e['url'] ?? '') == row['url']);
      if (duplicate) continue;
      next.books.add({
        'id': LibraryCatalog.newId('book'), 'subjectId': subject['id'],
        'title': row['title'], 'url': row['url'], 'visible': true,
        'order': next.books.where((e) => e['subjectId'] == subject!['id']).length,
      });
    }
    next.validate();
    return next;
  }
}
