import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:excel_plus/excel_plus.dart';
import 'package:iraqi_school_library_dual/admin/catalog_tools.dart';
import 'package:iraqi_school_library_dual/models/library_catalog.dart';

LibraryCatalog catalog() => LibraryCatalog.fromJson({
  'schemaVersion':2,'revision':7,'updatedAt':'2026-11-07T00:00:00Z',
  'stages':[{'id':'s','name':'الابتدائية','color':'#496AF2','icon':'book','order':0}],
  'grades':[{'id':'g','stageId':'s','name':'الأول الابتدائي','color':'#467AEF','order':0}],
  'subjects':[{'id':'sub','gradeId':'g','name':'الرياضيات','order':0}],
  'books':[{'id':'b','subjectId':'sub','title':'رياضيات 1','url':'https://example.org/1.pdf','order':0}],
});

void main() {
  test('link audit distinguishes missing and repeated URLs', () {
    final doc = catalog();
    doc.books.add({'id':'b2','subjectId':'sub','title':'كتاب ثان','url':'','order':1});
    doc.books.add({'id':'b3','subjectId':'sub','title':'كتاب مكرر','url':'https://example.org/1.pdf','order':2});
    doc.validate();
    final audit = LinkAudit.run(doc);
    expect(audit.missing, hasLength(1));
    expect(audit.duplicates, hasLength(1));
  });

  test('CSV import respects existing grades and creates missing subjects', () {
    final csv = 'الصف,المادة,الكتاب,الرابط\nالأول الابتدائي,العلوم,كتاب العلوم,https://example.org/science.pdf\n';
    final rows = BulkBookImport.readCsv(Uint8List.fromList(utf8.encode(csv)));
    final preview = BulkBookImport.parse(rows);
    expect(preview.errors, isEmpty);
    expect(preview.items, hasLength(1));
    final doc = BulkBookImport.apply(catalog(), preview);
    expect(doc.subjects, hasLength(2));
    expect(doc.books, hasLength(2));
    expect(BulkBookImport.apply(doc, preview).books, hasLength(2));
  });

  test('XLSX import keeps Arabic headers and book URLs after decoding', () {
    final workbook = Excel.createExcel();
    final sheet = workbook['Sheet1'];
    sheet.appendRow([
      TextCellValue('الصف'), TextCellValue('المادة'),
      TextCellValue('الكتاب'), TextCellValue('الرابط'),
    ]);
    sheet.appendRow([
      TextCellValue('الأول الابتدائي'), TextCellValue('العلوم'),
      TextCellValue('كتاب العلوم'),
      TextCellValue('https://example.org/science.pdf'),
    ]);
    final encoded = workbook.save();
    expect(encoded, isNotNull);
    final rows = BulkBookImport.readXlsx(Uint8List.fromList(encoded!));
    final preview = BulkBookImport.parse(rows);
    expect(preview.errors, isEmpty);
    expect(preview.items, hasLength(1));
    expect(preview.items.single['title'], 'كتاب العلوم');
    expect(preview.items.single['url'], 'https://example.org/science.pdf');
  });

  test('optional new review bank works with old JSON and cascades on subject deletion', () {
    final doc = catalog();
    expect(doc.reviews, isEmpty);
    doc.reviews.add({
      'id':'q1','subjectId':'sub','text':'ما ناتج 2+2؟',
      'choices':['4','5','6','7'],'answer':0,'difficulty':'سهل',
    });
    doc.validate();
    final roundTrip = LibraryCatalog.fromJson(doc.toJson());
    expect(roundTrip.reviews, hasLength(1));
    expect(roundTrip.descendants('subject','sub'), 2);
    roundTrip.deleteTree('subject','sub');
    roundTrip.validate();
    expect(roundTrip.reviews, isEmpty);
  });
}
