import 'dart:async';
import 'dart:convert';

import 'downloaded_books.dart';

import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'pdf_reader_controls.dart';

class BookPdfScreen extends StatefulWidget {
  final String? localPath;
  final String url;
  final String bookKey;
  final String title;

  const BookPdfScreen({
    super.key,
    this.localPath,
    required this.url,
    required this.bookKey,
    required this.title,
  });

  @override
  State<BookPdfScreen> createState() => _BookPdfScreenState();
}

class _BookPdfScreenState extends State<BookPdfScreen> {
  final PdfViewerController _controller = PdfViewerController();
  PdfTextSearcher? _textSearcher;
  PdfDocument? _document;
  List<PdfOutlineNode> _outline = const [];
  bool _outlineLoaded = false;
  int _page = 1;
  final ValueNotifier<int> _pageNotifier = ValueNotifier<int>(1);
  Timer? _saveProgressTimer;
  bool _loadingSearchIndex = false;
  int _initialPage = 1;
  int _totalPages = 0;
  bool _stateLoaded = false;
  List<int> _bookmarks = const [];
  List<_BookNote> _notes = const [];
  // Null means 'follow the app theme'; manual reader preference is persistent.
  bool? _readerNightOverride;
  static const String _readerNightKey = 'pdf-reader-night-v26';
  static const ColorFilter _nightPagesFilter = ColorFilter.matrix(<double>[
    -1, 0, 0, 0, 255,
    0, -1, 0, 0, 255,
    0, 0, -1, 0, 255,
    0, 0, 0, 1, 0,
  ]);
  static const ColorFilter _normalPagesFilter = ColorFilter.matrix(<double>[
    1, 0, 0, 0, 0,
    0, 1, 0, 0, 0,
    0, 0, 1, 0, 0,
    0, 0, 0, 1, 0,
  ]);

  bool get _readerNight => _readerNightOverride ??
      (Theme.of(context).brightness == Brightness.dark);

  Future<void> _toggleNight() async {
    final next = !_readerNight;
    setState(() => _readerNightOverride = next);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_readerNightKey, next);
    } catch (_) { /* Keep the in-session preference even without storage. */ }
  }

  String get _progressKey => 'pdf-progress:${widget.bookKey}';
  String get _bookmarksKey => 'pdf-bookmarks:${widget.bookKey}';
  String get _notesKey => 'pdf-notes:${widget.bookKey}';
  bool get _currentPageBookmarked => _bookmarks.contains(_page);

  @override
  void initState() {
    super.initState();
    _restoreReadingState();
  }

  Future<void> _restoreReadingState() async {
    final prefs = await SharedPreferences.getInstance();
    final page = prefs.getInt(_progressKey) ?? 1;
    final savedNight = prefs.getBool(_readerNightKey);
    final bookmarks = prefs.getStringList(_bookmarksKey) ?? const <String>[];
    final notes = prefs.getStringList(_notesKey) ?? const <String>[];
    final restoredNotes = <_BookNote>[];
    for (final item in notes) {
      try {
        restoredNotes.add(_BookNote.fromJson(Map<String, dynamic>.from(jsonDecode(item) as Map)));
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _initialPage = page < 1 ? 1 : page;
      _page = _initialPage;
      _pageNotifier.value = _initialPage;
      _bookmarks = bookmarks.map(int.tryParse).whereType<int>().toList()..sort();
      _notes = restoredNotes;
      _readerNightOverride = savedNight;
      _stateLoaded = true;
    });
  }

  // Avoid setState on the viewer during flings; persist only after scrolling rests.
  void _onPageChanged(int? page) {
    if (!mounted || page == null || page < 1 || _page == page) return;
    _page = page;
    _pageNotifier.value = page;
    _saveProgressTimer?.cancel();
    _saveProgressTimer = Timer(const Duration(milliseconds: 700), () {
      unawaited(_saveProgress(page));
    });
  }

  Future<void> _saveProgress(int page) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_progressKey, page);
    } catch (_) {}
  }

  // Loading all page dimensions is deferred until the user actually searches,
  // allowing cold-open and fast swipes to use on-demand measurements.
  Future<void> _performSearch(String phrase) async {
    final query = phrase.trim();
    if (query.isEmpty || _loadingSearchIndex) return;
    _loadingSearchIndex = true;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('جارٍ تجهيز صفحات الكتاب للبحث الشامل…'),
      duration: Duration(seconds: 2),
    ));
    try {
      final document = _document;
      if (document != null) await document.loadPagesProgressively();
      if (mounted) _textSearcher?.startTextSearch(query,
        caseInsensitive: true, goToFirstMatch: false,
        searchImmediately: true);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('تعذر تجهيز البحث. حاول مرة أخرى.'),
      ));
    } finally {
      _loadingSearchIndex = false;
    }
  }

  void _onViewerReady(PdfDocument document, PdfViewerController controller) {
    if (!mounted) return;
    _document = document;
    _textSearcher ??= PdfTextSearcher(controller)..addListener(_onSearchChanged);
    final total = document.pages.length;
    setState(() {
      _totalPages = total;
      _page = (controller.pageNumber ?? _initialPage).clamp(1, total == 0 ? 1 : total).toInt();
      _pageNotifier.value = _page;
    });
    if (total > 0 && _initialPage > total) {
      unawaited(controller.goToPage(pageNumber: total, duration: Duration.zero));
    }
    unawaited(_loadOutline(document));
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _loadOutline(PdfDocument document) async {
    try {
      final outline = await document.loadOutline();
      if (!mounted || !identical(_document, document)) return;
      setState(() {
        _outline = outline;
        _outlineLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _outlineLoaded = true);
    }
  }

  Future<void> _showBookSearch() async {
    final searcher = _textSearcher;
    if (searcher == null) return;
    final input = TextEditingController(text: searcher.pattern is String ? searcher.pattern! as String : '');
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .78,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
              child: Row(children: [
                const Icon(Icons.manage_search_rounded, color: Color(0xFF16A89A)),
                const SizedBox(width: 9),
                const Expanded(child: Text('بحث داخل الكتاب', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
                if (searcher.isSearching)
                  SizedBox(width: 21, height: 21, child: CircularProgressIndicator(value: searcher.searchProgress, strokeWidth: 2.4)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: input,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'اكتب كلمة أو موضوعاً',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: IconButton(
                    tooltip: 'مسح البحث',
                    onPressed: () { input.clear(); searcher.resetTextSearch(); },
                    icon: const Icon(Icons.close_rounded),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                ),
                onSubmitted: (value) {
                  final query = value.trim();
                  if (query.isNotEmpty) unawaited(_performSearch(query));
                },
              ),
            ),
            const SizedBox(height: 9),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    final query = input.text.trim();
                    if (query.isNotEmpty) unawaited(_performSearch(query));
                  },
                  icon: const Icon(Icons.search_rounded),
                  label: const Text('ابحث في جميع الصفحات'),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  searcher.isSearching ? 'جارٍ البحث… ${searcher.matches.length} نتيجة حتى الآن' : 'النتائج: ${searcher.matches.length}',
                  style: TextStyle(color: Theme.of(sheetContext).colorScheme.onSurface.withValues(alpha: .68),
                    fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            Expanded(
              child: searcher.matches.isEmpty
                  ? _ReaderEmptyState(
                      icon: searcher.isSearching ? Icons.hourglass_top_rounded : Icons.search_off_rounded,
                      label: searcher.pattern == null ? 'اكتب كلمة لبدء البحث' : (searcher.isSearching ? 'يتم فحص صفحات الكتاب' : 'لا توجد نتائج مطابقة'),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
                      itemCount: searcher.matches.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 4),
                      itemBuilder: (context, index) {
                        final match = searcher.matches[index];
                        return Card(
                          child: ListTile(
                            leading: CircleAvatar(backgroundColor: const Color(0xFF16A89A).withValues(alpha: .12), child: Text('${match.pageNumber}', style: const TextStyle(color: Color(0xFF087C72), fontWeight: FontWeight.w900))),
                            title: Text(match.text.trim().replaceAll(RegExp(r'\s+'), ' '), maxLines: 2, overflow: TextOverflow.ellipsis),
                            subtitle: Text('الصفحة ${match.pageNumber} • نتيجة ${index + 1}'),
                            trailing: const Icon(Icons.north_west_rounded),
                            onTap: () async {
                              await searcher.goToMatch(match);
                              if (sheetContext.mounted) Navigator.pop(sheetContext);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
    input.dispose();
  }

  Future<void> _showThumbnails() async {
    final document = _document;
    if (document == null || _totalPages < 1) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .82,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 3, 20, 12),
              child: Row(children: [
                const Icon(Icons.grid_view_rounded, color: Color(0xFF16A89A)),
                const SizedBox(width: 9),
                const Expanded(child: Text('فهرس الصفحات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
                Text('$_totalPages صفحة', style: TextStyle(
                  color: Theme.of(sheetContext).colorScheme.onSurface.withValues(alpha: .68), fontSize: 12)),
              ]),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(14, 2, 14, 20),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: .62, crossAxisSpacing: 11, mainAxisSpacing: 12),
                itemCount: _totalPages,
                itemBuilder: (context, index) {
                  final page = index + 1;
                  final selected = page == _page;
                  return Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () { Navigator.pop(sheetContext); _goToPage(page); },
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(color: selected ? const Color(0xFF16A89A) : Colors.black12, width: selected ? 2 : 1), borderRadius: BorderRadius.circular(14)),
                        child: Column(children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: PdfPageView(document: document, pageNumber: page, maximumDpi: 80, backgroundColor: Colors.white),
                            ),
                          ),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            color: selected ? const Color(0xFF16A89A).withValues(alpha: .10) : const Color(0xFFF3F6FA),
                            child: Text('الصفحة $page', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: selected ? const Color(0xFF087C72) : const Color(0xFF34465B))),
                          ),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _appendOutlineRows(List<PdfOutlineNode> nodes, List<({PdfOutlineNode node, int depth})> rows, [int depth = 0]) {
    for (final node in nodes) {
      rows.add((node: node, depth: depth));
      _appendOutlineRows(node.children, rows, depth + 1);
    }
  }

  Future<void> _showContents() async {
    if (!_outlineLoaded) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('جارٍ تحميل فهرس الفصول…')));
      return;
    }
    final rows = <({PdfOutlineNode node, int depth})>[];
    _appendOutlineRows(_outline, rows);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .72,
          child: Column(children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 2, 20, 14), child: Align(alignment: Alignment.centerRight, child: Text('فهرس الفصول', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)))),
            Expanded(
              child: rows.isEmpty
                  ? const _ReaderEmptyState(icon: Icons.menu_book_outlined, label: 'لا يحتوي هذا الملف على فهرس فصول داخلي')
                  : ListView.builder(
                      itemCount: rows.length,
                      itemBuilder: (context, index) {
                        final row = rows[index];
                        final page = row.node.dest?.pageNumber;
                        return ListTile(
                          contentPadding: EdgeInsetsDirectional.fromSTEB(18 + row.depth * 18.0, 4, 18, 4),
                          leading: Icon(row.depth == 0 ? Icons.bookmark_outline_rounded : Icons.subdirectory_arrow_left_rounded, color: const Color(0xFF16A89A)),
                          title: Text(row.node.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: row.depth == 0 ? FontWeight.w800 : FontWeight.w600)),
                          subtitle: page == null ? null : Text('الصفحة $page'),
                          trailing: page == null ? null : const Icon(Icons.chevron_left_rounded),
                          onTap: page == null ? null : () {
                            Navigator.pop(sheetContext);
                            unawaited(_controller.goToDest(row.node.dest, duration: const Duration(milliseconds: 160)).then((_) {}));
                          },
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
  }

  void _goToPage(int page) {
    if (!_controller.isReady || _controller.pageCount < 1) return;
    final target = page.clamp(1, _controller.pageCount).toInt();
    // A big jump should be instant: animating across dozens of intermediate
    // pages wastes raster work and makes the reader appear unresponsive.
    final duration = (target - _page).abs() > 4
        ? Duration.zero
        : const Duration(milliseconds: 120);
    unawaited(_controller.goToPage(pageNumber: target, duration: duration));
    _onPageChanged(target);
  }

  Future<void> _toggleBookmark() async {
    final updated = [..._bookmarks];
    final removed = updated.remove(_page);
    if (!removed) updated.add(_page);
    updated.sort();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_bookmarksKey, updated.map((page) => '$page').toList());
    if (!mounted) return;
    setState(() => _bookmarks = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(removed ? 'أُزيلت علامة الصفحة $_page.' : 'حُفظت الصفحة $_page في العلامات.'),
      ),
    );
  }

  Future<void> _removeBookmark(int page) async {
    final updated = [..._bookmarks]..remove(page);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_bookmarksKey, updated.map((item) => '$item').toList());
    if (mounted) setState(() => _bookmarks = updated);
  }

  Future<void> _addNote() async {
    final controller = TextEditingController();
    final note = await showDialog<String>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text('ملاحظة للصفحة $_page'),
          content: TextField(
            controller: controller,
            autofocus: true,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'اكتب ملاحظتك عن هذه الصفحة'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('حفظ')),
          ],
        ),
      ),
    );
    controller.dispose();
    if (note == null || note.isEmpty || !mounted) return;
    final updated = [_BookNote(page: _page, text: note), ..._notes];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_notesKey, updated.map((item) => jsonEncode(item.toJson())).toList());
    if (mounted) setState(() => _notes = updated);
  }

  Future<void> _removeNote(_BookNote note) async {
    final updated = [..._notes]..remove(note);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_notesKey, updated.map((item) => jsonEncode(item.toJson())).toList());
    if (mounted) setState(() => _notes = updated);
  }

  Future<void> _showPagePicker() async {
    if (_totalPages < 1) return;
    final input = TextEditingController(text: '$_page');
    final target = await showDialog<int>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('الانتقال إلى صفحة'),
          content: TextField(
            controller: input,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'رقم الصفحة', helperText: 'من 1 إلى $_totalPages'),
            onSubmitted: (_) => Navigator.pop(dialogContext, _parsePage(input.text)),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton.icon(
              onPressed: () => Navigator.pop(dialogContext, _parsePage(input.text)),
              icon: const Icon(Icons.arrow_forward_rounded),
              label: const Text('انتقال'),
            ),
          ],
        ),
      ),
    );
    input.dispose();
    if (target != null) _goToPage(target);
  }

  int? _parsePage(String value) {
    final western = value
        .replaceAllMapped(RegExp('[٠-٩]'), (match) => '${match.group(0)!.codeUnitAt(0) - 0x0660}')
        .replaceAllMapped(RegExp('[۰-۹]'), (match) => '${match.group(0)!.codeUnitAt(0) - 0x06F0}');
    final page = int.tryParse(western.trim());
    return page != null && page >= 1 && page <= _totalPages ? page : null;
  }

  Future<void> _showQuickAccess() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: StatefulBuilder(
          builder: (sheetContext, setSheetState) => SizedBox(
            height: MediaQuery.of(sheetContext).size.height * .7,
            child: DefaultTabController(
              length: 2,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 2, 20, 10),
                  child: Row(children: [
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('الوصول السريع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                      Text('علاماتك وملاحظاتك المحفوظة', style: TextStyle(
                        color: Theme.of(sheetContext).colorScheme.onSurface.withValues(alpha: .68), fontSize: 12)),
                    ])),
                    IconButton.filledTonal(
                      tooltip: _readerNight ? 'إيقاف القراءة الليلية' : 'قراءة ليلية بنص أبيض',
                      icon: Icon(_readerNight ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
                      onPressed: () {
                        unawaited(_toggleNight());
                        setSheetState(() {});
                      },
                    ),
                    if (Uri.tryParse(widget.url)?.hasScheme == true)
                      IconButton(
                        tooltip: 'فتح المصدر في المتصفح',
                        icon: const Icon(Icons.open_in_browser_rounded),
                        onPressed: () => launchUrl(
                          Uri.parse(widget.url), mode: LaunchMode.externalApplication),
                      ),
                    IconButton.filledTonal(
                      tooltip: 'اختيار رقم صفحة',
                      onPressed: () { Navigator.pop(sheetContext); _showPagePicker(); },
                      icon: const Icon(Icons.pin_rounded),
                    ),
                  ]),
                ),
                const TabBar(tabs: [
                  Tab(icon: Icon(Icons.bookmarks_outlined), text: 'العلامات'),
                  Tab(icon: Icon(Icons.sticky_note_2_outlined), text: 'الملاحظات'),
                ]),
                Expanded(child: TabBarView(children: [
                  _bookmarks.isEmpty
                      ? const _ReaderEmptyState(icon: Icons.bookmark_border_rounded, label: 'لا توجد صفحات محفوظة بعد')
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _bookmarks.length,
                          itemBuilder: (context, index) {
                            final page = _bookmarks[index];
                            return Card(
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.bookmark_added_rounded)),
                                title: Text('الصفحة $page'),
                                subtitle: const Text('علامة محفوظة'),
                                onTap: () { Navigator.pop(sheetContext); _goToPage(page); },
                                trailing: IconButton(
                                  tooltip: 'إلغاء حفظ الصفحة $page',
                                  icon: const Icon(Icons.bookmark_remove_outlined, color: Colors.redAccent),
                                  onPressed: () async { await _removeBookmark(page); setSheetState(() {}); },
                                ),
                              ),
                            );
                          },
                        ),
                  _notes.isEmpty
                      ? const _ReaderEmptyState(icon: Icons.note_alt_outlined, label: 'لا توجد ملاحظات محفوظة بعد')
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _notes.length,
                          itemBuilder: (context, index) {
                            final note = _notes[index];
                            return Card(
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.sticky_note_2_rounded)),
                                title: Text(note.text, maxLines: 2, overflow: TextOverflow.ellipsis),
                                subtitle: Text('الصفحة ${note.page}'),
                                onTap: () { Navigator.pop(sheetContext); _goToPage(note.page); },
                                trailing: IconButton(
                                  tooltip: 'حذف الملاحظة',
                                  icon: const Icon(Icons.delete_outline_rounded),
                                  onPressed: () async { await _removeNote(note); setSheetState(() {}); },
                                ),
                              ),
                            );
                          },
                        ),
                ])),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPageControls() => PdfReaderControls(
        darkMode: _readerNight,
        pageNumber: _page,
        pageCount: _totalPages,
        // The slider previews inside its own State. Avoid rebuilding the
        // entire reader while the user drags the thumb across hundreds of pages.
        onPreviewPage: (_) {},
        onGoToPage: _goToPage,
        onShowThumbnails: _showThumbnails,
      );

  @override
  void dispose() {
    _textSearcher?.removeListener(_onSearchChanged);
    _textSearcher?.dispose();
    _saveProgressTimer?.cancel();
    unawaited(_saveProgress(_page));
    _pageNotifier.dispose();
    super.dispose();
  }


  Widget _buildDocumentViewer() {
    final params = PdfViewerParams(
      margin: 6,
      backgroundColor: const Color(0xFFE9EEF5),
      pageDropShadow: const BoxShadow(color: Color(0x19000000), blurRadius: 3),
      // Keep the area being rasterized close to the viewport on low-end phones;
      // large cache extents cause expensive renders during rapid flings.
      verticalCacheExtent: 1.25,
      maxImageBytesCachedOnMemory: 96 * 1024 * 1024,
      // Lower inertia friction improves long vertical flings without forcing
      // page-by-page scrolling; the view still loads PDF pages on demand.
      interactionEndFrictionCoefficient: 0.00000125,
      // Drag the side thumb to jump across dozens of pages without repeated
      // swipes. This is a pdfrx overlay and does not change the document state.
      viewerOverlayBuilder: (context, size, handleLinkTap) => [
        PdfViewerScrollThumb(
          controller: _controller,
          orientation: ScrollbarOrientation.left,
          thumbSize: const Size(37, 46),
          margin: 3,
          thumbBuilder: (context, thumbSize, pageNumber, controller) =>
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xDA10253F),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: Colors.white70),
                ),
                alignment: Alignment.center,
                child: Text(
                  pageNumber?.toString() ?? '–',
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                    color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800,
                  ),
                ),
              ),
        ),
      ],
      pagePaintCallbacks: [if (_textSearcher != null) _textSearcher!.pageTextMatchPaintCallback],
      behaviorControlParams: const PdfViewerBehaviorControlParams(
        // Allow momentum frames to paint from low-res previews first; delay
        // expensive full resolution renders until movement is less intense.
        trailingPageLoadingDelay: Duration(milliseconds: 160),
        pageImageCachingDelay: Duration(milliseconds: 25),
        partialImageLoadingDelay: Duration(milliseconds: 90),
        enableLowResolutionPagePreview: true,
        loadPageDimensionsOnDemand: true,
      ),
      loadingBannerBuilder: (context, bytesDownloaded, totalBytes) =>
        const Center(child: CircularProgressIndicator(color: Color(0xFF16A89A))),
      errorBannerBuilder: (context, error, stackTrace, documentRef) => Center(
        child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Card(
          child: Padding(padding: const EdgeInsets.all(22), child: Column(
            mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.warning_amber_rounded, size: 44, color: Color(0xFFB42318)),
              const SizedBox(height: 12),
              const Text('تعذّر فتح الكتاب', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Text(widget.localPath == null
                ? 'تحقق من الاتصال بالإنترنت، أو حمّل الكتاب من المكتبة لفتحه دون إنترنت.'
                : 'قد يكون ملف الكتاب غير صالح. حاول تنزيله مجدداً.', textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton(onPressed: () => Navigator.of(context).maybePop(), child: const Text('العودة للمكتبة')),
            ],
          )),
        )),
      ),
      onPageChanged: _onPageChanged,
      onViewerReady: _onViewerReady,
    );
    if (widget.localPath != null && widget.localPath!.isNotEmpty) {
      return PdfViewer.file(widget.localPath!, controller: _controller,
        initialPageNumber: _initialPage, params: params);
    }
    return PdfViewer.uri(DownloadedBooks.directPdfUri(widget.url),
      controller: _controller, initialPageNumber: _initialPage,
      params: params, timeout: const Duration(seconds: 30));
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: _readerNight ? const Color(0xFF0D1522) : const Color(0xFFE9EEF5),
          appBar: AppBar(
            backgroundColor: const Color(0xFF10253F),
            foregroundColor: Colors.white,
            elevation: 0,
            titleSpacing: 0,
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
              const Text('قارئ المناهج • يحفظ تقدمك تلقائياً', style: TextStyle(fontSize: 10, color: Colors.white70)),
            ]),
            actions: [
              IconButton(
                tooltip: 'بحث داخل الكتاب',
                onPressed: _textSearcher == null ? null : _showBookSearch,
                icon: const Icon(Icons.search_rounded),
              ),
              IconButton(
                tooltip: _outlineLoaded && _outline.isEmpty ? 'الفهرس غير متاح في هذا الملف' : 'فهرس الفصول',
                onPressed: _showContents,
                icon: const Icon(Icons.segment_rounded),
              ),
              ValueListenableBuilder<int>(
                valueListenable: _pageNotifier,
                builder: (_, _, _) => IconButton(
                  tooltip: _currentPageBookmarked ? 'إلغاء حفظ الصفحة الحالية' : 'حفظ الصفحة الحالية',
                  onPressed: _stateLoaded ? _toggleBookmark : null,
                  icon: Icon(_currentPageBookmarked ? Icons.bookmark_added_rounded : Icons.bookmark_add_outlined),
                  color: _currentPageBookmarked ? const Color(0xFFFFD166) : Colors.white,
                ),
              ),
              IconButton(tooltip: 'ملاحظة لهذه الصفحة', onPressed: _stateLoaded ? _addNote : null, icon: const Icon(Icons.note_add_outlined)),
              IconButton(
                tooltip: 'العلامات والملاحظات والوضع الليلي والتنقل',
                onPressed: _showQuickAccess,
                icon: Badge(
                  isLabelVisible: _bookmarks.isNotEmpty || _notes.isNotEmpty,
                  label: Text('${_bookmarks.length + _notes.length}'),
                  child: const Icon(Icons.toc_rounded),
                ),
              ),
              const SizedBox(width: 4),
            ],
          ),
          // Invert only the document viewport, not the toolbar or dialogs.
          // This converts printed black ink to white in night mode while leaving
          // all original PDF bytes untouched. Identity filter preserves the
          // viewer element and its position when toggling the mode.
          body: _stateLoaded ? RepaintBoundary(child: ColorFiltered(
              colorFilter: _readerNight ? _nightPagesFilter : _normalPagesFilter,
              child: _buildDocumentViewer(),
            )) : const Center(child: CircularProgressIndicator(color: Color(0xFF16A89A))),
          bottomNavigationBar: _stateLoaded
              ? ValueListenableBuilder<int>(valueListenable: _pageNotifier,
                  builder: (_, _, _) => _buildPageControls()) : null,
        ),
      );
}

class _ReaderEmptyState extends StatelessWidget {
  final IconData icon;
  final String label;

  const _ReaderEmptyState({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 38, color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .42)),
          const SizedBox(height: 10),
          Text(label, style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .68),
            fontWeight: FontWeight.w700)),
        ]),
      );
}

class _BookNote {
  final int page;
  final String text;

  const _BookNote({required this.page, required this.text});

  Map<String, dynamic> toJson() => {'page': page, 'text': text};

  factory _BookNote.fromJson(Map<String, dynamic> json) => _BookNote(
        page: (json['page'] as num?)?.toInt() ?? 1,
        text: json['text'] as String? ?? '',
      );
}
