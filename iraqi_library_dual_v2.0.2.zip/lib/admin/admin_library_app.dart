import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/library_catalog.dart';
import '../services/github_publisher.dart';
import '../services/library_repository.dart';

const kBlue = Color(0xff496af2);
const kInk = Color(0xff172748);
const kBg = Color(0xfff5f7fc);

class IraqiLibraryAdminApp extends StatelessWidget {
  const IraqiLibraryAdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'مدير المكتبة العراقية',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: kBg,
          colorScheme: ColorScheme.fromSeed(seedColor: kBlue),
          appBarTheme: const AppBarTheme(backgroundColor: kBg, foregroundColor: kInk),
          cardTheme: const CardThemeData(color: Colors.white, elevation: 0),
          inputDecorationTheme: InputDecorationTheme(
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          ),
        ),
        home: const Directionality(textDirection: TextDirection.rtl, child: ManagerHome()),
      );
}

class ManagerHome extends StatefulWidget {
  const ManagerHome({super.key});
  @override
  State<ManagerHome> createState() => _ManagerHomeState();
}

class _ManagerHomeState extends State<ManagerHome> {
  final LibraryRepository _repo = LibraryRepository();
  final GitHubPublisher _publisher = GitHubPublisher();
  LibraryCatalog? _doc;
  LibraryCatalog? _published;
  String? _baseSha;
  bool _dirty = false, _busy = false, _hasToken = false, _remoteConflict = false;
  String _status = 'مخزّن محلياً';
  int _tab = 0;
  final List<Map<String, String>> _path = [];
  String _search = '';

  @override
  void initState() { super.initState(); _initialize(); }

  Future<void> _initialize() async {
    try {
      final baseline = await _repo.cachedOrPackaged();
      final dirty = await _repo.hasDraft();
      final draft = dirty ? await _repo.loadDraft() : null;
      final token = await _publisher.hasToken;
      if (!mounted) return;
      setState(() {
        _published = baseline;
        _doc = draft ?? baseline.copy();
        _dirty = draft != null;
        _hasToken = token;
      });
      if (token && LibraryEndpoint.configured) {
        await _refreshFromGitHub(silent: true);
      }
    } catch (e) { _toast('تعذّر تحميل بيانات الإدارة: $e'); }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 5)));
  }

  Future<void> _save(LibraryCatalog next) async {
    try {
      next.validate();
      await _repo.saveDraft(next);
      if (!mounted) return;
      setState(() { _doc = next; _dirty = true; _status = 'تعديلات غير منشورة'; });
      _toast('تم الحفظ محلياً؛ اضغط «نشر» لإظهاره للمستخدمين');
    } catch (e) { _toast('لم يُقبل التعديل: $e'); }
  }

  Future<void> _refreshFromGitHub({bool silent = false}) async {
    if (_busy) return;
    if (!_hasToken) { if (!silent) _toast('أضف رمز GitHub من الإعدادات أولاً'); return; }
    if (!LibraryEndpoint.configured) { if (!silent) _toast('المستودع لم يهيّأ أثناء بناء APK'); return; }
    setState(() => _busy = true);
    try {
      final remote = await _publisher.fetch();
      if (!mounted) return;
      // A local draft is based on the previously published baseline. Never
      // replace its base SHA with a newer remote SHA: that would lose edits.
      final conflict = _dirty && remote.catalog != null && _published != null &&
          jsonEncode(remote.catalog!.toJson()) != jsonEncode(_published!.toJson());
      setState(() {
        _remoteConflict = conflict;
        _baseSha = conflict ? null : remote.sha;
        if (!conflict && remote.catalog != null) {
          _published = remote.catalog;
          if (!_dirty) _doc = remote.catalog!.copy();
        }
        _status = conflict ? 'توجد نسخة أحدث من مسودتك: ألغِ المسودة أو ادمج التغييرات خارج التطبيق' :
          remote.catalog == null ? 'الملف لم يُنشر بعد' :
          (_dirty ? 'مسودتك محفوظة؛ لا توجد تغييرات خارجية' : 'تم تحميل النسخة المنشورة');
      });
      if (!conflict && !_dirty && remote.catalog != null) {
        await _repo.markPublished(remote.catalog!);
      }
      if (!silent) _toast(_status);
    } catch (e) { if (!silent) _toast('$e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _publish() async {
    if (_doc == null || _busy) return;
    if (_remoteConflict) { _toast('يوجد تعارض مع نسخة GitHub؛ حمّل النسخة المنشورة أولاً بعد مراجعة مسودتك'); return; }
    if (!_hasToken) { _toast('أدخل رمز GitHub من الإعدادات'); setState(() => _tab = 4); return; }
    if (!LibraryEndpoint.configured) { _toast('المستودع غير مهيأ في ملف البناء'); return; }
    setState(() => _busy = true);
    try {
      final result = await _publisher.publish(draft: _doc!, baseSha: _baseSha);
      final published = result.catalog!;
      await _repo.markPublished(published);
      if (!mounted) return;
      setState(() {
        _doc = published.copy(); _published = published; _baseSha = result.sha;
        _dirty = false; _remoteConflict = false;
        _status = 'تم النشر بنجاح • الإصدار ${published.revision}';
      });
      _toast('نُشرت البيانات على GitHub. ستصل للمستخدمين عند المزامنة.');
    } catch (e) { _toast('تعذّر النشر: $e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  void _openPath(String type, Map<String, dynamic> item) {
    setState(() => _path.add({'type': type, 'id': item['id'].toString(), 'name': LibraryCatalog.name(item)}));
  }

  String get _currentType => switch (_path.length) {
    0 => 'stage', 1 => 'grade', 2 => 'subject', _ => 'book',
  };

  String? get _currentParent => _path.isEmpty ? null : _path.last['id'];

  List<Map<String, dynamic>> _shown() {
    final doc = _doc;
    if (doc == null) return [];
    if (_currentType == 'stage') return doc.sorted(doc.stages);
    return doc.children(_path.last['type']!, _path.last['id']!);
  }

  String _label(String type) => switch (type) {
    'stage' => 'مرحلة', 'grade' => 'صف', 'subject' => 'مادة', _ => 'كتاب',
  };

  IconData _typeIcon(String type) => switch (type) {
    'stage' => Icons.school_outlined, 'grade' => Icons.view_module_outlined,
    'subject' => Icons.menu_book_outlined, _ => Icons.auto_stories_outlined,
  };

  Color _hex(String? color) {
    if (color == null || !LibraryCatalog.isColor(color)) return kBlue;
    return Color(int.parse('FF${color.substring(1)}', radix: 16));
  }

  Future<void> _showEditor(String type, {Map<String, dynamic>? original}) async {
    final titleCtl = TextEditingController(text: original == null ? '' : LibraryCatalog.name(original));
    final descCtl = TextEditingController(text: original?['description']?.toString() ?? '');
    final urlCtl = TextEditingController(text: original?['url']?.toString() ?? '');
    final colorCtl = TextEditingController(text: original?['color']?.toString() ?? (type == 'stage' ? '#5274F1' : '#6484EA'));
    String icon = ['book', 'school', 'star'].contains(original?['icon']) ? original!['icon'] as String : 'book';
    bool visible = original?['visible'] != false;
    final key = GlobalKey<FormState>();
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, update) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23)),
        title: Text(original == null ? 'إضافة ${_label(type)}' : 'تعديل ${_label(type)}'),
        content: Form(key: key, child: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(controller: titleCtl, autofocus: true,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(labelText: type == 'book' ? 'عنوان الكتاب' : 'الاسم'),
              validator: (v) => (v == null || v.trim().isEmpty || v.trim().length > 180)
                ? 'اكتب اسماً لا يتجاوز 180 حرفاً' : null,
            ),
            if (type == 'stage') ...[
              const SizedBox(height: 12),
              TextFormField(controller: descCtl, decoration: const InputDecoration(labelText: 'وصف المرحلة')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(initialValue: icon,
                decoration: const InputDecoration(labelText: 'أيقونة المرحلة'),
                items: const [DropdownMenuItem(value:'book', child: Text('كتاب')),
                  DropdownMenuItem(value:'school', child: Text('مدرسة')),
                  DropdownMenuItem(value:'star', child: Text('نجمة'))],
                onChanged: (v) => update(() => icon = v ?? 'book'),
              ),
            ],
            if (type == 'grade' || type == 'stage') ...[
              const SizedBox(height: 12),
              TextFormField(controller: colorCtl,
                decoration: const InputDecoration(labelText: 'اللون HEX', hintText: '#496AF2'),
                validator: (v) => LibraryCatalog.isColor(v) ? null : 'اكتب اللون بصيغة #RRGGBB',
              ),
            ],
            if (type == 'book') ...[
              const SizedBox(height: 12),
              TextFormField(controller: urlCtl, maxLines: 3, minLines: 2,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(labelText: 'رابط PDF أو Google Drive', hintText: 'https://...'),
                validator: (v) => (v == null || v.trim().isEmpty || LibraryCatalog.validWebUrl(v))
                  ? null : 'اكتب رابط http أو https صحيحاً',
              ),
            ],
            const SizedBox(height: 8),
            SwitchListTile.adaptive(title: const Text('ظاهر للمستخدمين بعد النشر'),
              value: visible, onChanged: (v) => update(() => visible = v)),
          ],
        ))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () {
            if (key.currentState?.validate() != true) return;
            Navigator.pop(ctx, {
              'title': titleCtl.text.trim(), 'description': descCtl.text.trim(),
              'url': urlCtl.text.trim(), 'color': colorCtl.text.trim(),
              'visible': visible, 'icon': icon,
            });
          }, child: const Text('حفظ')),
        ],
      )),
    );
    titleCtl.dispose(); descCtl.dispose(); urlCtl.dispose(); colorCtl.dispose();
    if (result == null || _doc == null) return;
    final next = _doc!.copy();
    final list = next.group(type);
    Map<String, dynamic> edited;
    if (original != null) {
      edited = list.firstWhere((e) => e['id'] == original['id']);
    } else {
      edited = {
        'id': LibraryCatalog.newId(type),
        'order': list.isEmpty ? 0 : list.map((e) => e['order'] as int).reduce((a, b) => a > b ? a : b) + 1,
        if (type == 'grade') 'stageId': _currentParent,
        if (type == 'subject') 'gradeId': _currentParent,
        if (type == 'book') 'subjectId': _currentParent,
      };
      list.add(edited);
    }
    if (type == 'book') {
      edited['title'] = result['title']; edited['url'] = result['url'];
    } else {
      edited['name'] = result['title'];
    }
    edited['visible'] = result['visible'];
    if (type == 'stage') {
      edited['description'] = result['description'];
      edited['color'] = result['color']; edited['icon'] = result['icon'];
    }
    if (type == 'grade') edited['color'] = result['color'];
    await _save(next);
  }

  Future<void> _delete(String type, Map<String, dynamic> item) async {
    final descendants = _doc!.descendants(type, item['id'].toString());
    final agreed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تأكيد الحذف'),
      content: Text('حذف «${LibraryCatalog.name(item)}» سيحذف معه $descendants عنصراً تابعاً له. يمكن التراجع قبل النشر بإعادة تحميل النسخة المنشورة.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف'))],
    ));
    if (agreed != true) return;
    final next = _doc!.copy();
    next.deleteTree(type, item['id'].toString());
    await _save(next);
  }

  Future<void> _toggle(String type, Map<String, dynamic> item) async {
    final next = _doc!.copy();
    final target = next.group(type).firstWhere((e) => e['id'] == item['id']);
    target['visible'] = !LibraryCatalog.visible(target);
    await _save(next);
  }

  Future<void> _reorder(String type, String itemId, int direction) async {
    if (_doc == null) return;
    final next = _doc!.copy();
    final list = type == 'stage' ? next.sorted(next.stages) :
      next.children(_path.last['type']!, _currentParent!);
    final pos = list.indexWhere((e) => e['id'] == itemId);
    final other = pos + direction;
    if (pos < 0 || other < 0 || other >= list.length) return;
    final a = list[pos], b = list[other];
    final oldA = a['order']; a['order'] = b['order']; b['order'] = oldA;
    await _save(next);
  }

  Widget _metric(String value, String label, IconData icon, Color color) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color), const SizedBox(height: 13),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 23, color: kInk)),
      Text(label, style: const TextStyle(color: Color(0xff76849b), fontSize: 12)),
    ]),
  );

  Widget _dashboard() {
    final doc = _doc!;
    return ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 28), children: [
      Container(padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: const LinearGradient(colors: [Color(0xff5053e8), Color(0xff2b89ed)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.admin_panel_settings_outlined, color: Colors.white, size: 34),
          const SizedBox(height: 12),
          const Text('إدارة مكتبتك من هاتفك', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          const Text('أضف مراحل وصفوفاً ومواد وكتباً، ثم انشرها للمستخدمين بنقرة واحدة.',
            style: TextStyle(color: Color(0xffe6ebff), height: 1.7)),
          const SizedBox(height: 17),
          FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: kBlue),
            onPressed: () => setState(() { _tab = 1; _path.clear(); }),
            icon: const Icon(Icons.add_circle_outline), label: const Text('إدارة المراحل')),
        ]),
      ),
      const SizedBox(height: 17),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35,
        children: [
          _metric('${doc.stages.length}', 'المراحل الدراسية', Icons.school_outlined, kBlue),
          _metric('${doc.grades.length}', 'الصفوف الدراسية', Icons.grid_view_outlined, const Color(0xff11a98e)),
          _metric('${doc.subjects.length}', 'المواد الدراسية', Icons.category_outlined, const Color(0xff8d62d5)),
          _metric('${doc.books.length}', 'الكتب المدرسية', Icons.menu_book_outlined, const Color(0xffe6a14c)),
        ],
      ),
      const SizedBox(height: 15),
      _notice(Icons.cloud_sync, 'حالة النشر', _status,
        _dirty ? const Color(0xfff3a32b) : const Color(0xff16977e)),
      const SizedBox(height: 12),
      _notice(Icons.verified_user_outlined, 'الحماية',
        'المستخدم يقرأ فقط، ولا يحتوي تطبيقه على أدوات الإدارة أو مفتاح الكتابة.', kBlue),
    ]);
  }

  Widget _notice(IconData icon, String title, String description, Color color) =>
    Container(padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(
          color: color.withValues(alpha: .09), borderRadius: BorderRadius.circular(13)),
          child: Icon(icon, color: color)),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          Text(description, style: const TextStyle(color: Color(0xff728097), fontSize: 12)),
        ])),
      ]),
    );

  Widget _hierarchy() {
    final type = _currentType, list = _shown();
    return Column(children: [
      Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: Row(children: [
          if (_path.isNotEmpty) IconButton(onPressed: () => setState(() => _path.removeLast()),
            icon: const Icon(Icons.arrow_forward_ios, size: 19)),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_path.isEmpty ? 'المراحل الدراسية' : _path.last['name']!,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            Text('إدارة ${_label(type)} • ${list.length} عناصر',
              style: const TextStyle(color: Color(0xff71809c), fontSize: 12)),
          ])),
          FilledButton.icon(onPressed: () => _showEditor(type),
            icon: const Icon(Icons.add, size: 18), label: Text('إضافة ${_label(type)}')),
        ]),
      ),
      if (_path.isNotEmpty)
        SizedBox(height: 37, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            TextButton(onPressed: () => setState(() => _path.clear()), child: const Text('المراحل')),
            ..._path.asMap().entries.map((entry) => TextButton(
              onPressed: () => setState(() => _path.removeRange(entry.key + 1, _path.length)),
              child: Text('› ${entry.value['name']}'),
            )),
          ])),
      Expanded(child: list.isEmpty
        ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.inventory_2_outlined, color: Color(0xff9eacc4), size: 49),
            const SizedBox(height: 13),
            Text('لا يوجد ${_label(type)} هنا'),
            const SizedBox(height: 9),
            OutlinedButton.icon(onPressed: () => _showEditor(type), icon: const Icon(Icons.add),
              label: const Text('إضافة الآن')),
          ]))
        : ListView.builder(padding: const EdgeInsets.fromLTRB(13, 8, 13, 24),
            itemCount: list.length, itemBuilder: (ctx, i) {
              final item = list[i];
              final color = _hex(item['color']?.toString());
              final isBook = type == 'book';
              final childCount = isBook ? 0 : _doc!.children(type, item['id'].toString()).length;
              return Card(margin: const EdgeInsets.only(bottom: 9), shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)),
                child: InkWell(borderRadius: BorderRadius.circular(18),
                  onTap: isBook ? () => _showEditor(type, original: item) : () => _openPath(type, item),
                  child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                    Container(width: 47, height: 47, decoration: BoxDecoration(
                      color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)),
                      child: Icon(_typeIcon(type), color: color)),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(LibraryCatalog.name(item), style: TextStyle(fontWeight: FontWeight.w800,
                        decoration: LibraryCatalog.visible(item) ? null : TextDecoration.lineThrough)),
                      Text(isBook ? ((item['url'] ?? '').toString().isNotEmpty ? 'الرابط متوفر' : 'بدون رابط') :
                        '$childCount عناصر تابعة', style: const TextStyle(color: Color(0xff8591a7), fontSize: 11)),
                    ])),
                    PopupMenuButton<String>(tooltip: 'خيارات', onSelected: (value) {
                      switch (value) {
                        case 'edit': _showEditor(type, original: item); break;
                        case 'toggle': _toggle(type, item); break;
                        case 'delete': _delete(type, item); break;
                        case 'up': _reorder(type, item['id'] as String, -1); break;
                        case 'down': _reorder(type, item['id'] as String, 1); break;
                      }
                    }, itemBuilder: (_) => [
                      const PopupMenuItem(value:'edit', child: Text('تعديل')),
                      PopupMenuItem(value:'toggle', child: Text(LibraryCatalog.visible(item) ? 'إخفاء' : 'إظهار')),
                      const PopupMenuItem(value:'up', child: Text('تحريك للأعلى')),
                      const PopupMenuItem(value:'down', child: Text('تحريك للأسفل')),
                      const PopupMenuItem(value:'delete', child: Text('حذف', style: TextStyle(color: Colors.red))),
                    ]),
                    if (!isBook) const Icon(Icons.chevron_left, color: Color(0xffa0acc0)),
                  ])),
                ),
              );
            })),
    ]);
  }

  Widget _allBooks() {
    final books = _doc!.sorted(_doc!.books).where((b) {
      final q = _search.trim().toLowerCase();
      return q.isEmpty || LibraryCatalog.name(b).toLowerCase().contains(q) ||
        (b['url'] ?? '').toString().toLowerCase().contains(q);
    }).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 13, 16, 7), child: TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث باسم الكتاب أو الرابط'),
        onChanged: (v) => setState(() => _search = v),
      )),
      Expanded(child: ListView.builder(padding: const EdgeInsets.fromLTRB(14, 7, 14, 20),
        itemCount: books.length, itemBuilder: (ctx, i) {
          final book = books[i];
          return Card(child: ListTile(
            leading: const Icon(Icons.menu_book_outlined, color: kBlue),
            title: Text(LibraryCatalog.name(book)),
            subtitle: Text((book['url'] ?? '').toString(), maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: IconButton(icon: const Icon(Icons.edit_note), onPressed: () => _showEditor('book', original: book)),
            onTap: () => _showEditor('book', original: book),
          ));
        })),
      Padding(padding: const EdgeInsets.all(12), child: OutlinedButton.icon(
        onPressed: () => setState(() { _tab = 1; _path.clear(); }),
        icon: const Icon(Icons.add), label: const Text('لإضافة كتاب: اختر المرحلة ← الصف ← المادة'))),
    ]);
  }

  Map<String, int> _changes() {
    final a = _published, b = _doc;
    final counts = <String, int>{};
    if (a == null || b == null) return counts;
    for (final type in ['stage','grade','subject','book']) {
      final old = {for (final e in a.group(type)) e['id'].toString(): jsonEncode(e)};
      final next = {for (final e in b.group(type)) e['id'].toString(): jsonEncode(e)};
      final keys = {...old.keys, ...next.keys};
      counts[type] = keys.where((id) => old[id] != next[id]).length;
    }
    return counts;
  }

  Future<void> _discardDraftAndLoadPublished() async {
    if (_busy) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('استبدال المسودة المحلية؟'),
      content: const Text('ستفقد كل التعديلات غير المنشورة في هذا الهاتف. لا يمكن التراجع بعد المتابعة.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة المنشور')),
      ],
    ));
    if (ok != true) return;
    try {
      final remote = await _publisher.fetch();
      final fresh = remote.catalog ?? await _repo.packaged();
      await _repo.markPublished(fresh);
      if (!mounted) return;
      setState(() {
        _doc = fresh.copy(); _published = fresh; _baseSha = remote.sha;
        _dirty = false; _remoteConflict = false;
        _status = 'تم استعادة الفهرس المنشور';
      });
      _toast('تم إلغاء المسودة المحلية واستعادة الفهرس المنشور');
    } catch (e) { _toast('$e'); }
  }

  Widget _publishPage() {
    final changes = _changes();
    return ListView(padding: const EdgeInsets.all(16), children: [
      _notice(Icons.cloud_upload_outlined, 'نشر التعديلات',
        'لا يرى المستخدمون مسودتك قبل الضغط على «نشر».', kBlue),
      const SizedBox(height: 15),
      ...['stage','grade','subject','book'].map((type) => Card(child: ListTile(
        leading: Icon(_typeIcon(type), color: kBlue),
        title: Text('تغييرات ${_label(type)}'),
        trailing: CircleAvatar(radius: 18, child: Text('${changes[type] ?? 0}')),
      ))),
      const SizedBox(height: 13),
      _notice(_dirty ? Icons.edit_outlined : Icons.check_circle_outline,
        _dirty ? 'توجد تعديلات غير منشورة' : 'النسخة الحالية', _status,
        _dirty ? const Color(0xffe7a346) : const Color(0xff139879)),
      const SizedBox(height: 17),
      FilledButton.icon(onPressed: _busy ? null : _publish,
        icon: const Icon(Icons.publish_outlined), label: const Text('نشر المراحل والصفوف والمواد والكتب'),
        style: FilledButton.styleFrom(padding: const EdgeInsets.all(17))),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: _busy ? null : () => _refreshFromGitHub(),
        icon: const Icon(Icons.sync), label: const Text('فحص آخر نسخة منشورة على GitHub')),
      const SizedBox(height: 9),
      OutlinedButton.icon(onPressed: _busy || !_hasToken ? null : _discardDraftAndLoadPublished,
        icon: const Icon(Icons.restore), label: const Text('إلغاء مسودتي واستعادة النسخة المنشورة')),
      const SizedBox(height: 13),
      const Text('تنبيه: عند وجود تغييرات نشرها محرر آخر، سيمنع GitHub استبدال الملف دون مراجعتها.\n'
        'التحديث لدى المستخدم يحتاج اتصالاً بالإنترنت ومستودعاً عاماً.',
        style: TextStyle(color: Color(0xff728097), height: 1.7)),
    ]);
  }

  Future<void> _saveTokenDialog() async {
    final controller = TextEditingController();
    final token = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('تسجيل دخول المدير إلى GitHub'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('أنشئ Fine-grained token بصلاحية Contents: Read and write للمستودع فقط. يُحفظ الرمز مشفراً على هاتف المدير، ولا يدخل في APK.'),
        const SizedBox(height: 14),
        TextField(controller: controller, obscureText: true, autocorrect: false, enableSuggestions: false,
          decoration: const InputDecoration(labelText: 'GitHub personal access token')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('حفظ آمن'))],
    ));
    controller.dispose();
    if (token == null || token.isEmpty) return;
    try {
      await _publisher.saveToken(token);
      if (mounted) setState(() => _hasToken = true);
      _toast('تم حفظ الرمز في مساحة تخزين آمنة');
      await _refreshFromGitHub();
    } catch (e) { _toast('$e'); }
  }

  Widget _settings() => ListView(padding: const EdgeInsets.all(16), children: [
    _notice(Icons.security, 'إعداد GitHub الآمن',
      _hasToken ? 'رمز المدير محفوظ على الجهاز' : 'لم تدخل رمز المدير بعد',
      _hasToken ? const Color(0xff13a085) : const Color(0xffe5a14e)),
    const SizedBox(height: 13),
    Card(child: Column(children: [
      ListTile(title: const Text('المستودع'), subtitle: Text(LibraryEndpoint.configured ?
        '${LibraryEndpoint.owner}/${LibraryEndpoint.repo}' : 'غير محدد في GitHub Actions')),
      const Divider(height: 1),
      ListTile(title: const Text('الفرع والملف'), subtitle: Text('${LibraryEndpoint.branch} / ${LibraryEndpoint.path}')),
      const Divider(height: 1),
      ListTile(title: const Text('عنوان مزامنة المستخدمين'), subtitle: SelectableText(
        LibraryEndpoint.configured ? LibraryEndpoint.rawUrl : 'غير مهيأ')),
    ])),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: _saveTokenDialog,
      icon: const Icon(Icons.key_outlined), label: Text(_hasToken ? 'تغيير رمز GitHub' : 'ربط حساب المدير')),
    const SizedBox(height: 9),
    OutlinedButton.icon(onPressed: _hasToken ? () async {
      await _publisher.clearToken();
      if (mounted) setState(() { _hasToken = false; _baseSha = null; });
      _toast('تم حذف رمز GitHub من هذا الجهاز');
    } : null,
      icon: const Icon(Icons.logout), label: const Text('فصل صلاحية النشر')),
    const SizedBox(height: 9),
    OutlinedButton.icon(onPressed: () => launchUrl(
      Uri.parse('https://github.com/settings/personal-access-tokens/new'),
      mode: LaunchMode.externalApplication,
    ), icon: const Icon(Icons.open_in_new), label: const Text('إنشاء رمز صلاحية محدودة على GitHub')),
    const SizedBox(height: 17),
    _notice(Icons.info_outline, 'التحديث التلقائي',
      'عندما تنشر الفهرس، يتعرف تطبيق المستخدم على المراحل والصفوف والمواد والكتب الجديدة عند الاتصال ومزامنة البيانات.', kBlue),
  ]);

  @override
  Widget build(BuildContext context) {
    final doc = _doc;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(
          color: kBlue, borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.local_library, color: Colors.white, size: 19)),
        const SizedBox(width: 10),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('مدير المكتبة العراقية', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          Text('لوحة التحكم الخاصة بك', style: TextStyle(fontSize: 10, color: Color(0xff8995ad))),
        ])),
      ]), actions: [
        if (_busy) const Padding(padding: EdgeInsets.all(14), child: SizedBox(
          height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))),
        IconButton(tooltip: 'نشر', icon: Badge(isLabelVisible: _dirty,
          child: const Icon(Icons.cloud_upload_outlined)), onPressed: () => setState(() => _tab = 3)),
      ]),
      body: doc == null ? const Center(child: CircularProgressIndicator()) :
        IndexedStack(index: _tab, children: [
          _dashboard(), _hierarchy(), _allBooks(), _publishPage(), _settings(),
        ]),
      bottomNavigationBar: NavigationBar(height: 73, selectedIndex: _tab,
        onDestinationSelected: (v) => setState(() { _tab = v; if (v == 1) _path.clear(); }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.account_tree_outlined), selectedIcon: Icon(Icons.account_tree), label: 'المراحل'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'الكتب'),
          NavigationDestination(icon: Icon(Icons.cloud_upload_outlined), selectedIcon: Icon(Icons.cloud_upload), label: 'النشر'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ]),
    );
  }
}
