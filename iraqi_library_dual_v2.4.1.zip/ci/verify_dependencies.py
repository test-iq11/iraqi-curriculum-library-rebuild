#!/usr/bin/env python3
"""Preflight for the pubspec regression that blocked the 2.4.0 build.

This is a static guard. It does not replace pub.dev resolution / `flutter pub get`.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
pubspec = (root / 'pubspec.yaml').read_text(encoding='utf-8')
workflow = (root / '.github/workflows/build-dual-apk.yml').read_text(encoding='utf-8')

picker = re.search(r'^\s{2}file_picker:\s*([^\s#]+)', pubspec, re.MULTILINE)
assert picker is not None, 'Missing file_picker dependency'
assert picker.group(1) == '10.3.10', (
    f'file_picker must be pinned to known published 10.3.10; got {picker.group(1)!r}. '
    'The previously selected 10.3.11 is retracted on pub.dev.'
)
assert 'file_picker: ^10.3.11' not in pubspec, 'Retracted dependency is still present'
assert 'flutter-version: "3.47.9"' in workflow, 'Expected tested Flutter version not pinned'
assert 'flutter create --no-pub' in workflow, 'Flutter create must not auto-resolve dependencies'
assert "flutter pub get" in workflow, 'Missing explicit dependency resolution'
assert 'flutter analyze --no-fatal-infos' in workflow, 'Analyzer step must be retained'
assert 'flutter test --reporter expanded' in workflow, 'Test step must be retained'
assert 'iraqi_library_dual_v2.4.1.zip' in workflow, 'Workflow ZIP filename mismatch'
assert "data/library.json" not in re.findall(r'^\s*-\s+[\'\"]([^\'\"]+)', workflow, re.M), 'Data must not be overwritten'
print('PASS: non-retracted file_picker 10.3.10 pinned; Flutter 3.47.9; explicit pub get, analyze, test, matching ZIP.')
