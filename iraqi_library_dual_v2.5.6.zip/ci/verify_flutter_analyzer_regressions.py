#!/usr/bin/env python3
"""Early, static regressions for the four analyzer constructs fixed in 2.5.3.

The Flutter analyzer remains authoritative; this simply catches accidental
re-introduction of the exact errors before package installation/build.
"""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
reader = (root / 'lib/user/book_pdf_screen.dart').read_text(encoding='utf-8')
controls = (root / 'lib/user/pdf_reader_controls.dart').read_text(encoding='utf-8')
reviews = (root / 'lib/user/restored_reviews_page.dart').read_text(encoding='utf-8')

assert 'height: PdfReaderControls.toolbarHeight,' in controls, 'Use the qualified toolbar height constant'
assert 'height: toolbarHeight,' not in controls, 'An undefined instance-level identifier was reintroduced'
assert 'const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [' not in reader, 'Theme lookup must not be in a const widget subtree'
assert "color: Theme.of(sheetContext).colorScheme.onSurface.withValues(alpha: .68)" in reader, 'Reader contrast regression'
assert 'if (mounted) {\n        _textSearcher?.startTextSearch(' in reader, 'Search mounted guard requires braces'
assert "if (mounted) {\n        ScaffoldMessenger.of(context).showSnackBar(" in reader, 'Error mounted guard requires braces'
assert 'if (id != null) {\n            setState(() {' in reviews, 'Review selection guard requires braces'
assert 'version: 2.5.6+35' in (root / 'pubspec.yaml').read_text(encoding='utf-8')
manager = (root / 'lib/admin/admin_library_app.dart').read_text(encoding='utf-8')
assert '_baseSha' not in manager, 'Unused GitHub SHA field/write remains'
assert '_remoteConflict' not in manager, 'Unused conflict-state field/write remains'
assert "import 'package:flutter/physics.dart';" not in reader, 'Redundant physics import remains'
assert '_publisher.fetch()' in manager and 'baseSha: latest.sha' in manager, 'GitHub publish must still use a fresh SHA'
print('PASS: known analyzer failures, including 2 unused fields and redundant import')
