import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../models/library_catalog.dart';
import '../services/library_repository.dart';
import 'downloaded_books.dart';

class IraqiLibraryUserApp extends StatelessWidget {
  const IraqiLibraryUserApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'المكتبة العراقية',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xff496af2), fontFamily: 'Roboto'),
        home: const Directionality(textDirection: TextDirection.rtl, child: LibraryWebShell()),
      );
}

class LibraryWebShell extends StatefulWidget {
  const LibraryWebShell({super.key});
  @override
  State<LibraryWebShell> createState() => _LibraryWebShellState();
}

class _LibraryWebShellState extends State<LibraryWebShell> with WidgetsBindingObserver {
  final LibraryRepository _repository = LibraryRepository();
  final DownloadedBooks _downloads = DownloadedBooks();
  late final WebViewController _web;
  LibraryCatalog? _catalog;
  bool _loaded = false;
  bool _syncing = false;
  DateTime? _lastSync;
  String? _syncError;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xfff6f8ff))
      ..addJavaScriptChannel('NativeLibrary', onMessageReceived: _bridge)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) async {
          _loaded = true;
          await _injectCatalog();
        },
        onNavigationRequest: (request) {
          final uri = Uri.tryParse(request.url);
          if (uri != null && (uri.scheme == 'http' || uri.scheme == 'https')) {
            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadFlutterAsset('assets/library_ui.html');
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      final cached = await _repository.cachedOrPackaged();
      if (!mounted) return;
      _catalog = cached;
      await _injectCatalog();
      await _refresh();
    } catch (e) {
      if (mounted) _message('تعذر تحميل الفهرس المحلي: $e');
    }
  }

  Future<void> _injectCatalog() async {
    if (!_loaded || _catalog == null) return;
    final json = jsonEncode(_catalog!.toJson()).replaceAll('\u2028', r'\u2028').replaceAll('\u2029', r'\u2029');
    try { await _web.runJavaScript('window.applyRemoteLibrary($json);'); } catch (_) {}
  }

  Future<void> _refresh() async {
    if (_syncing || !LibraryEndpoint.configured) return;
    _syncing = true;
    try {
      final remote = await _repository.refreshPublic();
      if (!mounted) return;
      if (remote != null) {
        _catalog = remote;
        await _injectCatalog();
        _syncError = null;
        _lastSync = DateTime.now();
      }
    } catch (e) { _syncError = '$e'; } finally { _syncing = false; }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        (_lastSync == null || DateTime.now().difference(_lastSync!).inMinutes >= 2)) {
      _refresh();
    }
  }

  Map<String, dynamic>? _book(String? id) {
    if (id == null || _catalog == null) return null;
    for (final b in _catalog!.books) {
      if (b['id'] == id && LibraryCatalog.visible(b)) return b;
    }
    return null;
  }

  Future<void> _bridge(JavaScriptMessage event) async {
    try {
      final payload = jsonDecode(event.message);
      if (payload is! Map) return;
      final action = payload['action']?.toString();
      final b = _book(payload['bookId']?.toString());
      if (action == 'readBook' && b != null) { await _read(b); return; }
      if (action == 'downloadBook' && b != null) { await _download(b); return; }
      if (action == 'copyBookLink' && b != null) {
        await Clipboard.setData(ClipboardData(text: b['url'].toString()));
        _message('تم نسخ رابط الكتاب'); return;
      }
      if (action == 'downloads') { await _showDownloads(); return; }
      if (action == 'reviews') { await _showReviews(); return; }
      if (action == 'exportJson') {
        await Clipboard.setData(ClipboardData(text: payload['data']?.toString() ?? '{}'));
        _message('تم نسخ بياناتك المحلية، ويمكن لصقها في ملف JSON'); return;
      }
      if (action == 'importClipboard') {
        _message('يمكن الاستيراد من داخل معاينة HTML.'); return;
      }
      if (action == 'sync') { await _refresh(); _message(_syncError ?? 'تم تحديث قائمة الكتب'); }
    } catch (e) { _message('تعذر تنفيذ الأمر: $e'); }
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 4)));
  }

  Future<void> _read(Map<String, dynamic> book) async {
    final url = (book['url'] ?? '').toString();
    if (!LibraryCatalog.validWebUrl(url)) { _message('رابط الكتاب غير متوفر'); return; }
    final localPath = await _downloads.localFile(book['id'].toString());
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(
      builder: (_) => BookPdfScreen(title: book['title'].toString(), url: url, localPath: localPath),
    ));
  }

  Future<void> _download(Map<String, dynamic> book) async {
    _message('بدأ تنزيل الكتاب. قد يستغرق بحسب حجم الملف.');
    try {
      final path = await _downloads.download(book);
      if (mounted) {
        _message('اكتمل الحفظ للقراءة دون إنترنت');
        await Navigator.push(context, MaterialPageRoute<void>(builder: (_) =>
          BookPdfScreen(title: book['title'].toString(), url: book['url'].toString(), localPath: path),
        ));
      }
    } catch (e) { _message('$e'); }
  }

  Future<void> _showDownloads() async {
    final map = await _downloads.entries();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('الكتب المحمّلة')),
      body: Directionality(textDirection: TextDirection.rtl,
        child: map.isEmpty ? const Center(child: Text('لم تحمّل أي كتاب بعد')) :
          ListView(children: map.entries.map((entry) {
            final value = Map<String, dynamic>.from(entry.value as Map);
            return ListTile(title: Text(value['title']?.toString() ?? 'كتاب'),
              leading: const Icon(Icons.picture_as_pdf_outlined),
              onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => BookPdfScreen(
                title: value['title']?.toString() ?? '', url: value['sourceUrl']?.toString() ?? '',
                localPath: value['path']?.toString(),
              ))),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
                await _downloads.remove(entry.key);
                if (context.mounted) Navigator.pop(context);
              }),
            );
          }).toList()),
      ),
    )));
  }

  Future<void> _showReviews() async {
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute<void>(builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('بطاقات المراجعة')),
      body: const Directionality(textDirection: TextDirection.rtl, child: Padding(
        padding: EdgeInsets.all(24), child: Center(child: Text(
          'واجهة بطاقات المراجعة الأصلية موجودة في مشروع Flutter السابق. لم تكن ملفات أسئلتها ضمن معاينة HTML المتاحة؛ يجب دمجها من ZIP الأصلي دون اختراع أسئلة من المناهج.',
          textAlign: TextAlign.center,
        )),
      )),
    )));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: WebViewWidget(controller: _web)),
      );
}

class BookPdfScreen extends StatelessWidget {
  const BookPdfScreen({super.key, required this.title, required this.url, this.localPath});
  final String title;
  final String url;
  final String? localPath;

  @override
  Widget build(BuildContext context) {
    final Uri uri = DownloadedBooks.directPdfUri(url);
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis), actions: [
        IconButton(tooltip: 'فتح المصدر في المتصفح', icon: const Icon(Icons.open_in_browser),
          onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)),
      ]),
      body: (localPath != null)
          ? PdfViewer.file(localPath!, params: const PdfViewerParams(margin: 6, verticalCacheExtent: 1.3))
          : PdfViewer.uri(uri, params: const PdfViewerParams(margin: 6, verticalCacheExtent: 1.3),
              timeout: const Duration(seconds: 30)),
      bottomNavigationBar: SafeArea(child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        child: Text('تمرير عمودي متواصل • كبّر بإصبعين • عند تعذر عرض Google Drive افتح المصدر من الأعلى',
          textAlign: TextAlign.center, style: Theme.of(context).textTheme.labelSmall),
      )),
    ));
  }
}
