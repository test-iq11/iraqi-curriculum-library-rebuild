import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_curriculum_library/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  testWidgets('the Iraqi library app opens in Arabic', (tester) async {
    await tester.pumpWidget(const AppBootstrap());
    await tester.pumpAndSettle();

    expect(find.text('مكتبتي'), findsOneWidget);
    expect(find.text('المراحل الدراسية'), findsOneWidget);
    expect(find.text('الاختبارات'), findsNothing);
    expect(find.text('مركز الاختبارات'), findsNothing);
  });
}
