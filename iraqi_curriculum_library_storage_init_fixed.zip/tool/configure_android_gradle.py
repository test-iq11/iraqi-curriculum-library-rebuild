from pathlib import Path
import re

root = Path('android/app')
kts = root / 'build.gradle.kts'
groovy = root / 'build.gradle'
path = kts if kts.exists() else groovy if groovy.exists() else None
if path is None:
    raise SystemExit('Android app Gradle file not found; run flutter create --platforms=android first.')
text = path.read_text(encoding='utf-8')

if path.suffix == '.kts':
    # The newer Flutter templates use Kotlin DSL.
    if re.search(r'compileSdk\s*=\s*flutter\.compileSdkVersion', text):
        text = re.sub(r'compileSdk\s*=\s*flutter\.compileSdkVersion', 'compileSdk = maxOf(flutter.compileSdkVersion, 35)', text, count=1)
    elif re.search(r'compileSdk\s*=\s*\d+', text):
        text = re.sub(r'compileSdk\s*=\s*\d+', lambda m: 'compileSdk = maxOf(' + m.group(0).split('=')[1].strip() + ', 35)', text, count=1)
    if 'isCoreLibraryDesugaringEnabled' not in text:
        pattern = r'(compileOptions\s*\{)'
        text, n = re.subn(pattern, r'\1\n        isCoreLibraryDesugaringEnabled = true', text, count=1)
        if n == 0:
            raise SystemExit('compileOptions block not found in Kotlin Gradle file.')
    if re.search(r'defaultConfig\s*\{', text) and 'multiDexEnabled' not in text:
        text = re.sub(r'(defaultConfig\s*\{)', r'\1\n        multiDexEnabled = true', text, count=1)
    dep = 'coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")'
    if 'desugar_jdk_libs' not in text:
        if re.search(r'dependencies\s*\{', text):
            text = re.sub(r'(dependencies\s*\{)', r'\1\n    ' + dep, text, count=1)
        else:
            text += '\n\ndependencies {\n    ' + dep + '\n}\n'
else:
    if re.search(r'compileSdkVersion\s+flutter\.compileSdkVersion', text):
        text = re.sub(r'compileSdkVersion\s+flutter\.compileSdkVersion', 'compileSdkVersion 35', text, count=1)
    elif re.search(r'compileSdk\s+flutter\.compileSdkVersion', text):
        text = re.sub(r'compileSdk\s+flutter\.compileSdkVersion', 'compileSdk 35', text, count=1)
    if 'coreLibraryDesugaringEnabled' not in text:
        text, n = re.subn(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', text, count=1)
        if n == 0:
            raise SystemExit('compileOptions block not found in Groovy Gradle file.')
    if re.search(r'defaultConfig\s*\{', text) and 'multiDexEnabled' not in text:
        text = re.sub(r'(defaultConfig\s*\{)', r'\1\n        multiDexEnabled true', text, count=1)
    dep = "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'"
    if 'desugar_jdk_libs' not in text:
        if re.search(r'dependencies\s*\{', text):
            text = re.sub(r'(dependencies\s*\{)', r'\1\n    ' + dep, text, count=1)
        else:
            text += '\n\ndependencies {\n    ' + dep + '\n}\n'


# Disable R8/resource shrinking for release builds. With R8 enabled, the
# shared_preferences Pigeon API (SharedPreferencesApiRegistrar.getAll) is
# renamed/stripped, causing NoSuchMethodError at startup on the phone.
def _disable_shrink(text, kts):
    if kts:
        if 'isMinifyEnabled' in text:
            text = re.sub(r'isMinifyEnabled\s*=\s*\w+', 'isMinifyEnabled = false', text)
            text = re.sub(r'isShrinkResources\s*=\s*\w+', 'isShrinkResources = false', text)
            return text
        lines = 'isMinifyEnabled = false\n            isShrinkResources = false'
    else:
        if 'minifyEnabled' in text:
            text = re.sub(r'minifyEnabled\s+\w+', 'minifyEnabled false', text)
            text = re.sub(r'shrinkResources\s+\w+', 'shrinkResources false', text)
            return text
        lines = 'minifyEnabled false\n            shrinkResources false'
    text, n = re.subn(r'(buildTypes\s*\{\s*release\s*\{)', lambda m: m.group(1) + '\n            ' + lines, text, count=1)
    if n == 0:
        raise SystemExit('release buildType not found in Gradle file.')
    return text

text = _disable_shrink(text, path.suffix == '.kts')

path.write_text(text, encoding='utf-8')
print(f'Configured Android desugaring in {path}.')
