part of '../main.dart';

class StudyTask {
  final int id;
  final String title;
  final String grade;
  final String subject;
  final DateTime due;
  bool done;
  StudyTask({int? id, required this.title, required this.grade, required this.subject, required this.due, this.done = false})
      : id = id ?? (DateTime.now().microsecondsSinceEpoch % 0x7ffffffe) + 1;
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'grade': grade, 'subject': subject, 'due': due.toIso8601String(), 'done': done};
  factory StudyTask.fromJson(Map<String, dynamic> j) => StudyTask(id: (j['id'] as num?)?.toInt(), title: j['title'] as String? ?? '', grade: j['grade'] as String? ?? grades.first, subject: j['subject'] as String? ?? 'الإسلامية', due: DateTime.tryParse(j['due'] as String? ?? '') ?? DateTime.now(), done: j['done'] as bool? ?? false);
}

class StudyPlannerScreen extends StatefulWidget {
  const StudyPlannerScreen({super.key});
  @override
  State<StudyPlannerScreen> createState() => _StudyPlannerScreenState();
}
class _StudyPlannerScreenState extends State<StudyPlannerScreen> {
  final tasks = <StudyTask>[];
  final titleController = TextEditingController();
  String grade = grades.first;
  String subject = 'الإسلامية';
  DateTime due = DateTime.now().add(const Duration(days: 1));
  TimeOfDay reminderTime = const TimeOfDay(hour: 18, minute: 0);
  @override
  void initState() { super.initState(); _loadTasks(); }
  Future<void> _loadTasks() async {
    try {
      final raw = appPrefs.getString('studyTasks');
      if (raw == null) return;
      final stored = (jsonDecode(raw) as List).map((value) => Map<String, dynamic>.from(value as Map)).toList();
      final needsIdMigration = stored.any((task) => task['id'] == null);
      tasks
        ..clear()
        ..addAll(stored.map(StudyTask.fromJson));
      if (mounted) setState(() {});
      if (needsIdMigration) {
        await _saveTasks();
        for (final task in tasks.where((task) => !task.done)) {
          await _scheduleTaskReminder(task);
        }
      }
    } catch (_) {}
  }
  Future<void> _saveTasks() => appPrefs.setString('studyTasks', jsonEncode(tasks.map((e) => e.toJson()).toList()));

  DateTime get _dueDateTime => DateTime(due.year, due.month, due.day, reminderTime.hour, reminderTime.minute);

  Future<bool> _scheduleTaskReminder(StudyTask task) async {
    if (task.done || !task.due.isAfter(DateTime.now())) {
      await StudyNotificationService.cancel(task.id);
      return false;
    }
    return StudyNotificationService.schedule(
      id: task.id,
      title: 'تذكير بمهمة دراسية',
      body: '${task.title} • ${task.grade} • ${task.subject}',
      dateTime: task.due,
    );
  }
  @override
  void dispose() { titleController.dispose(); super.dispose(); }
  Future<void> addTask() async {
    final title = titleController.text.trim();
    if (title.isEmpty) return;
    final task = StudyTask(title: title, grade: grade, subject: subject, due: _dueDateTime);
    setState(() { tasks.add(task); titleController.clear(); });
    await _saveTasks();
    final scheduled = await _scheduleTaskReminder(task);
    if (mounted && !scheduled) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('حُفظت المهمة. فعّل إشعارات التطبيق لتلقي تذكير النظام.')));
    }
    FocusScope.of(context).unfocus();
  }
  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('الجدول الدراسي')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const SectionHeading(title: 'خطتك اليومية', subtitle: 'أضف واجباتك ومواعيد المراجعة'),
      const SizedBox(height: 16),
      TextField(controller: titleController, decoration: const InputDecoration(labelText: 'المهمة الدراسية', hintText: 'مثلاً: مراجعة الفصل الأول')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: grade, decoration: const InputDecoration(labelText: 'الصف الدراسي'), items: grades.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(), onChanged: (v) { if (v != null) setState(() { grade = v; final valid = gradeSubjectsFor(grade); if (!valid.contains(subject)) subject = valid.first; }); }),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: gradeSubjectsFor(grade).contains(subject) ? subject : gradeSubjectsFor(grade).first, decoration: const InputDecoration(labelText: 'المادة'), items: gradeSubjectsFor(grade).map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) { if (v != null) setState(() => subject = v); }),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: due, firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime.now().add(const Duration(days: 3650))); if (d != null) setState(() => due = d); }, icon: const Icon(Icons.calendar_month_rounded), label: Text('التاريخ: ${due.year}/${due.month}/${due.day}')),
      OutlinedButton.icon(onPressed: () async { final t = await showTimePicker(context: context, initialTime: reminderTime); if (t != null) setState(() => reminderTime = t); }, icon: const Icon(Icons.schedule_rounded), label: Text('وقت التذكير: ${reminderTime.format(context)}')),
      const SizedBox(height: 10),
      FilledButton.icon(onPressed: addTask, icon: const Icon(Icons.add_rounded), label: const Text('إضافة إلى الجدول')),
      const SizedBox(height: 22),
      const SectionHeading(title: 'المهام', subtitle: 'علّم المهمة عند إنجازها'),
      const SizedBox(height: 10),
      if (tasks.any((t) => !t.done && !t.due.isAfter(DateTime.now()))) Card(color: Colors.orange.withOpacity(.10), child: const ListTile(leading: Icon(Icons.notifications_active_rounded, color: Colors.deepOrange), title: Text('لديك مهمة مستحقة'), subtitle: Text('راجع المهام أدناه. يظهر هذا التنبيه عند فتح الجدول الدراسي.'))),
      if (tasks.isEmpty) const EmptyState(icon: Icons.event_note_rounded, title: 'جدولك فارغ', subtitle: 'أضف أول مهمة دراسية للبدء.'),
      ...tasks.asMap().entries.map((e) => Card(margin: const EdgeInsets.only(bottom: 8), child: CheckboxListTile(value: e.value.done, onChanged: (v) async { final task = e.value; setState(() => task.done = v ?? false); await _saveTasks(); await _scheduleTaskReminder(task); }, title: Text(e.value.title, style: TextStyle(decoration: e.value.done ? TextDecoration.lineThrough : null, fontWeight: FontWeight.bold)), subtitle: Text('${e.value.grade} • ${e.value.subject} • ${e.value.due.year}/${e.value.due.month}/${e.value.due.day} ${TimeOfDay.fromDateTime(e.value.due).format(context)}'), secondary: IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () async { final task = tasks[e.key]; setState(() => tasks.removeAt(e.key)); await StudyNotificationService.cancel(task.id); await _saveTasks(); }), controlAffinity: ListTileControlAffinity.leading))),
      const SizedBox(height: 8),
      const Text('تُحفظ المهام على هذا الجهاز. يرسل التطبيق تذكيراً محلياً في الموعد المحدد إذا سمحت بإشعارات النظام؛ المتصفح يعرض المهام داخل التطبيق فقط.', style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.6)),
    ]),
  ));
}

