part of '../main.dart';

class StudyAssistantScreen extends StatefulWidget {
  const StudyAssistantScreen({super.key});
  @override
  State<StudyAssistantScreen> createState() => _StudyAssistantScreenState();
}
class _StudyAssistantScreenState extends State<StudyAssistantScreen> {
  final controller = TextEditingController();
  final messages = <Map<String, String>>[
    {'from': 'assistant', 'text': 'أهلاً بك. أبحث أولاً في نص الكتاب الذي تحفظه وتختاره أدناه، وأعرض اسم الكتاب ورقم الصفحة مع المقتطف. إذا لم يتوفر نص مطابق، أوضح ذلك وأقدم نصيحة عامة دون الادعاء بأنها من الكتاب.'}
  ];
  final offlineBooks = <offline.OfflineBookInfo>[];
  String? selectedBookKey;
  bool searchingBook = false;

  @override
  void initState() {
    super.initState();
    _loadAssistantData();
  }

  Future<void> _loadAssistantData() async {
    final saved = appPrefs.getString('assistantMessages');
    if (saved != null) {
      try {
        messages
          ..clear()
          ..addAll((jsonDecode(saved) as List).map((e) => Map<String, String>.from(e)));
      } catch (_) {}
    }
    try {
      offlineBooks
        ..clear()
        ..addAll(await offline.loadOfflineBooks());
      selectedBookKey = offlineBooks.isEmpty ? null : offlineBooks.first.key;
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _saveMessages() => appPrefs.setString('assistantMessages', jsonEncode(messages));
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  String answerFor(String q) {
    final t = q.toLowerCase();
    if (t.contains('رياضيات') || t.contains('مسألة') || t.contains('معادلة')) return 'في الرياضيات: اكتب المعطيات أولاً، ثم حدّد المطلوب، واختر القانون المناسب، وحل خطوة بخطوة. أرسل نص المسألة كاملاً لأساعدك في ترتيب خطوات الحل.';
    if (t.contains('إنكليزي') || t.contains('انكليزي') || t.contains('english')) return 'لتطوير الإنكليزية: احفظ مفردات قليلة يومياً ضمن جمل، وراجع القواعد بالأمثلة، ثم حل أسئلة قصيرة مع التحقق من الإجابات.';
    if (t.contains('حفظ') || t.contains('أحفظ')) return 'جرّب الاسترجاع النشط: اقرأ فقرة قصيرة، أغلق الكتاب، اشرحها من ذاكرتك، ثم راجع ما نسيته. كرر المراجعة بعد يوم ثم بعد عدة أيام.';
    if (t.contains('جدول') || t.contains('وقت') || t.contains('نظم')) return 'قسّم وقتك إلى جلسات 25 دقيقة وبينها استراحة 5 دقائق. ابدأ بالمادة الأصعب، وحدد هدفاً صغيراً واضحاً لكل جلسة.';
    if (t.contains('امتحان') || t.contains('اختبار')) return 'للاستعداد للامتحان: راجع أهداف الفصل، حل أسئلة دون النظر إلى الكتاب، سجّل أخطاءك، ثم أعد حل الأسئلة التي أخطأت فيها.';
    if (t.contains('عربي') || t.contains('نحو')) return 'في اللغة العربية، حدّد نوع الكلمة وموقعها في الجملة، ثم اربط القاعدة بمثال صحيح. دوّن مثالين من الكتاب لكل قاعدة.';
    return 'أستطيع تقديم إرشادات دراسية عامة حالياً. اكتب المادة أو موضوع الدرس بصورة أوضح، مثل: طريقة مراجعة الفيزياء أو تنظيم وقت الامتحانات. للإجابات العلمية الدقيقة ينبغي الرجوع إلى نص الكتاب المعتمد.';
  }
  Future<void> send() async {
    final q = controller.text.trim();
    if (q.isEmpty || searchingBook) return;
    setState(() {
      messages.add({'from': 'user', 'text': q});
      searchingBook = true;
      controller.clear();
    });
    String answer;
    final selected = offlineBooks.where((book) => book.key == selectedBookKey);
    if (selected.isEmpty) {
      answer = '${answerFor(q)}\n\nلا يوجد كتاب محفوظ محدد؛ هذه إرشادات عامة وليست إجابة مستندة إلى المنهج.';
    } else {
      try {
        final book = selected.first;
        final hits = await CurriculumBookSearch.search(query: q, books: [book]);
        if (hits.isEmpty) {
          answer = 'لم أجد نصاً مطابقاً في «${book.title}». قد يكون الملف مصوراً أو يستخدم كلمات مختلفة. لم أستنتج إجابة من الكتاب؛ إليك إرشاداً عاماً:\n\n${answerFor(q)}';
        } else {
          answer = hits.map((hit) =>
              'من «${hit.book.title}» — ${hit.book.grade}، ${hit.book.subject}، الصفحة ${hit.page}:\n${hit.excerpt}').join('\n\n');
        }
      } catch (_) {
        answer = 'تعذر استخراج النص من الكتاب المحفوظ. قد يكون PDF مصوراً أو غير قابل للقراءة. ${answerFor(q)}';
      }
    }
    if (!mounted) return;
    setState(() {
      messages.add({'from': 'assistant', 'text': answer});
      searchingBook = false;
    });
    await _saveMessages();
  }
  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('المساعد الدراسي')),
    body: Column(children: [
      if (offlineBooks.isNotEmpty)
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          child: DropdownButtonFormField<String>(
            value: selectedBookKey,
            decoration: const InputDecoration(labelText: 'ابحث داخل كتاب محفوظ'),
            items: offlineBooks.map((book) => DropdownMenuItem(
              value: book.key,
              child: Text('${book.grade} • ${book.subject} • ${book.title}', overflow: TextOverflow.ellipsis),
            )).toList(),
            onChanged: (value) => setState(() => selectedBookKey = value),
          ),
        )
      else
        const Padding(
          padding: EdgeInsets.all(12),
          child: Text('احفظ كتاباً دون إنترنت أولاً حتى يبحث المساعد في نصه.', style: TextStyle(color: Colors.grey)),
        ),
      Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (context, i) { final m = messages[i]; final user = m['from'] == 'user'; return Align(alignment: user ? Alignment.centerLeft : Alignment.centerRight, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(13), constraints: const BoxConstraints(maxWidth: 500), decoration: BoxDecoration(color: user ? blue.withOpacity(.12) : Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)), child: Text(m['text'] ?? '', style: const TextStyle(height: 1.5)))); })),
      if (searchingBook) const LinearProgressIndicator(minHeight: 2),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: TextField(controller: controller, minLines: 1, maxLines: 4, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'اكتب سؤالاً عن الكتاب المحدد...'))), const SizedBox(width: 8), IconButton.filled(onPressed: searchingBook ? null : send, icon: const Icon(Icons.search_rounded))]))),
    ]),
  ));
}

