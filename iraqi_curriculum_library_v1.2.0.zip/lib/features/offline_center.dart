part of '../main.dart';

class OfflineCenterScreen extends StatefulWidget {
  final List<SchoolBook> books;
  final ValueChanged<String>? onSaved;
  final ValueChanged<String>? onDeleted;
  const OfflineCenterScreen({super.key, required this.books, this.onSaved, this.onDeleted});

  @override
  State<OfflineCenterScreen> createState() => _OfflineCenterScreenState();
}

class _OfflineCenterScreenState extends State<OfflineCenterScreen> {
  late Future<List<offline.OfflineBookInfo>> savedBooksFuture;
  bool busy = false;
  double? downloadProgress;
  offline.OfflineDownloadCancellation? cancellation;
  String? activeBookKey;

  @override
  void initState() {
    super.initState();
    savedBooksFuture = offline.loadOfflineBooks();
  }

  Future<void> _download(SchoolBook book) async {
    if (book.url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رابط الكتاب غير متوفر.')));
      return;
    }
    if (kIsWeb) {
      final id = RegExp(r'/d/([^/?]+)').firstMatch(book.url)?.group(1);
      final url = id == null ? book.url : 'https://drive.google.com/uc?export=download&id=$id';
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('في المتصفح يبدأ تنزيل الملف من خلال المتصفح، أما حفظه داخل التطبيق باستخدام path_provider فيحتاج نسخة Android.')));
      return;
    }
    final activeCancellation = offline.OfflineDownloadCancellation();
    setState(() {
      busy = true;
      cancellation = activeCancellation;
      downloadProgress = null;
      activeBookKey = book.key;
    });
    try {
      await offline.saveBookOffline(
        key: book.key,
        title: book.title,
        grade: book.grade,
        subject: book.subject,
        url: book.url,
        cancellation: activeCancellation,
        onProgress: (received, total) {
          if (!mounted || total == null || total <= 0) return;
          final value = (received / total).clamp(0, 1).toDouble();
          final previous = downloadProgress;
          if (previous == null || value >= previous + .01 || value >= 1) {
            setState(() => downloadProgress = value);
          }
        },
      );
      CurriculumBookSearch.invalidateBook(book.key);
      widget.onSaved?.call(book.key);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم حفظ ${book.title} دون إنترنت.')));
        setState(() => savedBooksFuture = offline.loadOfflineBooks());
      }
    } on offline.OfflineDownloadCancelled {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أُلغي التنزيل.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل التنزيل: $e')));
    } finally {
      if (mounted) setState(() { busy = false; cancellation = null; downloadProgress = null; activeBookKey = null; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final available = widget.books.where((b) => b.url.isNotEmpty).toList();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('التنزيلات والعمل دون إنترنت')),
      body: FutureBuilder<List<offline.OfflineBookInfo>>(
        future: savedBooksFuture,
        builder: (context, snapshot) {
          final saved = snapshot.data ?? const <offline.OfflineBookInfo>[];
          return ListView(padding: const EdgeInsets.all(18), children: [
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Icon(Icons.offline_pin_rounded, color: teal, size: 28), SizedBox(width: 9), Expanded(child: Text('نسخ محفوظة على الجهاز', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)))]),
              const SizedBox(height: 10),
              Text(kIsWeb
                  ? 'معاينة الويب تفتح تنزيلات المتصفح؛ أما حفظ PDF داخل مساحة التطبيق والرجوع إليه دون إنترنت فيتوفر في نسخة Android باستخدام path_provider.'
                  : 'يمكنك حفظ الكتب هنا، ثم فتح النسخة المحلية حتى لو انقطع الإنترنت. إذا رفض Google Drive التنزيل، تأكد أن الملف متاح للجميع أو افتح الرابط أولاً.', style: const TextStyle(height: 1.6)),
              const SizedBox(height: 8),
              Text('الكتب المحفوظة: ${saved.length}', style: const TextStyle(color: teal, fontWeight: FontWeight.w800)),
            ]))),
            const SizedBox(height: 14),
            if (snapshot.connectionState == ConnectionState.waiting)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 10),
                    Text('جارٍ تحميل قائمة الكتب المحفوظة...'),
                  ],
                ),
              ),
            if (saved.isEmpty && !kIsWeb && snapshot.connectionState != ConnectionState.waiting)
              const EmptyState(icon: Icons.cloud_off_rounded, title: 'لم تحفظ كتباً بعد', subtitle: 'اضغط زر التنزيل بجانب أي كتاب أدناه لحفظ نسخة PDF.'),
            ...saved.map((b) => Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
              leading: const Icon(Icons.picture_as_pdf_rounded, color: teal),
              title: Text(b.title),
              subtitle: Text('${b.grade} • ${b.subject} • محفوظ دون إنترنت'),
              trailing: Wrap(spacing: 0, children: [
                IconButton(tooltip: 'فتح النسخة المحفوظة', icon: const Icon(Icons.menu_book_rounded), onPressed: () { Navigator.of(context).push<void>(MaterialPageRoute(builder: (_) => PdfReaderScreen(path: b.path, bookKey: b.key, title: b.title))); }),
                IconButton(tooltip: 'حذف النسخة', icon: const Icon(Icons.delete_outline_rounded), onPressed: () async { await offline.deleteOfflineBook(b.key); CurriculumBookSearch.invalidateBook(b.key); widget.onDeleted?.call(b.key); if (mounted) setState(() => savedBooksFuture = offline.loadOfflineBooks()); }),
              ]),
            ))),
            const SizedBox(height: 20),
            const SectionHeading(title: 'كتب متاحة للحفظ', subtitle: 'اختر الكتب التي تريد الاحتفاظ بها محلياً'),
            const SizedBox(height: 10),
            if (available.isEmpty) const EmptyState(icon: Icons.menu_book_outlined, title: 'لا توجد روابط حالياً', subtitle: 'تظهر هنا الكتب التي أضيفت لها روابط فعلية.'),
            ...available.map((b) {
              final isDownloading = busy && activeBookKey == b.key;
              return Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
                leading: const Icon(Icons.picture_as_pdf_rounded, color: blue),
                title: Text(b.title),
                subtitle: Text(isDownloading && downloadProgress != null ? '${b.grade} • ${b.subject} • ${(downloadProgress! * 100).round()}%' : '${b.grade} • ${b.subject}'),
                trailing: isDownloading
                    ? IconButton(tooltip: 'إلغاء التنزيل', icon: const Icon(Icons.close_rounded), onPressed: cancellation?.cancel)
                    : IconButton(tooltip: 'تنزيل وحفظ دون إنترنت', icon: const Icon(Icons.download_rounded), onPressed: busy ? null : () => _download(b)),
              ));
            }),
          ]);
        },
      ),
    ));
  }
}

