import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'screens/pdf_reader_screen.dart';
import 'theme/library_palette.dart';
import 'widgets/library_color_picker.dart';
import 'services/curriculum_book_search.dart';
import 'services/offline_book_storage.dart' as offline;
import 'services/study_notification_service.dart';

part 'features/study_planner.dart';
part 'features/study_assistant.dart';
part 'features/offline_center.dart';
part 'features/quizzes.dart';

late SharedPreferences appPrefs;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await pdfrxFlutterInitialize();
  } catch (error, stackTrace) {
    // Keep the library usable if PDF initialization fails; PdfViewer will show
    // its localized load error instead of leaving the user with a blank page.
    debugPrint('PDF engine initialization failed: $error\n$stackTrace');
  }
  runApp(const AppBootstrap());
}

/// Loads platform services after Flutter has already displayed a startup UI.
/// This prevents a failed plugin initialization from leaving a blank screen.
class AppBootstrap extends StatefulWidget {
  const AppBootstrap({super.key});

  @override
  State<AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<AppBootstrap> {
  late Future<void> _startup;

  @override
  void initState() {
    super.initState();
    _startup = _initialize();
  }

  Future<void> _initialize() async {
    // Always use the real on-device SharedPreferences store.
    // Do not time out into setMockInitialValues: mock preferences are in-memory
    // only, so favorites and theme settings disappear after the app is closed.
    // Waiting for the real plugin also avoids racing startup against storage.
    // Retry once in case the platform channel is not ready on the first call.
    // Keep using the real platform store; never substitute in-memory mock data.
    try {
      appPrefs = await SharedPreferences.getInstance();
    } catch (_) {
      await Future<void>.delayed(const Duration(milliseconds: 350));
      appPrefs = await SharedPreferences.getInstance();
    }

    final savedHistory = appPrefs.getString('quizHistory');
    if (savedHistory != null) {
      try {
        quizHistory
          ..clear()
          ..addAll((jsonDecode(savedHistory) as List).map(
            (e) => QuizResult.fromJson(Map<String, dynamic>.from(e)),
          ));
      } catch (_) {
        quizHistory.clear();
      }
    }

    // Notifications are optional; failure must not prevent the library UI.
    try {
      await StudyNotificationService.initialize().timeout(
        const Duration(seconds: 5),
      );
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _startup,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done &&
            !snapshot.hasError) {
          return const IraqiLibraryApp();
        }
        if (snapshot.hasError) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              backgroundColor: const Color(0xFFF4F7FC),
              body: SafeArea(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            color: Color(0xFFB42318), size: 54),
                        const SizedBox(height: 16),
                        const Text(
                          'تعذّر تشغيل التطبيق',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'تعذّر فتح التخزين المحلي على الهاتف. اضغط إعادة المحاولة، وإذا تكرر الخطأ أرسل تفاصيله أدناه.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        SelectableText(
                          snapshot.error.toString(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 11),
                        ),
                        const SizedBox(height: 20),
                        FilledButton.icon(
                          onPressed: () => setState(() {
                            _startup = _initialize();
                          }),
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('إعادة المحاولة'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        }
        return const MaterialApp(
          debugShowCheckedModeBanner: false,
          home: Scaffold(
            backgroundColor: Color(0xFFF4F7FC),
            body: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 18),
                  Text('جارٍ تجهيز مكتبتك الدراسية...'),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

const navy = Color(0xFF142D4E);
const blue = Color(0xFF2864E8);
const teal = Color(0xFF0C9B83);
const purple = Color(0xFF8655C8);
const stageGreen = Color(0xFF10A97D);
const stageOrange = Color(0xFFF59E0B);
const canvas = Color(0xFFF4F7FC);

// Shared visual rhythm: retain the established palette while standardizing
// common spacing, icon sizes and section headings.
const double appSpaceXs = 4;
const double appSpaceSm = 8;
const double appSpaceMd = 12;
const double appSpaceLg = 16;
const double appSpaceXl = 24;
const double appIconSize = 22;
const double appSectionTitleSize = 18;

class GentlePageTransitionsBuilder extends PageTransitionsBuilder {
  const GentlePageTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final eased = CurvedAnimation(
      parent: animation,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeInCubic,
    );
    final slide = Tween<Offset>(
      begin: const Offset(0.018, 0),
      end: Offset.zero,
    ).animate(eased);
    return FadeTransition(
      opacity: eased,
      child: SlideTransition(position: slide, child: child),
    );
  }
}

// نتائج الاختبارات تحفظ محلياً على Android والويب بواسطة shared_preferences.
final List<QuizResult> quizHistory = [];

Future<void> saveQuizHistory() async {
  await appPrefs.setString('quizHistory', jsonEncode(quizHistory.map((e) => e.toJson()).toList()));
}

const booksByGrade = <String, List<Map<String, String>>>{
  'الأول الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1idf1IS_S_XcSXCoDFb59tpaH41hyYEzu/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/10RMSOmVOmJ0I5aUFvQMGH2D5qs3WrmAN/view?usp=drivesdk',
    },
    {
      'title': 'نشاط القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1Ih3Wm3i-UMhP73VTGtKdgsAQiHa2fQSm/view?usp=drivesdk',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/12cLRJZ0Re6aOrG_rM2JGFAiR1t_kvQIa/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1V0JkjgaYztH9LsEAKQR-BkUwpjig8xeV/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1KsxJxe0W5h-feD1jL0i9YVitoprbeRd1/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1DG7fL9MfuL5NqTDuG7hRa5aaD9vqmM79/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/11TqMbf2GqbldP8DwCiRV2R8lsSay89oF/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1QeJR7DsfMqkiyuI4fgW0m5CErHYIK0lu/view',
    },
    {
      'title': 'كتاب الأخلاقية',
      'subject': 'الأخلاقية',
      'url': 'https://drive.google.com/file/d/1PQFy1vS77opnyaDWLcBz4J2rtrqmK_sZ/view',
    },
  ],
  'الثاني الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1sgXP7NNoAYvAvc6hj_PxNzA5U_-v_MPo/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1OwLe8elhbqcr0Oe5t2Hf9mAvYfgON6w5/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1cKHbMM7vNc8eqcQ4J_GAG0lsva2Sp3hF/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1V1NhW8lQLtaAXzl-zpHWL6dU6aCcFRRn/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/13nk4HvTojF_MSSmsV_Wtp6wXoWx6wrUP/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1M7csrP8ESi_ejvEL_2WKBJLSL_VV6D2F/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1UkKWZ0aAwZyBHrfzc2C1ZWB5WvNn9l5b/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1etu-YJv82iZqH9_VOSK_UGVILHVOY6dc/view',
    },
    {
      'title': 'كتاب الأخلاقية',
      'subject': 'الأخلاقية',
      'url': 'https://drive.google.com/file/d/1X3nIzGQCUpeK5DQqRjoT_U97AiHTBlWH/view',
    },
  ],
  'الثالث الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1GNfl_jfkIZTlCAzSJJlZdfzcXp9Yg8A0/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1EujI_2O0LtoZgWVKbz4_n-CVlzSeVBuG/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/10c2x_pbyM1qUb4-2UnorIUoCiReHGpYz/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1FGACF7U-oqeEIfgqiphYsMdWbeTAFyj4/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1e7rcS2xAzfSc3PK_mx7IHRHiv94xwLmi/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1t88XP_kDtSrdPFv1gip4bJQfo2xsEgZP/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1f7RlugDalwJ3iQidd7B_bg-vpNR9cRcf/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1OCwai2pYlOg3-ujitXmNJ7LGg6jvJ4h8/view',
    },
  ],
  'الرابع الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1qrQ0m3BpEpGpddG4Ga_oGxOBGbAVmdc1/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1FwlJF6FlAQYfkeThkoKcExM-WAeK3XKI/view',
    },
    {
      'title': 'كتاب القواعد',
      'subject': 'القواعد',
      'url': 'https://drive.google.com/file/d/1ld5aGZnQLGsFoNOklylefc0CaD8ikZPY/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1od1MGHZJ_erJednreUzwC1U7YQSjuzBw/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1B6sT5nd6kj5ljdPF270igMhkrqyyvsqj/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1u0T7voKBEViq_lfBOzOABXXv-nH-UR8w/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1vuJbrL80ri-MLvkk7UXdLJuPbFKUxK3I/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1pB7l4fgD2tpDpWwSs1gfCz2kbOVjAru0/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/143YTfRRY0X6yNqf0BXs5CFjyeCus2EGT/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/119FjK-goDmppik85_g7iUGZly2qySope/view',
    },
  ],
  'الخامس الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1toPZxJtvEF22aO2CFY6eTIID_mOijBPJ/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1WO4ZRerrs5DTOkhucLfmvSzDbJM-izCL/view',
    },
    {
      'title': 'كتاب القواعد',
      'subject': 'القواعد',
      'url': 'https://drive.google.com/file/d/1yd47rq8fgGsAYUfnsB6T2jfZ6PV-9YWP/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1WsOjod92DE7jEqGpvdrrekI_OPBne17_/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/19KG6V4waG0_wgwfA3BHTbNhHMrgCcwu9/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/19Vw-FeVe5UZfHufy8U9_ZeDrPJPBv6Sh/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/19jhpW5XjFVRi0xaSu2uKTMyL-zP5Yt62/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1SxdVpZk9brkv4YRpbX_wIe1c3yrIzfkY/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1OPd-LH8vclgd4KKBGsf24X_gYB77jdgt/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/1i5RbK2zY4AfOFB1RnWkBCEYrqhSZow8s/view',
    },
  ],
  'السادس الابتدائي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1Lx7OGHY5S8bqglDX_5KmgmyxRbfccpVB/view',
    },
    {
      'title': 'كتاب القراءة',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1955uM36MDE54JuC5bAvheYLocrN6pLZ_/view',
    },
    {
      'title': 'كتاب القواعد',
      'subject': 'القواعد',
      'url': 'https://drive.google.com/file/d/1lEtZ_U_DGHadnrqHTKMe945_toxRuC0r/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1oLRTuvvg2TWLH-tx3ynPai7bU98xl3Jf/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/12KodkqqgIxl6C0iqV7Xj6nX_RMNY12V-/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1eruXvQZRELfJn_cab2VmYYUhZ2PDq_tK/view',
    },
    {
      'title': 'نشاط الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1WjTTipG5RW52qUZDhjmXj7uN4B0YPr1C/view',
    },
    {
      'title': 'كتاب العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1hHSjYlxNHCkx8_D9ZeYtBxW7szZZ0Rdu/view',
    },
    {
      'title': 'نشاط العلوم',
      'subject': 'العلوم',
      'url': 'https://drive.google.com/file/d/1QiJXj0Aa0fEtp2_kTkmKYQu09yIL-Ust/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/18niTWYBMKB6z5TTTwa_1J6Jn6-oE2amK/view',
    },
  ],
  'الأول المتوسط': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/17ZD6sfjGSZAk_Nhv8hPRWzoIcpfn2tCv/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1QBq6_g2nd3ydDFan6UN-MXe4A5pEF1vY/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1BCp3RGgNJ6KVpKw2_oCvp1dqQLlZ-r-p/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1k7iyNJaml_OxfMDoUPaXADSiVtjzRhXY/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/10BmtO85zw7VcICDM77rwB9NnO8m6e3Zm/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1j5rCTdsWEBq1GlYocjNEZ3L7fOSD371P/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/1air6voRkhKdQ23z6MP6x6hW1C5tSmk8O/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1awyzCsIy-_oy503aOD7nKhLLkThqTqzb/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/11abqYmRhh_6XTvgQWDPmTi-YfWpJEya1/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/1XSfIMD1lrd5FMW5T8WjnJc0iv0c51oNU/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1ubTfL8RuDUIo8uK5xU5BRzfnzQINSlR_/view',
    },
    {
      'title': 'كتاب الأخلاقية',
      'subject': 'الأخلاقية',
      'url': 'https://drive.google.com/file/d/1j-c9YZzE5S4yzg3URSyX8lEKiPUekAty/view',
    },
  ],
  'الثاني المتوسط': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1c-3r-MLUsWIcklbX2hLtOzS0MkslwoY0/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1j_7dIHXd9_OoEu-CIApfpESEAZDlWAl7/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/16FQvkdrAMkkN56hEp4Q7aR7axH31Etr9/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1ibcYVjMDQ0taCokRqbDt6dcMA_GYepfH/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1NZqQACVdmQ8OXXj2y6wE41OA03mPdlz9/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1cxBycgclU-aKb5Gcw_MFF8HVH2VePwEl/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/18ZVBiV7akYupZarET3iA3xzh9UsXnlfs/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1ZDA6UhFe0pv_1Fef3TZq9nNq_c-LDbd0/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/1hx5nrpXIfC57TwxHzzz74p8_akqgNjYG/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/18ageDf_ZJYPeXezwRvDwVHz3TAZTZihH/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1DYMLo0M-GXGztodKeaOi78nbNxxrvQ0_/view',
    },
    {
      'title': 'كتاب الأخلاقية',
      'subject': 'الأخلاقية',
      'url': 'https://drive.google.com/file/d/1rwlB-DrCJbM5b_thpMsJJyh-XHLZE4Hc/view',
    },
  ],
  'الثالث المتوسط': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1yvu0veNu51F28XrXIe6XY9RZi_7v3NGo/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1MQLG5ShT2ovs-_mKTapcVdtp8VW5FGtX/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1uJwzwq7IHPRmofKk_pVKY615bX1NT4GC/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1lTSoU55iVqeTjSXivwB7pjB_Cl6p0PVy/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1aC3novMQQQhhl8dfvawoFErtIjHn0oLn/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1DDmRpOA81MxjcLLrU93-WK0SWY3l9haA/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1JX3Txh9ID4sTSwkSsmmhMPqJFRVFlD74/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/1sekvvDcy_-E2UG95jgmrtso7jw_GmJgj/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/1x88OiZMUQowTXahXfRaZeBwuiEemA0A6/view',
    },
    {
      'title': 'كتاب الاجتماعيات',
      'subject': 'الاجتماعيات',
      'url': 'https://drive.google.com/file/d/1aOCO7YF9dUwu2S9cQD2psIDHuChn1GkV/view',
    },
  ],
  'الرابع العلمي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1A_2_hY2sFNdwh4DeUoc_nem8Akzo5MBl/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1DZftdIOxSrcvN8XOmWGgKN82jBSQLrrx/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1WA5lv1p4KU4N76XKeiQGjQ2iMF7_AJ2Q/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1f2-VLqjEo-a0Z8PQP4PbOfehoE4_zIuJ/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1JK8veZKGigbb_4lldUuqRWk3mjfQAf4Z/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1DBeqVvFSn0IyamTwfDoHhfryLJGYdm4v/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1ljrfl-PUIu8Uw8ysSWodwelF1NeCBPpF/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/1DrZpDQk4pjJFDX4xgfymaJepKLZR1qaU/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/1No5mOZbm_tarTLuIs8KlJqIC9kRDz7vm/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1H7TO0RC1ob1eALpNX_c-_7GiDToiPVbA/view',
    },
    {
      'title': 'كتاب جرائم البعث',
      'subject': 'جرائم البعث',
      'url': 'https://drive.google.com/file/d/1VYkqoESHBq__npTnNLEmkhBujRC1OA3p/view',
    },
  ],
  'الرابع الأدبي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1A_2_hY2sFNdwh4DeUoc_nem8Akzo5MBl/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1DZftdIOxSrcvN8XOmWGgKN82jBSQLrrx/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1WA5lv1p4KU4N76XKeiQGjQ2iMF7_AJ2Q/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1f2-VLqjEo-a0Z8PQP4PbOfehoE4_zIuJ/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1JK8veZKGigbb_4lldUuqRWk3mjfQAf4Z/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1BQMyduVtDOSi-sa_AlvhLsx6wNYX72o4/view',
    },
    {
      'title': 'كتاب التاريخ',
      'subject': 'التاريخ',
      'url': 'https://drive.google.com/file/d/1GiWsIsTKCqAbmWyNcaySGolpCLpVq6bm/view',
    },
    {
      'title': 'كتاب الجغرافية',
      'subject': 'الجغرافية',
      'url': 'https://drive.google.com/file/d/1WJumB16RVauyINwC8JxkAo-RQlow-N59/view',
    },
    {
      'title': 'كتاب علم الاجتماع',
      'subject': 'علم الاجتماع',
      'url': 'https://drive.google.com/file/d/1pNlIIM_3Gn_2a8VfNidg4rgXf59CKtYX/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1H7TO0RC1ob1eALpNX_c-_7GiDToiPVbA/view',
    },
    {
      'title': 'كتاب جرائم البعث',
      'subject': 'جرائم البعث',
      'url': 'https://drive.google.com/file/d/1VYkqoESHBq__npTnNLEmkhBujRC1OA3p/view',
    },
  ],
  'الخامس العلمي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/18fZ8LAG4W-TTwdNUfhLsrC3zIrIGX52X/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1RLjREu5JoMKGpD8_b_gLkvzjRHdn_S0V/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1ZcHyXnUMCcPDdQVdfmNI25IcNRdo0ihM/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1LV9vHG17YKJV7VelXIV51Ls99RHSlmDM/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1Ljuhp_m6OFRzHB3NO0arSHCEHY0ieuEB/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1kuHHdsrd3A9fX_gWFTsRZJNJ8ymrbqYi/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1KN59ojfIimlLLphMeiQbcDtJU6jhtzjC/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/18Yfy2blPQFSPh04CLK9Olzmqn_jPV0G-/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/1xjUntupzglhjG0hxUgPrxwh5GV4oSEpQ/view',
    },
    {
      'title': 'كتاب علم الأرض',
      'subject': 'علم الأرض',
      'url': 'https://drive.google.com/file/d/1phJxyi_0k99MSvqYFn3NRfekbLnbrEZ2/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1BPiGxlL-Ogp8WfEbcpkBPxIF9nTl_Kw8/view',
    },
  ],
  'الخامس الأدبي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/18fZ8LAG4W-TTwdNUfhLsrC3zIrIGX52X/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1RLjREu5JoMKGpD8_b_gLkvzjRHdn_S0V/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1ZcHyXnUMCcPDdQVdfmNI25IcNRdo0ihM/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1LV9vHG17YKJV7VelXIV51Ls99RHSlmDM/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1Ljuhp_m6OFRzHB3NO0arSHCEHY0ieuEB/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1N2N6c6XfT267nkaonQWGXNjdaUC8TyPN/view',
    },
    {
      'title': 'كتاب التاريخ',
      'subject': 'التاريخ',
      'url': 'https://drive.google.com/file/d/1k6P28pYqm65REaKuWt181Wq-lHbvQ0FV/view',
    },
    {
      'title': 'كتاب الجغرافية',
      'subject': 'الجغرافية',
      'url': 'https://drive.google.com/file/d/1Y-cIsxKNWGVpTcqvZoCsivnNE-oXQ1uL/view',
    },
    {
      'title': 'كتاب الفلسفة',
      'subject': 'الفلسفة',
      'url': 'https://drive.google.com/file/d/1bJeMUuZSWBmfAVpdyYNih3wekONvwC4r/view',
    },
    {
      'title': 'كتاب الحاسوب',
      'subject': 'الحاسوب',
      'url': 'https://drive.google.com/file/d/1BPiGxlL-Ogp8WfEbcpkBPxIF9nTl_Kw8/view',
    },
    {
      'title': 'كتاب الاقتصاد',
      'subject': 'الاقتصاد',
      'url': 'https://drive.google.com/file/d/1uFHGaJ_9IbFmpS2o4Z5lCh8CLPHmB5Am/view',
    },
  ],
  'السادس العلمي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1sSfkJBYy3hjBD0-nNr5TxvP_EgrZW_kI/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1A3UT2PVgmaXtxdCOnilULdCwZ_rNrD-S/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/14LWmS10HJpfaeoW6fO9t5DogoUytFu3x/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1CIBqJdozoE2hP7qVoKtvbVVxLSRHuDOL/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1i_GD1bDTIPk0YV7wVzMke9ajXlFe1jpo/view',
    },
    {
      'title': 'كتاب أدب الإنكليزي',
      'subject': 'أدب الإنكليزي',
      'url': 'https://drive.google.com/file/d/1LT9RJXK9MEiqZEzTg06NcP0myBOHg7k2/view',
    },
    {
      'title': 'تمارين أدب الإنكليزي',
      'subject': 'أدب الإنكليزي',
      'url': 'https://drive.google.com/file/d/1yN9cp2sZQ7ungTVpQ8q39UCEuNRUGgiB/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/19W9vwgKrpyRM_57emKvNY924quBMpXAe/view',
    },
    {
      'title': 'كتاب الأحياء',
      'subject': 'الأحياء',
      'url': 'https://drive.google.com/file/d/1GSNrsYelnTPmDjwf1DazX63HVCrtRZ_f/view',
    },
    {
      'title': 'كتاب الكيمياء',
      'subject': 'الكيمياء',
      'url': 'https://drive.google.com/file/d/1ehts5XcMl32MuAIe6F7kuNEo8YeUkLOd/view',
    },
    {
      'title': 'كتاب الفيزياء',
      'subject': 'الفيزياء',
      'url': 'https://drive.google.com/file/d/1k6JqHWmdgxTSwv3OOdAFfc909bUo_JIj/view',
    },
  ],
  'السادس الأدبي': [
    {
      'title': 'كتاب التربية الإسلامية',
      'subject': 'الإسلامية',
      'url': 'https://drive.google.com/file/d/1sSfkJBYy3hjBD0-nNr5TxvP_EgrZW_kI/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الأول',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/1A3UT2PVgmaXtxdCOnilULdCwZ_rNrD-S/view',
    },
    {
      'title': 'كتاب اللغة العربية - الجزء الثاني',
      'subject': 'اللغة العربية',
      'url': 'https://drive.google.com/file/d/14LWmS10HJpfaeoW6fO9t5DogoUytFu3x/view',
    },
    {
      'title': 'كتاب اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1CIBqJdozoE2hP7qVoKtvbVVxLSRHuDOL/view',
    },
    {
      'title': 'نشاط اللغة الإنكليزية',
      'subject': 'اللغة الإنكليزية',
      'url': 'https://drive.google.com/file/d/1i_GD1bDTIPk0YV7wVzMke9ajXlFe1jpo/view',
    },
    {
      'title': 'كتاب أدب الإنكليزي',
      'subject': 'أدب الإنكليزي',
      'url': 'https://drive.google.com/file/d/1LT9RJXK9MEiqZEzTg06NcP0myBOHg7k2/view',
    },
    {
      'title': 'تمارين أدب الإنكليزي',
      'subject': 'أدب الإنكليزي',
      'url': 'https://drive.google.com/file/d/1yN9cp2sZQ7ungTVpQ8q39UCEuNRUGgiB/view',
    },
    {
      'title': 'كتاب الرياضيات',
      'subject': 'الرياضيات',
      'url': 'https://drive.google.com/file/d/1I-XzEAm89D6wpaKcJZlvbiWd7zku6LLL/view',
    },
    {
      'title': 'كتاب التاريخ',
      'subject': 'التاريخ',
      'url': 'https://drive.google.com/file/d/1uR74L0mD0rGnVhd8DRPdMxQCy8z678-3/view',
    },
    {
      'title': 'كتاب الجغرافية',
      'subject': 'الجغرافية',
      'url': 'https://drive.google.com/file/d/1vE0mBMXycN6HuTnNIgJefbdenxB45yga/view',
    },
    {
      'title': 'كتاب الاقتصاد',
      'subject': 'الاقتصاد',
      'url': 'https://drive.google.com/file/d/1ptkJfPsRbHwf9SGuhszTL6BJOlR-r52h/view',
    },
  ],
};

const grades = [
  'الأول الابتدائي',
  'الثاني الابتدائي',
  'الثالث الابتدائي',
  'الرابع الابتدائي',
  'الخامس الابتدائي',
  'السادس الابتدائي',
  'الأول المتوسط',
  'الثاني المتوسط',
  'الثالث المتوسط',
  'الرابع العلمي',
  'الخامس العلمي',
  'السادس العلمي',
  'الرابع الأدبي',
  'الخامس الأدبي',
  'السادس الأدبي',
];

List<String> gradeSubjectsFor(String grade) {
  if (grade.contains('الابتدائي')) {
    final number = grades.indexOf(grade) + 1;
    final result = <String>[
      'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات', 'العلوم',
    ];
    if (number <= 2) result.add('الأخلاقية');
    if (number >= 4) {
      result.add('القواعد');
      result.add('الاجتماعيات');
    }
    return result;
  }

  switch (grade) {
    case 'الأول المتوسط':
    case 'الثاني المتوسط':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'الاجتماعيات', 'الأحياء', 'الكيمياء', 'الفيزياء', 'الحاسوب', 'الأخلاقية',
      ];
    case 'الثالث المتوسط':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'الأحياء', 'الكيمياء', 'الفيزياء', 'الاجتماعيات',
      ];
    case 'الرابع العلمي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'الأحياء', 'الكيمياء', 'الفيزياء', 'الحاسوب', 'جرائم البعث',
      ];
    case 'الرابع الأدبي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'التاريخ', 'الجغرافية', 'علم الاجتماع', 'الحاسوب', 'جرائم البعث',
      ];
    case 'الخامس العلمي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'الأحياء', 'الكيمياء', 'الفيزياء', 'علم الأرض', 'الحاسوب',
      ];
    case 'الخامس الأدبي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'التاريخ', 'الجغرافية', 'الفلسفة', 'الحاسوب', 'الاقتصاد',
      ];
    case 'السادس العلمي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'الأحياء', 'الكيمياء', 'الفيزياء', 'أدب الإنكليزي',
      ];
    case 'السادس الأدبي':
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'التاريخ', 'الجغرافية', 'الاقتصاد', 'أدب الإنكليزي',
      ];
    default:
      return <String>[
        'الإسلامية', 'اللغة العربية', 'اللغة الإنكليزية', 'الرياضيات',
        'التاريخ', 'الجغرافية', 'الاقتصاد',
      ];
  }
}

Color gradeColor(String grade) {
  // لون مستقل لكل صف مع الإبقاء على ألوان عناوين المراحل كما هي.
  const gradeColors = <String, Color>{
    'الأول الابتدائي': Color(0xFF356AE6),
    'الثاني الابتدائي': Color(0xFF7B52C7),
    'الثالث الابتدائي': Color(0xFFD95778),
    'الرابع الابتدائي': Color(0xFFD88928),
    'الخامس الابتدائي': Color(0xFF168C83),
    'السادس الابتدائي': Color(0xFF40556F),
    'الأول المتوسط': Color(0xFF2878B5),
    'الثاني المتوسط': Color(0xFF8B5E3C),
    'الثالث المتوسط': Color(0xFF5B65C9),
    'الرابع العلمي': Color(0xFF258A58),
    'الخامس العلمي': Color(0xFFC14D36),
    'السادس العلمي': Color(0xFF6850A4),
    'الرابع الأدبي': Color(0xFFB04E8A),
    'الخامس الأدبي': Color(0xFF657D32),
    'السادس الأدبي': Color(0xFF397F91),
  };
  return LibraryPalette.gradeColor(grade, gradeColors[grade] ?? blue);
}

String gradeStage(String grade) {
  if (grade.contains('الابتدائي')) return 'المرحلة الابتدائية';
  if (grade.contains('المتوسط')) return 'المرحلة المتوسطة';
  return 'المرحلة الإعدادية';
}

IconData gradeIcon(String grade) {
  if (grade.contains('الابتدائي')) return Icons.child_care_rounded;
  if (grade.contains('المتوسط')) return Icons.school_rounded;
  if (grade.contains('العلمي')) return Icons.science_rounded;
  if (grade.contains('الأدبي')) return Icons.menu_book_rounded;
  return Icons.school_rounded;
}

IconData subjectIcon(String subject) {
  switch (subject) {
    case 'الرياضيات':
      return Icons.calculate_rounded;
    case 'العلوم':
      return Icons.science_rounded;
    case 'اللغة العربية':
    case 'القواعد':
      return Icons.menu_book_rounded;
    case 'اللغة الإنكليزية':
      return Icons.translate_rounded;
    case 'أدب الإنكليزي':
      return Icons.auto_stories_rounded;
    case 'الاجتماعيات':
    case 'الجغرافية':
      return Icons.public_rounded;
    case 'التاريخ':
    case 'جرائم البعث':
      return Icons.history_edu_rounded;
    case 'علم الاجتماع':
      return Icons.groups_rounded;
    case 'الفلسفة':
      return Icons.psychology_rounded;
    case 'علم الأرض':
      return Icons.public_rounded;
    case 'الإسلامية':
      return Icons.mosque_rounded;
    case 'الفيزياء':
      return Icons.bolt_rounded;
    case 'الكيمياء':
      return Icons.biotech_rounded;
    case 'الأحياء':
      return Icons.spa_rounded;
    case 'الحاسوب':
      return Icons.computer_rounded;
    case 'الاقتصاد':
      return Icons.account_balance_rounded;
    case 'التربية الفنية':
      return Icons.palette_rounded;
    case 'التربية الرياضية':
      return Icons.sports_soccer_rounded;
    default:
      return Icons.auto_stories_rounded;
  }
}

Color subjectColor(String subject) {
  switch (subject) {
    case 'الرياضيات':
      return blue;
    case 'العلوم':
    case 'الكيمياء':
      return teal;
    case 'اللغة العربية':
      return purple;
    case 'اللغة الإنكليزية':
      return const Color(0xFFEC9142);
    case 'أدب الإنكليزي':
      return const Color(0xFF8B5AA8);
    case 'الاجتماعيات':
    case 'الجغرافية':
      return const Color(0xFF478C76);
    case 'الإسلامية':
    case 'الأخلاقية':
      return const Color(0xFFB88A37);
    case 'الفيزياء':
      return const Color(0xFF5078CC);
    case 'الأحياء':
      return const Color(0xFF65A45B);
    case 'التاريخ':
      return const Color(0xFFAD6550);
    case 'الاقتصاد':
    case 'علم الاجتماع':
      return const Color(0xFF398A91);
    case 'علم الأرض':
      return const Color(0xFF8D7455);
    case 'الفلسفة':
      return const Color(0xFF8B5AA8);
    case 'جرائم البعث':
      return const Color(0xFF9C5B58);
    case 'الحاسوب':
      return const Color(0xFF5D6DAB);
    case 'التربية الفنية':
      return const Color(0xFFDB719A);
    case 'التربية الرياضية':
      return const Color(0xFF549D62);
    default:
      return blue;
  }
}

class SchoolBook {
  final String title;
  final String subject;
  final String grade;
  final String url;

  const SchoolBook({
    required this.title,
    required this.subject,
    required this.grade,
    required this.url,
  });

  String get key => '$title|$grade';
}

List<SchoolBook> makeBooks() {
  final books = <SchoolBook>[];

  for (final grade in grades) {
    final supplied = booksByGrade[grade];
    if (supplied != null) {
      books.addAll(supplied.map((item) => SchoolBook(
            title: item['title']!,
            subject: item['subject']!,
            grade: grade,
            url: item['url']!,
          )));
      // Add clearly marked placeholders only for subjects that do not yet have a supplied link.
      for (final subject in gradeSubjectsFor(grade)) {
        if (!supplied.any((item) => item['subject'] == subject)) {
          books.add(SchoolBook(
            title: 'كتاب $subject (الرابط غير متوفر حالياً)',
            subject: subject,
            grade: grade,
            url: '',
          ));
        }
      }
      continue;
    }

    for (final subject in gradeSubjectsFor(grade)) {
      books.add(SchoolBook(
        title: 'كتاب $subject',
        subject: subject,
        grade: grade,
        url: '',
      ));
    }
  }

  return books;
}

class IraqiLibraryApp extends StatefulWidget {
  const IraqiLibraryApp({super.key});

  @override
  State<IraqiLibraryApp> createState() => _IraqiLibraryAppState();
}

class _IraqiLibraryAppState extends State<IraqiLibraryApp> {
  @override
  void initState() {
    super.initState();
    LibraryPalette.load(appPrefs, grades);
  }

  void _refreshAppearance() => setState(() {});

  bool dark = appPrefs.getBool('darkMode') ?? false;
  double fontScale = ((appPrefs.getDouble('fontScale') ?? 1.0)
          .clamp(0.85, 1.25))
      .toDouble();

  Future<void> _setDarkMode(bool value) async {
    if (dark != value) setState(() => dark = value);
    try {
      await appPrefs.setBool('darkMode', value);
    } catch (error) {
      debugPrint('Could not persist darkMode: $error');
    }
  }

  Future<void> _setFontScale(double value) async {
    final clamped = value.clamp(0.85, 1.25).toDouble();
    if ((fontScale - clamped).abs() > 0.001) {
      setState(() => fontScale = clamped);
    }
    try {
      await appPrefs.setDouble('fontScale', clamped);
    } catch (error) {
      debugPrint('Could not persist fontScale: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    const pageTransitions = PageTransitionsTheme(
      builders: <TargetPlatform, PageTransitionsBuilder>{
        TargetPlatform.android: GentlePageTransitionsBuilder(),
        TargetPlatform.iOS: GentlePageTransitionsBuilder(),
        TargetPlatform.macOS: GentlePageTransitionsBuilder(),
        TargetPlatform.windows: GentlePageTransitionsBuilder(),
        TargetPlatform.linux: GentlePageTransitionsBuilder(),
      },
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'المناهج الدراسية العراقية',
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      builder: (context, child) {
        final media = MediaQuery.of(context);
        return Directionality(
          textDirection: TextDirection.rtl,
          child: MediaQuery(
            data: media.copyWith(textScaler: TextScaler.linear(fontScale)),
            child: child ?? const SizedBox.shrink(),
          ),
        );
      },
      theme: ThemeData(
        useMaterial3: true,
        pageTransitionsTheme: pageTransitions,
        iconTheme: const IconThemeData(size: appIconSize),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          titleMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          bodyLarge: TextStyle(fontSize: 14),
          bodyMedium: TextStyle(fontSize: 13),
          bodySmall: TextStyle(fontSize: 12),
        ),
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(
          seedColor: LibraryPalette.accent,
          brightness: Brightness.light,
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: canvas,
          foregroundColor: navy,
          elevation: 0,
          scrolledUnderElevation: 0,
          surfaceTintColor: Colors.transparent,
          titleSpacing: 18,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(LibraryPalette.radius),
            side: const BorderSide(color: Color(0xFFE7EDF6)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF8793A5)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: const BorderSide(color: Color(0xFFE4EAF3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: const BorderSide(color: blue, width: 1.5),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 13),
            textStyle: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            side: const BorderSide(color: Color(0xFFDCE5F2)),
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        navigationBarTheme: NavigationBarThemeData(
          height: 72,
          backgroundColor: Colors.white,
          indicatorColor: const Color(0xFFE3EBFF),
          surfaceTintColor: Colors.transparent,
          labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        pageTransitionsTheme: pageTransitions,
        iconTheme: const IconThemeData(size: appIconSize),
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          titleMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          bodyLarge: TextStyle(fontSize: 14),
          bodyMedium: TextStyle(fontSize: 13),
          bodySmall: TextStyle(fontSize: 12),
        ),
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D1422),
        colorScheme: ColorScheme.fromSeed(
          seedColor: LibraryPalette.accent,
          brightness: Brightness.dark,
          surface: const Color(0xFF151F30),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0D1422),
          foregroundColor: Color(0xFFF3F6FC),
          elevation: 0,
          scrolledUnderElevation: 0,
          surfaceTintColor: Colors.transparent,
          titleSpacing: 18,
        ),
        cardTheme: CardThemeData(
          color: const Color(0xFF151F30),
          elevation: 0,
          surfaceTintColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(LibraryPalette.radius),
            side: const BorderSide(color: Color(0xFF26364B)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF151F30),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF9BA8BC)),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: const BorderSide(color: Color(0xFF29374B)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(17),
            borderSide: const BorderSide(color: Color(0xFF6B8FF5), width: 1.5),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 13),
            textStyle: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            side: const BorderSide(color: Color(0xFF33435A)),
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        navigationBarTheme: NavigationBarThemeData(
          height: 72,
          backgroundColor: const Color(0xFF111B2B),
          indicatorColor: const Color(0xFF253D68),
          surfaceTintColor: Colors.transparent,
          labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
      home: LibraryHome(
        dark: dark,
        fontScale: fontScale,
        onDarkChanged: _setDarkMode,
        onFontScaleChanged: _setFontScale,
        onAppearanceChanged: _refreshAppearance,
      ),
    );
  }
}

class LibraryHome extends StatefulWidget {
  final bool dark;
  final double fontScale;
  final ValueChanged<bool> onDarkChanged;
  final ValueChanged<double> onFontScaleChanged;
  final VoidCallback onAppearanceChanged;

  const LibraryHome({
    super.key,
    required this.dark,
    required this.fontScale,
    required this.onDarkChanged,
    required this.onFontScaleChanged,
    required this.onAppearanceChanged,
  });

  @override
  State<LibraryHome> createState() => _LibraryHomeState();
}

class _LibraryHomeState extends State<LibraryHome> {
  final books = makeBooks();
  final favorites = <String>{};
  final notes = <String>[];
  bool dataLoaded = false;
  final noteController = TextEditingController();
  final searchController = TextEditingController();
  final savedBookKeys = <String>{};
  final downloadingBookKeys = <String>{};
  final downloadProgress = <String, double?>{};
  final downloadCancellations =
      <String, offline.OfflineDownloadCancellation>{};

  String selectedGrade = grades.first;
  String search = '';
  int page = 0;

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    favorites
      ..clear()
      ..addAll(appPrefs.getStringList('favorites') ?? const <String>[]);
    notes
      ..clear()
      ..addAll(appPrefs.getStringList('notes') ?? const <String>[]);
    final savedGrade = appPrefs.getString('selectedGrade');
    if (savedGrade != null && grades.contains(savedGrade)) selectedGrade = savedGrade;
    try {
      final savedBooks = await offline.loadOfflineBooks();
      savedBookKeys
        ..clear()
        ..addAll(savedBooks.map((b) => b.key));
    } catch (_) {}
    if (mounted) setState(() => dataLoaded = true);
    await _checkCatalogUpdates();
  }

  Future<void> _checkCatalogUpdates() async {
    final signature = books.map((b) => '${b.key}:${b.url}').join('||');
    final previous = appPrefs.getString('bookCatalogSignature');
    await appPrefs.setString('bookCatalogSignature', signature);
    if (previous != null && previous != signature) {
      final notified = await StudyNotificationService.showNow(
        id: 4101,
        title: 'تحديث مكتبة الكتب',
        body: 'تمت إضافة كتاب أو تحديث رابط أحد الكتب في مكتبة المناهج.',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(notified
              ? 'تم تحديث مكتبة الكتب، وأُرسل إشعار بالتحديث.'
              : 'تم تحديث روابط مكتبة الكتب.'),
        ));
      }
    }
  }

  Future<void> _saveFavorites() async {
    try {
      await appPrefs.setStringList('favorites', favorites.toList());
    } catch (error) {
      debugPrint('Could not persist favorites: $error');
    }
  }

  Future<void> _saveNotes() async {
    try {
      await appPrefs.setStringList('notes', notes);
    } catch (error) {
      debugPrint('Could not persist notes: $error');
    }
  }

  String _normaliseSearch(String value) => value
      .trim()
      .toLowerCase()
      .replaceAll('أ', 'ا')
      .replaceAll('إ', 'ا')
      .replaceAll('آ', 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه');

  bool _bookMatchesSearch(SchoolBook book, String query) {
    final text = _normaliseSearch(
      '${book.title} ${book.subject} ${book.grade} ${gradeStage(book.grade)}',
    );
    return text.contains(query);
  }

  List<SchoolBook> get visibleBooks {
    final query = _normaliseSearch(search);
    final source = page == 1
        ? books.where((book) => favorites.contains(book.key))
        : query.isNotEmpty
            ? books
            : books.where((book) => book.grade == selectedGrade);

    if (query.isEmpty) return source.toList();
    return source.where((book) => _bookMatchesSearch(book, query)).toList();
  }

  @override
  void dispose() {
    noteController.dispose();
    searchController.dispose();
    super.dispose();
  }

  void changePage(int value) {
    FocusScope.of(context).unfocus();
    if (page != value) setState(() => page = value);
  }

  Widget _animatedTabPage(int index, Widget child) {
    final active = page == index;
    return ExcludeSemantics(
      excluding: !active,
      child: IgnorePointer(
        ignoring: !active,
        child: AnimatedOpacity(
          opacity: active ? 1 : 0,
          duration: LibraryPalette.reduceMotion ? Duration.zero : const Duration(milliseconds: 220),
          curve: Curves.easeInOutCubic,
          child: AnimatedSlide(
            offset: active ? Offset.zero : const Offset(0, 0.012),
            duration: LibraryPalette.reduceMotion ? Duration.zero : const Duration(milliseconds: 220),
            curve: Curves.easeOutCubic,
            child: TickerMode(enabled: active, child: child),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        // The home screen starts with the first stage card, with no heading above it.
        appBar: page == 0 ? null : AppBar(
          toolbarHeight: 78,
          title: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [blue, Color(0xFF6B8FF5)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(color: blue.withOpacity(0.22), blurRadius: 16, offset: const Offset(0, 6)),
                  ],
                ),
                child: const Icon(
                  Icons.auto_stories_rounded,
                  color: Colors.white,
                  size: 25,
                ),
              ),
              const SizedBox(width: 11),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'مكتبتي',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    'المناهج الدراسية العراقية',
                    style: TextStyle(fontSize: 11),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'الوضع الليلي',
              onPressed: () => widget.onDarkChanged(!widget.dark),
              icon: Icon(
                widget.dark
                    ? Icons.light_mode_rounded
                    : Icons.dark_mode_rounded,
              ),
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final wide = constraints.maxWidth >= 760;

              return Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1100),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      _animatedTabPage(0, buildLibrary(wide)),
                      _animatedTabPage(1, buildFavorites(wide)),
                      _animatedTabPage(2, buildNotes()),
                      _animatedTabPage(3, buildSettings()),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 5, 12, 8),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
            decoration: BoxDecoration(
              color: widget.dark ? const Color(0xFF111B2B) : Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: widget.dark
                    ? const Color(0xFF26364A)
                    : const Color(0xFFE8EDF2),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(widget.dark ? .12 : .055),
                  blurRadius: 18,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                _bottomNavItem(
                  index: 0,
                  label: 'الرئيسية',
                  icon: Icons.home_outlined,
                  selectedIcon: Icons.home_rounded,
                  accent: const Color(0xFF547F73),
                ),
                _bottomNavItem(
                  index: 1,
                  label: 'المفضلة',
                  icon: Icons.favorite_border_rounded,
                  selectedIcon: Icons.favorite_rounded,
                  accent: const Color(0xFFB17B83),
                ),
                _bottomNavItem(
                  index: 2,
                  label: 'الملاحظات',
                  icon: Icons.sticky_note_2_outlined,
                  selectedIcon: Icons.sticky_note_2_rounded,
                  accent: const Color(0xFF7186A0),
                ),
                _bottomNavItem(
                  index: 3,
                  label: 'الإعدادات',
                  icon: Icons.settings_outlined,
                  selectedIcon: Icons.settings_rounded,
                  accent: const Color(0xFF87909B),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _bottomNavItem({
    required int index,
    required String label,
    required IconData icon,
    required IconData selectedIcon,
    required Color accent,
  }) {
    final selected = page == index;
    final selectedBackground = widget.dark
        ? Color.lerp(accent, const Color(0xFF111B2B), .76)!
        : Color.lerp(accent, Colors.white, .86)!;
    final inactive = widget.dark
        ? const Color(0xFF9AA8B8)
        : const Color(0xFF7D8998);

    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => changePage(index),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
            decoration: BoxDecoration(
              color: selected ? selectedBackground : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  selected ? selectedIcon : icon,
                  color: selected ? accent : inactive,
                  size: 22,
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: selected ? accent : inactive,
                    fontSize: 10.5,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildLibrary(bool wide) {
    final query = _normaliseSearch(search);
    return ListView(
      padding: const EdgeInsets.fromLTRB(appSpaceLg, 10, appSpaceLg, 28),
      children: [
        // Open directly on real stage cards: no hero, greeting or extra tiles above them.
        ..._gradeStageSections(wide),
        const SizedBox(height: 10),
        _quickSearchField(),
        if (!dataLoaded) _loadingStatus('جارٍ تجهيز الكتب المحفوظة...'),
        const SizedBox(height: 18),
        if (query.isNotEmpty) ...[
          _globalSearchResults(wide),
        ] else ...[
          const SectionHeading(
            title: 'أدواتك الدراسية',
            subtitle: 'اختصارات تساعدك على تنظيم الدراسة والمراجعة',
          ),
          const SizedBox(height: 12),
          _featureShortcut(
            icon: Icons.offline_pin_rounded,
            title: 'التنزيلات',
            color: stageOrange,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => OfflineCenterScreen(
                books: books,
                onSaved: (key) => setState(() => savedBookKeys.add(key)),
                onDeleted: (key) => setState(() => savedBookKeys.remove(key)),
              )),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            clipBehavior: Clip.antiAlias,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
              leading: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [purple, Color.lerp(purple, blue, .35)!],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.style_rounded, color: Colors.white, size: 25),
              ),
              title: const Text('بطاقات المراجعة', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              subtitle: const Padding(
                padding: EdgeInsets.only(top: 5),
                child: Text('اختر كتب صفك، ثم راجع أسئلة متنوعة تتجدد مع كل جلسة'),
              ),
              trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => FlashcardsPage(initialGrade: selectedGrade, allBooks: books),
              )),
            ),
          ),
        ],
        const SizedBox(height: 24),
        const Center(
          child: Text('مكتبة المناهج العراقية', style: TextStyle(fontSize: 11, color: Colors.grey)),
        ),
      ],
    );
  }

  Widget _loadingStatus(String message) {
    return Card(
      margin: const EdgeInsets.only(bottom: appSpaceMd),
      child: Padding(
        padding: const EdgeInsets.all(appSpaceMd),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2.2),
                ),
                const SizedBox(width: appSpaceSm),
                Expanded(
                  child: Text(message, style: Theme.of(context).textTheme.bodyMedium),
                ),
              ],
            ),
            const SizedBox(height: appSpaceSm),
            const LinearProgressIndicator(minHeight: 3),
          ],
        ),
      ),
    );
  }

  Widget _globalSearchResults(bool wide) {
    final query = _normaliseSearch(search);
    final matchingStages = <String>[
      'المرحلة الابتدائية',
      'المرحلة المتوسطة',
      'المرحلة الإعدادية',
    ].where((stage) => _normaliseSearch(stage).contains(query)).toList();
    final matchingGrades = grades.where((grade) {
      return _normaliseSearch(grade).contains(query) ||
          _normaliseSearch(gradeStage(grade)).contains(query);
    }).toList();
    final matchingBooks = books.where((book) => _bookMatchesSearch(book, query)).toList();

    if (matchingStages.isEmpty && matchingGrades.isEmpty && matchingBooks.isEmpty) {
      return const EmptyState(
        icon: Icons.search_off_rounded,
        title: 'ما لقينا نتائج',
        subtitle: 'جرّب اسم مرحلة أو صف أو مادة أو كتاب.',
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const Expanded(
              child: SectionHeading(
                title: 'نتائج البحث في المكتبة',
                subtitle: 'يشمل جميع المراحل والصفوف والمواد والكتب',
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: blue.withOpacity(.10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '${matchingGrades.length + matchingBooks.length} نتيجة',
                style: const TextStyle(color: blue, fontSize: 11, fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
        if (matchingStages.isNotEmpty) ...[
          const SizedBox(height: 16),
          const Text('المراحل الدراسية', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          ...matchingStages.map((stage) {
            final stageColor = stage == 'المرحلة الابتدائية'
                ? LibraryPalette.stageColor('المرحلة الابتدائية')
                : stage == 'المرحلة المتوسطة'
                    ? LibraryPalette.stageColor('المرحلة المتوسطة')
                    : LibraryPalette.stageColor('المرحلة الإعدادية');
            return Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: _searchStageResult(stage, stageColor),
            );
          }),
        ],
        if (matchingGrades.isNotEmpty) ...[
          const SizedBox(height: 16),
          const Text('الصفوف المطابقة', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          ...matchingGrades.asMap().entries.map((entry) => Padding(
            padding: const EdgeInsets.only(bottom: 9),
            child: _colorfulGradeCard(
              grade: entry.value,
              color: _gradeCardColor(entry.value, entry.key),
              onTap: () => _showGradeSubjects(entry.value),
            ),
          )),
        ],
        if (matchingBooks.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text('المواد والكتب المطابقة (${matchingBooks.length})', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: matchingBooks.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: wide ? 3 : 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              mainAxisExtent: 178,
            ),
            itemBuilder: (context, index) {
              final book = matchingBooks[index];
              return BookCard(
                book: book,
                favorite: favorites.contains(book.key),
                offlineSaved: savedBookKeys.contains(book.key),
                downloading: downloadingBookKeys.contains(book.key),
                downloadProgress: downloadProgress[book.key],
                onCancelDownload: () { downloadCancellations[book.key]?.cancel(); },
                onFavorite: () => toggleFavorite(book),
                onTap: () => openBook(book),
                onDownload: () => downloadBook(book),
                onSchedule: () => scheduleBookReview(book),
              );
            },
          ),
        ],
      ],
    );
  }

  Widget _searchStageResult(String stage, Color color) {
    final count = grades.where((grade) => gradeStage(grade) == stage).length;
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => _showStageGrades(stage),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: color.withOpacity(.25)),
          ),
          child: Row(
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(13)),
                child: Icon(Icons.school_rounded, color: color),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(stage, style: const TextStyle(fontWeight: FontWeight.w900))),
              Text('$count صفوف', style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w800)),
              const SizedBox(width: 6),
              Icon(Icons.chevron_left_rounded, color: color),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _gradeStageSections(bool wide) {
    const stages = <String>[
      'المرحلة الابتدائية',
      'المرحلة المتوسطة',
      'المرحلة الإعدادية',
    ];
    final stageColors = <String, Color>{
      for (final stage in stages) stage: LibraryPalette.stageColor(stage),
    };
    const stageIcons = <String, IconData>{
      'المرحلة الابتدائية': Icons.menu_book_rounded,
      'المرحلة المتوسطة': Icons.school_rounded,
      'المرحلة الإعدادية': Icons.workspace_premium_rounded,
    };

    final cardHeight = LibraryPalette.compact ? 88.0 : (wide ? 116.0 : 108.0);
    return stages.map((stage) {
      final color = stageColors[stage]!;
      final count = grades.where((grade) => gradeStage(grade) == stage).length;
      final subtitle = switch (stage) {
        'المرحلة الابتدائية' => 'من الصف الأول حتى السادس',
        'المرحلة المتوسطة' => 'ثلاثة صفوف دراسية',
        _ => 'فروع علمية وأدبية',
      };
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(LibraryPalette.radius),
          child: InkWell(
            borderRadius: BorderRadius.circular(LibraryPalette.radius),
            onTap: () => _showStageGrades(stage),
            child: Ink(
              height: cardHeight,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [color, Color.lerp(color, Colors.black, .09)!],
                ),
                borderRadius: BorderRadius.circular(LibraryPalette.radius),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(.18),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Positioned(
                    left: -26,
                    top: -36,
                    child: Container(
                      width: 125,
                      height: 125,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.07),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 13),
                    child: Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.18),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.white.withOpacity(.16)),
                          ),
                          child: Icon(stageIcons[stage], color: Colors.white, size: 29),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                stage,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                subtitle,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(.94),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '$count صفوف دراسية',
                                style: TextStyle(color: Colors.white.withOpacity(.78), fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.16),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Icon(Icons.chevron_left_rounded, color: Colors.white, size: 25),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }).toList();
  }

  Future<void> _showStageGrades(String stage) async {
    final stageGrades = grades.where((grade) => gradeStage(grade) == stage).toList();
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => StageGradesScreen(
          stage: stage,
          grades: stageGrades,
          color: LibraryPalette.stageColor(stage),
          gradeColorFor: _gradeCardColor,
          onGradeSelected: _showGradeSubjects,
        ),
      ),
    );
  }

  Color _gradeCardColor(String grade, int index) {
    // Use each grade's existing distinct color; stage cards remain unchanged.
    return gradeColor(grade);
  }

  Widget _colorfulGradeCard({
    required String grade,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(LibraryPalette.radius - 2),
      child: InkWell(
        borderRadius: BorderRadius.circular(LibraryPalette.radius - 2),
        onTap: onTap,
        child: Ink(
          height: LibraryPalette.compact ? 72 : 84,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [color, Color.lerp(color, Colors.black, .07)!],
            ),
            borderRadius: BorderRadius.circular(LibraryPalette.radius - 2),
            boxShadow: [
              BoxShadow(color: color.withOpacity(.16), blurRadius: 12, offset: const Offset(0, 5)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.17),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(gradeIcon(grade), color: Colors.white, size: 25),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(grade, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(gradeStage(grade), maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: Colors.white.withOpacity(.84), fontSize: 11)),
                    ],
                  ),
                ),
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(9)),
                  child: Icon(Icons.chevron_left_rounded, color: color, size: 23),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showGradeSubjects(String grade) async {
    if (grades.contains(grade) && selectedGrade != grade) {
      setState(() => selectedGrade = grade);
      await appPrefs.setString('selectedGrade', grade);
    }
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => GradeSubjectsScreen(
          grade: grade,
          subjects: gradeSubjectsFor(grade),
          books: books,
          onSubjectSelected: (subject) => _showSubjectBooks(grade, subject),
        ),
      ),
    );
  }

  Future<void> _showSubjectBooks(String grade, String subject) async {
    final subjectBooks = books
        .where((book) => book.grade == grade && book.subject == subject)
        .toList();
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => SubjectBooksScreen(
          grade: grade,
          subject: subject,
          books: subjectBooks,
          favorites: favorites,
          savedBookKeys: savedBookKeys,
          downloadingBookKeys: downloadingBookKeys,
          downloadProgress: downloadProgress,
          onCancelDownload: (key) { downloadCancellations[key]?.cancel(); },
          onFavorite: (book) {
            toggleFavorite(book);
          },
          onOpenBook: openBook,
          onDownload: downloadBook,
          onSchedule: (book) {
            scheduleBookReview(book);
          },
        ),
      ),
    );
  }

  Widget _quickSearchField() {
    return TextField(
      controller: searchController,
      onChanged: (value) {
        setState(() => search = value);
      },
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: 'ابحث في جميع المراحل والصفوف والمواد والكتب...',
        prefixIcon: const Icon(Icons.search_rounded),
        suffixIcon: search.isEmpty
            ? null
            : IconButton(
                tooltip: 'مسح البحث',
                onPressed: () {
                  searchController.clear();
                  setState(() => search = '');
                },
                icon: const Icon(Icons.close_rounded),
              ),
        filled: true,
        fillColor: Theme.of(context).cardColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Theme.of(context).dividerColor.withOpacity(.45)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: blue, width: 1.5),
        ),
      ),
    );
  }

  Widget _featureShortcut({required IconData icon, required String title, required Color color, required VoidCallback onTap}) {
    return Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [color.withOpacity(.18), color.withOpacity(.07)],
                    ),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(icon, color: color, size: 21),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, height: 1.25),
                  ),
                ),
                const SizedBox(width: 2),
                Icon(Icons.chevron_left_rounded, size: 17, color: color.withOpacity(.8)),
              ],
            ),
          ),
        ),
    );
  }

  Widget gradeDropdown() {
    final color = gradeColor(selectedGrade);

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(0.35)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: color.withOpacity(0.09),
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(21),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(
                    gradeIcon(selectedGrade),
                    color: Colors.white,
                    size: 25,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        gradeStage(selectedGrade),
                        style: TextStyle(
                          color: color,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        selectedGrade,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.expand_more_rounded, color: color, size: 29),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 5,
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedGrade,
                isExpanded: true,
                borderRadius: BorderRadius.circular(18),
                dropdownColor: Theme.of(context).cardColor,
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: color),
                hint: const Text('اختر الصف الدراسي'),
                items: [
                  ..._stageHeader('المرحلة الابتدائية', LibraryPalette.stageColor('المرحلة الابتدائية')),
                  ..._stageGrades(grades.take(6), LibraryPalette.stageColor('المرحلة الابتدائية')),
                  ..._stageHeader('المرحلة المتوسطة', LibraryPalette.stageColor('المرحلة المتوسطة')),
                  ..._stageGrades(grades.skip(6).take(3), LibraryPalette.stageColor('المرحلة المتوسطة')),
                  ..._stageHeader('المرحلة الإعدادية', LibraryPalette.stageColor('المرحلة الإعدادية')),
                  ..._stageGrades(grades.skip(9), LibraryPalette.stageColor('المرحلة الإعدادية')),
                ],
                onChanged: (value) {
                  if (value == null || !grades.contains(value)) return;
                  setState(() {
                    selectedGrade = value;
                    appPrefs.setString('selectedGrade', value);
                    search = '';
                    searchController.clear();
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<DropdownMenuItem<String>> _stageHeader(
    String title,
    Color color,
  ) {
    return [
      DropdownMenuItem<String>(
        enabled: false,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 7),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(9),
          ),
          child: Row(
            children: [
              Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 9),
              Text(
                title,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    ];
  }

  List<DropdownMenuItem<String>> _stageGrades(
    Iterable<String> stageGrades,
    Color color,
  ) {
    return stageGrades.map((grade) {
      final selected = grade == selectedGrade;

      return DropdownMenuItem<String>(
        value: grade,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
          decoration: BoxDecoration(
            color: selected ? color.withOpacity(0.10) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(gradeIcon(grade), color: color, size: 19),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Text(
                  grade,
                  style: TextStyle(
                    fontWeight: selected ? FontWeight.w900 : FontWeight.w500,
                    color: selected ? color : null,
                    fontSize: 13,
                  ),
                ),
              ),
              if (selected)
                Icon(Icons.check_circle_rounded, color: color, size: 20),
            ],
          ),
        ),
      );
    }).toList();
  }

  // بطاقة رئيسية أقل ارتفاعاً
  Widget heroBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF17365E), Color(0xFF2458B9), Color(0xFF2864E8)],
          stops: [0, .52, 1],
        ),
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(color: blue.withOpacity(.18), blurRadius: 18, offset: const Offset(0, 6)),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            left: 0,
            top: 0,
            child: Icon(Icons.auto_stories_rounded, size: 100, color: Colors.white.withOpacity(.07)),
          ),
          Positioned(
            left: 36,
            bottom: 0,
            child: Icon(Icons.auto_awesome_rounded, size: 26, color: Colors.white.withOpacity(.12)),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(color: Color(0xFF65E0BF), shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.13),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.white.withOpacity(.10)),
                    ),
                    child: const Text(
                      'مساحة تعلّمك',
                      style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'كل كتبك الدراسية، في مكان واحد.',
                maxLines: 2,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 23,
                  height: 1.18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.25,
                ),
              ),
              const SizedBox(height: 7),
              const Text(
                'نظّم دراستك وسهّل وصولك للمعلومة.',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Color(0xFFDCE7FF), fontSize: 11, height: 1.2),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 7,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  _heroMetric(Icons.menu_book_rounded, '${books.length} كتاب'),
                  _heroMetric(Icons.favorite_rounded, '${favorites.length} مفضلة'),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: navy,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                      minimumSize: const Size(0, 36),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity: VisualDensity.compact,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      setState(() {
                        page = 0;
                        search = '';
                        searchController.clear();
                      });
                    },
                    icon: const Icon(Icons.menu_book_rounded, size: 16),
                    label: const Text('تصفّح الكتب', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _heroMetric(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(.10)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 14),
          const SizedBox(width: 5),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget buildFavorites(bool wide) {
    final items = books
        .where((book) => favorites.contains(book.key))
        .toList();

    return ListView(
      padding: const EdgeInsets.all(appSpaceLg),
      children: [
        const SectionHeading(
          title: 'كتبك المفضلة',
          subtitle: 'الكتب التي حفظتها للوصول السريع',
        ),
        const SizedBox(height: 20),
        if (items.isEmpty)
          const EmptyState(
            icon: Icons.favorite_border_rounded,
            title: 'قائمتك فارغة حالياً',
            subtitle: 'اضغط على القلب في أي كتاب لإضافته هنا.',
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: wide ? 3 : 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              mainAxisExtent: 178,
            ),
            itemBuilder: (context, index) {
              final book = items[index];
              return BookCard(
                book: book,
                favorite: true,
                offlineSaved: savedBookKeys.contains(book.key),
                downloading: downloadingBookKeys.contains(book.key),
                downloadProgress: downloadProgress[book.key],
                onCancelDownload: () { downloadCancellations[book.key]?.cancel(); },
                onFavorite: () => toggleFavorite(book),
                onTap: () => openBook(book),
                onDownload: () => downloadBook(book),
                onSchedule: () => scheduleBookReview(book),
              );
            },
          ),
      ],
    );
  }

  Widget buildNotes() {
    return ListView(
      padding: const EdgeInsets.all(appSpaceLg),
      children: [
        const SectionHeading(
          title: 'ملاحظاتي',
          subtitle: 'دوّن أفكارك ومعلوماتك المهمة',
        ),
        const SizedBox(height: 18),
        TextField(
          controller: noteController,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: 'اكتب ملاحظة أو واجباً تريد تذكّره...',
            alignLabelWithHint: true,
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () async {
            final text = noteController.text.trim();
            if (text.isEmpty) return;
            setState(() {
              notes.insert(0, text);
              noteController.clear();
            });
            await _saveNotes();
            FocusScope.of(context).unfocus();
          },
          icon: const Icon(Icons.add_rounded),
          label: const Text('إضافة ملاحظة'),
        ),
        const SizedBox(height: 20),
        if (notes.isEmpty)
          const EmptyState(
            icon: Icons.sticky_note_2_outlined,
            title: 'لا توجد ملاحظات',
            subtitle: 'ابدأ بتدوين أول ملاحظة دراسية.',
          )
        else
          ...notes.asMap().entries.map((entry) {
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: const Icon(Icons.notes_rounded, color: blue),
                title: Text(entry.value),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline_rounded),
                  onPressed: () {
                    setState(() => notes.removeAt(entry.key));
                    _saveNotes();
                  },
                ),
              ),
            );
          }),
      ],
    );
  }

  Future<void> _chooseLibraryColor(String title, Color current,
      Future<void> Function(Color) save) async {
    final chosen = await showLibraryColorPicker(context, title: title, current: current);
    if (chosen == null) return;
    await save(chosen);
    if (!mounted) return;
    widget.onAppearanceChanged();
  }

  Widget _appearanceColorTile(String label, Color color, Future<void> Function(Color) save) {
    return ListTile(
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('اضغط لاختيار لون أو كتابة كوده'),
      leading: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant, width: 2),
        ),
      ),
      trailing: const Icon(Icons.edit_outlined),
      onTap: () => _chooseLibraryColor(label, color, save),
    );
  }

  bool _isBackupKey(String key) =>
      key == 'favorites' || key == 'notes' || key == 'selectedGrade' ||
      key == 'darkMode' || key == 'fontScale' || key == 'quizHistory' ||
      key == 'studyTasks' || key == 'studyReminders' ||
      key == 'studyAssistantHistory' || key.startsWith('lib-') ||
      key.startsWith('pdf-');

  Future<void> _copySettingsBackup() async {
    final values = <String, Object?>{};
    for (final key in appPrefs.getKeys()) {
      if (_isBackupKey(key)) values[key] = appPrefs.get(key);
    }
    final backup = jsonEncode(<String, Object?>{
      'kind': 'iraqi-curriculum-library-backup',
      'version': 1,
      'settings': values,
    });
    await Clipboard.setData(ClipboardData(text: backup));
    if (mounted) showMessage('نُسخت الإعدادات والمفضلة والملاحظات إلى الحافظة. احفظ النص في مكان آمن.');
  }

  Future<void> _restoreSettingsBackup() async {
    final clip = await Clipboard.getData('text/plain');
    final raw = clip?.text;
    if (raw == null || raw.trim().isEmpty) {
      if (mounted) showMessage('لا توجد بيانات منسوخة في الحافظة.');
      return;
    }
    Map<String, dynamic> backup;
    Map<String, dynamic> values;
    try {
      backup = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      if (backup['kind'] != 'iraqi-curriculum-library-backup' || backup['version'] != 1) {
        throw const FormatException('صيغة النسخة غير مطابقة.');
      }
      values = Map<String, dynamic>.from(backup['settings'] as Map);
    } catch (_) {
      if (mounted) showMessage('النص المنسوخ ليس نسخة احتياطية صحيحة للتطبيق.');
      return;
    }
    if (!mounted) return;
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة البيانات؟'),
        content: const Text('ستُستبدل الإعدادات والمفضلة والملاحظات الموجودة بالحقول المحفوظة في النسخة. لن تُحذف ملفات PDF المنزلّة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (accepted != true) return;
    try {
      for (final entry in values.entries) {
        final key = entry.key;
        final value = entry.value;
        if (!_isBackupKey(key)) continue;
        if (value is bool) {
          await appPrefs.setBool(key, value);
        } else if (value is int) {
          await appPrefs.setInt(key, value);
        } else if (value is double) {
          await appPrefs.setDouble(key, value);
        } else if (value is String) {
          await appPrefs.setString(key, value);
        } else if (value is List && value.every((item) => item is String)) {
          await appPrefs.setStringList(key, value.cast<String>());
        }
      }
      LibraryPalette.load(appPrefs, grades);
      await _loadSavedData();
      widget.onDarkChanged(appPrefs.getBool('darkMode') ?? widget.dark);
      widget.onFontScaleChanged(appPrefs.getDouble('fontScale') ?? widget.fontScale);
      widget.onAppearanceChanged();
      if (mounted) showMessage('استُعيدت البيانات المحفوظة.');
    } catch (error) {
      if (mounted) showMessage('تعذّرت استعادة بعض البيانات: $error');
    }
  }

  Widget _appearanceSettingsCard() {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(Icons.palette_rounded, color: LibraryPalette.accent),
        title: const Text('تخصيص ألوان وشكل المكتبة', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('5 لوحات جاهزة وتغيير لون كل مرحلة وصف بشكل مستقل'),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (var i = 0; i < LibraryPalette.presetNames.length; i++)
                OutlinedButton(
                  onPressed: () async {
                    await LibraryPalette.applyPreset(appPrefs, i);
                    if (mounted) widget.onAppearanceChanged();
                  },
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: LibraryPalette.presetColors[i][0]),
                    foregroundColor: LibraryPalette.presetColors[i][0],
                  ),
                  child: Text(LibraryPalette.presetNames[i]),
                ),
            ]),
          ),
          _appearanceColorTile('اللون الأساسي', LibraryPalette.accent,
              (color) => LibraryPalette.setAccent(appPrefs, color)),
          const Divider(),
          for (final stage in LibraryPalette.stageNames)
            _appearanceColorTile(stage, LibraryPalette.stageColor(stage),
                (color) => LibraryPalette.setStage(appPrefs, stage, color)),
          ExpansionTile(
            leading: const Icon(Icons.school_outlined),
            title: const Text('ألوان الصفوف (15 صفاً)'),
            subtitle: const Text('لون خاص لكل صف دون تغيير بقية الصفوف'),
            children: [
              for (final grade in grades)
                _appearanceColorTile(grade, gradeColor(grade),
                    (color) => LibraryPalette.setGrade(appPrefs, grade, color)),
            ],
          ),
          const Divider(),
          ListTile(
            title: const Text('استدارة البطاقات'),
            subtitle: Slider(
              value: LibraryPalette.radius,
              min: 14, max: 30, divisions: 8,
              label: '${LibraryPalette.radius.round()}',
              onChanged: (value) {
                LibraryPalette.radius = value;
                widget.onAppearanceChanged();
              },
              onChangeEnd: (value) => LibraryPalette.setRadius(appPrefs, value),
            ),
          ),
          SwitchListTile(
            title: const Text('بطاقات مدمجة'),
            subtitle: const Text('عرض مزيد من المحتوى على الشاشة'),
            value: LibraryPalette.compact,
            onChanged: (value) async {
              await LibraryPalette.setCompact(appPrefs, value);
              if (mounted) widget.onAppearanceChanged();
            },
          ),
          SwitchListTile(
            title: const Text('تقليل الحركة'),
            subtitle: const Text('تقليل الانتقالات للأجهزة الأبطأ'),
            value: LibraryPalette.reduceMotion,
            onChanged: (value) async {
              await LibraryPalette.setReduceMotion(appPrefs, value);
              if (mounted) widget.onAppearanceChanged();
            },
          ),
        ],
      ),
    );
  }

  Widget buildSettings() {
    return ListView(
      padding: const EdgeInsets.all(appSpaceLg),
      children: [
        const SectionHeading(
          title: 'الإعدادات',
          subtitle: 'خصص تجربتك الدراسية',
        ),
        const SizedBox(height: 20),
        Card(
          child: SwitchListTile(
            secondary: const Icon(Icons.dark_mode_rounded),
            title: const Text('الوضع الليلي'),
            subtitle: const Text('يُحفظ اختيارك حتى بعد إغلاق التطبيق وفتحه مجدداً'),
            value: widget.dark,
            onChanged: widget.onDarkChanged,
          ),
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.text_fields_rounded),
                  title: const Text('حجم الخط'),
                  subtitle: const Text('اضبط حجم النص في جميع صفحات التطبيق'),
                  trailing: Text(
                    '${(widget.fontScale * 100).round()}%',
                    style: const TextStyle(fontWeight: FontWeight.w900, color: blue),
                  ),
                ),
                Slider(
                  value: widget.fontScale,
                  min: 0.85,
                  max: 1.25,
                  divisions: 8,
                  label: '${(widget.fontScale * 100).round()}%',
                  onChanged: widget.onFontScaleChanged,
                ),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('أصغر', style: TextStyle(fontSize: 11)),
                    Text('افتراضي', style: TextStyle(fontSize: 11)),
                    Text('أكبر', style: TextStyle(fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
        ),
        _appearanceSettingsCard(),
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const ListTile(
                leading: Icon(Icons.backup_outlined),
                title: Text('نسخة احتياطية لإعداداتي'),
                subtitle: Text('انسخ المفضلة والملاحظات والألوان إلى الحافظة، أو استعدها منها. ملفات PDF محفوظة على الهاتف ولا تُنسخ هنا.'),
              ),
              Wrap(spacing: 10, runSpacing: 8, children: [
                OutlinedButton.icon(onPressed: _copySettingsBackup, icon: const Icon(Icons.copy_all_rounded), label: const Text('نسخ البيانات')),
                OutlinedButton.icon(onPressed: _restoreSettingsBackup, icon: const Icon(Icons.restore_rounded), label: const Text('استعادة من الحافظة')),
              ]),
            ]),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.calendar_month_rounded, color: teal),
            title: const Text('الجدول الدراسي'),
            subtitle: const Text('التخطيط للمذاكرة دون إضافة بطاقة إلى الرئيسية'),
            trailing: const Icon(Icons.chevron_left_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StudyPlannerScreen())),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.notifications_active_rounded, color: teal),
            title: const Text('إشعارات المذاكرة'),
            subtitle: const Text('تذكير بمراجعة مادة أو عند تحديث روابط الكتب'),
            trailing: IconButton(
              tooltip: 'اختبار الإشعار',
              icon: const Icon(Icons.send_rounded),
              onPressed: () async {
                final shown = await StudyNotificationService.showNow(
                  id: 4102,
                  title: 'مكتبة المناهج العراقية',
                  body: 'هذا إشعار تجريبي لتذكيرك بالمذاكرة.',
                );
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
                  kIsWeb ? 'إشعارات النظام المجدولة غير متاحة في هذه المعاينة. جرّب نسخة Android.' : shown ? 'تم إرسال إشعار تجريبي.' : 'لم يُرسل الإشعار. تحقق من صلاحية الإشعارات في إعدادات الجهاز.',
                )));
              },
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Card(
          child: ListTile(
            leading: Icon(Icons.school_rounded),
            title: Text('مكتبة المناهج العراقية'),
            subtitle: Text('البيانات تحفظ محلياً على الجهاز أو المتصفح ولا تُرسل إلى خادم.'),
          ),
        ),
        Card(child: ListTile(leading: const Icon(Icons.delete_sweep_outlined), title: const Text('مسح بيانات التطبيق المحفوظة'), subtitle: const Text('يحذف المفضلة والملاحظات والنتائج والمهام وسجل المساعد.'), onTap: () async { final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('مسح البيانات؟'), content: const Text('لا يمكن التراجع عن هذه العملية.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('مسح'))])); if (ok == true) { await appPrefs.clear(); quizHistory.clear(); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم مسح البيانات المحلية. أعد تحميل التطبيق لتطبيق الإعدادات.'))); } })),
      ],
    );
  }

  Future<void> toggleFavorite(SchoolBook book) async {
    setState(() {
      if (favorites.contains(book.key)) {
        favorites.remove(book.key);
      } else {
        favorites.add(book.key);
      }
    });
    // Wait for the platform write to finish before returning from the action.
    await _saveFavorites();
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> downloadBook(SchoolBook book) async {
    if (book.url.isEmpty) {
      showMessage('رابط تحميل هذا الكتاب غير متوفر حالياً.');
      return;
    }
    if (kIsWeb) {
      final id = RegExp(r'/d/([^/?]+)').firstMatch(book.url)?.group(1);
      final directUrl = id == null ? book.url : 'https://drive.google.com/uc?export=download&id=$id';
      final opened = await launchUrl(Uri.parse(directUrl), mode: LaunchMode.externalApplication);
      if (mounted) {
        showMessage(opened
            ? 'بدأ تنزيل الملف من المتصفح. لحفظ نسخة داخل التطبيق دون إنترنت استخدم نسخة Android.'
            : 'تعذر فتح رابط التنزيل. جرّب فتح الكتاب أولاً.');
      }
      return;
    }

    final cancellation = offline.OfflineDownloadCancellation();
    setState(() {
      downloadingBookKeys.add(book.key);
      downloadCancellations[book.key] = cancellation;
      downloadProgress[book.key] = null;
    });
    try {
      final saved = await offline.saveBookOffline(
        key: book.key,
        title: book.title,
        grade: book.grade,
        subject: book.subject,
        url: book.url,
        cancellation: cancellation,
        onProgress: (received, total) {
          if (!mounted || total == null || total <= 0) return;
          final value = (received / total).clamp(0, 1).toDouble();
          final previous = downloadProgress[book.key];
          if (previous == null || value >= previous + .01 || value >= 1) {
            setState(() => downloadProgress[book.key] = value);
          }
        },
      );
      if (saved != null) {
        CurriculumBookSearch.invalidateBook(book.key);
        setState(() => savedBookKeys.add(book.key));
        showMessage('تم تنزيل «${book.title}» وحفظه للقراءة دون إنترنت.');
      } else {
        showMessage('لم تُحفظ النسخة محلياً. افتح رابط الكتاب وتأكد من إتاحته للتنزيل.');
        final id = RegExp(r'/d/([^/?]+)').firstMatch(book.url)?.group(1);
        final directUrl = id == null ? book.url : 'https://drive.google.com/uc?export=download&id=$id';
        await launchUrl(Uri.parse(directUrl), mode: LaunchMode.externalApplication);
      }
    } on offline.OfflineDownloadCancelled {
      showMessage('أُلغي تنزيل «${book.title}».');
    } catch (e) {
      showMessage('تعذر حفظ الكتاب: $e');
    } finally {
      if (mounted) {
        setState(() {
          downloadingBookKeys.remove(book.key);
          downloadCancellations.remove(book.key);
          downloadProgress.remove(book.key);
        });
      }
    }
  }

  Future<void> scheduleBookReview(SchoolBook book) async {
    final now = DateTime.now();
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 1)),
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 5),
      helpText: 'اختر يوم المراجعة',
    );
    if (selectedDate == null || !mounted) return;
    final selectedTime = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 19, minute: 0),
      helpText: 'اختر وقت المراجعة',
    );
    if (selectedTime == null || !mounted) return;
    final startAt = DateTime(selectedDate.year, selectedDate.month, selectedDate.day, selectedTime.hour, selectedTime.minute);
    if (!startAt.isAfter(DateTime.now())) {
      showMessage('اختر وقتاً في المستقبل حتى يصل التذكير بموعده.');
      return;
    }

    final target = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('إضافة المراجعة إلى التقويم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            ListTile(leading: const Icon(Icons.calendar_month_rounded, color: blue), title: const Text('Google Calendar'), subtitle: const Text('إضافة حدث إلى تقويم Google'), onTap: () => Navigator.pop(ctx, 'google')),
            ListTile(leading: const Icon(Icons.event_available_rounded, color: teal), title: const Text('Outlook Calendar'), subtitle: const Text('إضافة حدث إلى تقويم Outlook'), onTap: () => Navigator.pop(ctx, 'outlook')),
          ]),
        )),
      ),
    );
    if (target == null || !mounted) return;

    final endAt = startAt.add(const Duration(minutes: 45));
    final eventTitle = 'مراجعة ${book.subject} — ${book.grade}';
    final eventDescription = 'مراجعة كتاب ${book.title} من تطبيق مكتبة المناهج العراقية.';
    Uri eventUri;
    if (target == 'google') {
      String googleDate(DateTime d) => '${d.year.toString().padLeft(4, '0')}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}T${d.hour.toString().padLeft(2, '0')}${d.minute.toString().padLeft(2, '0')}00';
      eventUri = Uri.https('calendar.google.com', '/calendar/render', {
        'action': 'TEMPLATE',
        'text': eventTitle,
        'dates': '${googleDate(startAt)}/${googleDate(endAt)}',
        'ctz': 'Asia/Baghdad',
        'details': eventDescription,
      });
    } else {
      eventUri = Uri.https('outlook.live.com', '/calendar/0/deeplink/compose', {
        'subject': eventTitle,
        'startdt': startAt.toIso8601String(),
        'enddt': endAt.toIso8601String(),
        'body': eventDescription,
      });
    }

    final reminderId = DateTime.now().millisecondsSinceEpoch.remainder(2000000000);
    final notificationScheduled = await StudyNotificationService.schedule(
      id: reminderId,
      title: 'موعد مراجعة دراسية',
      body: 'حان وقت مراجعة ${book.subject} — ${book.grade}.',
      dateTime: startAt,
    );
    final reminders = appPrefs.getStringList('studyReminders') ?? <String>[];
    reminders.add(jsonEncode({
      'id': reminderId,
      'title': eventTitle,
      'grade': book.grade,
      'subject': book.subject,
      'startAt': startAt.toIso8601String(),
      'provider': target,
    }));
    await appPrefs.setStringList('studyReminders', reminders);
    final launched = await launchUrl(eventUri, mode: LaunchMode.externalApplication);
    if (mounted) {
      showMessage(launched
          ? (notificationScheduled
              ? 'فتح التقويم وتم إعداد تذكير مراجعة للمادة.'
              : 'فتح التقويم. في نسخة الويب أو عند منع الإشعارات، احفظ الحدث في التقويم لإتمام التذكير.')
          : 'حُفظ موعد المراجعة في التطبيق، لكن تعذر فتح التقويم.');
    }
  }

  void openBook(SchoolBook book) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final isFavorite = favorites.contains(book.key);

            return Directionality(
              textDirection: TextDirection.rtl,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 26),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 58,
                            height: 66,
                            decoration: BoxDecoration(
                              color: subjectColor(book.subject)
                                  .withOpacity(0.12),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              subjectIcon(book.subject),
                              size: 30,
                              color: subjectColor(book.subject),
                            ),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  book.title,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(book.grade),
                                const SizedBox(height: 3),
                                Text(
                                  book.subject,
                                  style: TextStyle(
                                    color: subjectColor(book.subject),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Text(
                        book.url.isEmpty
                            ? 'لم تتم إضافة رابط لهذا الكتاب بعد.'
                            : 'يمكنك فتح الكتاب أو محاولة تحميله.',
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton(
                              style: FilledButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 12,
                                  horizontal: 5,
                                ),
                              ),
                              onPressed: () async {
                                if (book.url.isEmpty && !savedBookKeys.contains(book.key)) {
                                  showMessage('رابط هذا الكتاب غير متوفر حالياً.');
                                  return;
                                }
                                Navigator.pop(sheetContext);
                                if (!kIsWeb) {
                                  final savedBooks = await offline.loadOfflineBooks();
                                  final matches = savedBooks.where((entry) => entry.key == book.key);
                                  if (matches.isNotEmpty && mounted) {
                                    final saved = matches.first;
                                    if (book.url.isNotEmpty && saved.url != book.url) {
                                      // The catalog link changed: do not silently open an obsolete book.
                                      final update = await showDialog<bool>(
                                        context: context,
                                        builder: (dialogContext) => AlertDialog(
                                          title: const Text('تحديث رابط الكتاب'),
                                          content: Text('توجد نسخة قديمة من «${book.title}» على جهازك. هل تريد تنزيل النسخة المحدثة؟'),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.pop(dialogContext, false),
                                              child: const Text('فتح النسخة المحفوظة'),
                                            ),
                                            FilledButton(
                                              onPressed: () => Navigator.pop(dialogContext, true),
                                              child: const Text('تحميل النسخة الجديدة'),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (!mounted || update == null) return;
                                      if (update) {
                                        await downloadBook(book);
                                        return;
                                      }
                                    }
                                    if (!mounted) return;
                                    await Navigator.of(context).push<void>(MaterialPageRoute(
                                      builder: (_) => PdfReaderScreen(
                                        path: saved.path,
                                        bookKey: saved.key,
                                        title: saved.title,
                                      ),
                                    ));
                                    return;
                                  }
                                }
                                if (book.url.isNotEmpty) {
                                  await launchUrl(Uri.parse(book.url), mode: LaunchMode.externalApplication);
                                } else {
                                  showMessage('تعذر فتح النسخة المحفوظة.');
                                }
                              },
                              child: const Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.menu_book_rounded, size: 19),
                                  SizedBox(height: 4),
                                  Text('فتح الكتاب'),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),
                          Expanded(
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 12,
                                  horizontal: 5,
                                ),
                              ),
                              onPressed: () {
                                Navigator.pop(sheetContext);
                                downloadBook(book);
                              },
                              child: const Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.download_rounded, size: 19),
                                  SizedBox(height: 4),
                                  Text('تحميل'),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),
                          Expanded(
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 12,
                                  horizontal: 3,
                                ),
                              ),
                              onPressed: () {
                                toggleFavorite(book);
                                setSheetState(() {});
                              },
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    isFavorite
                                        ? Icons.favorite_rounded
                                        : Icons.favorite_border_rounded,
                                    size: 19,
                                    color: isFavorite
                                        ? Colors.redAccent
                                        : null,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    isFavorite ? 'إزالة' : 'المفضلة',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () => scheduleBookReview(book),
                          icon: const Icon(Icons.event_available_rounded),
                          label: const Text('جدولة مراجعة في Google أو Outlook'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class ExamsPage extends StatelessWidget {
  final String grade;
  final String difficulty;
  final ValueChanged<String> onGradeChanged;
  final ValueChanged<String> onDifficultyChanged;

  const ExamsPage({
    super.key,
    required this.grade,
    required this.difficulty,
    required this.onGradeChanged,
    required this.onDifficultyChanged,
  });

  @override
  Widget build(BuildContext context) {
    final questionCount = difficulty == 'سهل' ? 10 : difficulty == 'صعب' ? 50 : 25;
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SectionHeading(
          title: 'مركز الاختبارات',
          subtitle: 'اختبارات تفاعلية، تصحيح تلقائي، وسجل دائم للنتائج',
        ),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: grade,
          decoration: const InputDecoration(labelText: 'الصف الدراسي'),
          items: grades.map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
          onChanged: (value) { if (value != null) onGradeChanged(value); },
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: difficulty,
          decoration: const InputDecoration(labelText: 'مستوى الصعوبة'),
          items: const [
            DropdownMenuItem(value: 'سهل', child: Text('سهل — 10 أسئلة')),
            DropdownMenuItem(value: 'متوسط', child: Text('متوسط — 25 سؤالاً')),
            DropdownMenuItem(value: 'صعب', child: Text('صعب — 50 سؤالاً')),
          ],
          onChanged: (value) { if (value != null) onDifficultyChanged(value); },
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Row(children: [
              const Icon(Icons.tune_rounded, color: blue),
              const SizedBox(width: 10),
              Expanded(child: Text('المستوى المحدد: $difficulty • $questionCount سؤالاً في الاختبار', style: const TextStyle(fontWeight: FontWeight.w700))),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        const Text('مواد هذا الصف', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ...gradeSubjectsFor(grade).map((subject) => Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: subjectColor(subject).withOpacity(.12),
              child: Icon(subjectIcon(subject), color: subjectColor(subject)),
            ),
            title: Text(subject, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('$difficulty • $questionCount سؤالاً اختيارياً'),
            trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => QuizScreen(grade: grade, subject: subject, difficulty: difficulty),
              ));
            },
          ),
        )),
        const SizedBox(height: 8),
        const Text(
          'ملاحظة: بنك الأسئلة الحالي تدريبي عام. للحصول على اختبار مطابق حرفياً للمنهج العراقي، يجب إعداد بنك أسئلة موثق من ملفات الكتب المعتمدة.',
          style: TextStyle(fontSize: 12, height: 1.6, color: Colors.grey),
        ),
      ],
    );
  }
}

class StageGradesScreen extends StatelessWidget {
  final String stage;
  final List<String> grades;
  final Color color;
  final Color Function(String, int) gradeColorFor;
  final ValueChanged<String> onGradeSelected;

  const StageGradesScreen({
    super.key,
    required this.stage,
    required this.grades,
    required this.color,
    required this.gradeColorFor,
    required this.onGradeSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('صفوف $stage'),
          leading: IconButton(
            tooltip: 'رجوع',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [color, Color.lerp(color, Colors.black, .08)!],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Row(
                children: [
                  const Icon(Icons.school_rounded, color: Colors.white, size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(stage, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
                        const SizedBox(height: 4),
                        Text('اختر صفك للانتقال إلى المواد الدراسية', style: TextStyle(color: Colors.white.withOpacity(.88), fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Text('${grades.length} صفوف دراسية', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            ...grades.asMap().entries.map((entry) {
              final grade = entry.value;
              final cardColor = gradeColorFor(grade, entry.key);
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _GradeNavigationCard(
                  grade: grade,
                  color: cardColor,
                  onTap: () => onGradeSelected(grade),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class GradeSubjectsScreen extends StatelessWidget {
  final String grade;
  final List<String> subjects;
  final List<SchoolBook> books;
  final ValueChanged<String> onSubjectSelected;

  const GradeSubjectsScreen({
    super.key,
    required this.grade,
    required this.subjects,
    required this.books,
    required this.onSubjectSelected,
  });

  @override
  Widget build(BuildContext context) {
    final color = gradeColor(grade);
    final columns = MediaQuery.of(context).size.width >= 600 ? 3 : 2;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('مواد $grade'),
          leading: IconButton(
            tooltip: 'رجوع',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: color.withOpacity(.09),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: color.withOpacity(.18)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(15)),
                    child: Icon(gradeIcon(grade), color: color, size: 25),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(grade, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Text('اختر المادة لعرض كتبها في صفحة مستقلة', style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: subjects.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                mainAxisExtent: 148,
              ),
              itemBuilder: (context, index) {
                final subject = subjects[index];
                final subjectColorValue = subjectColor(subject);
                final count = books.where((book) => book.grade == grade && book.subject == subject).length;
                return _SubjectNavigationCard(
                  subject: subject,
                  color: subjectColorValue,
                  bookCount: count,
                  onTap: () => onSubjectSelected(subject),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class SubjectBooksScreen extends StatefulWidget {
  final String grade;
  final String subject;
  final List<SchoolBook> books;
  final Set<String> favorites;
  final Set<String> savedBookKeys;
  final Set<String> downloadingBookKeys;
  final Map<String, double?> downloadProgress;
  final ValueChanged<String>? onCancelDownload;
  final ValueChanged<SchoolBook> onFavorite;
  final ValueChanged<SchoolBook> onOpenBook;
  final Future<void> Function(SchoolBook) onDownload;
  final ValueChanged<SchoolBook> onSchedule;

  const SubjectBooksScreen({
    super.key,
    required this.grade,
    required this.subject,
    required this.books,
    required this.favorites,
    required this.savedBookKeys,
    required this.downloadingBookKeys,
    required this.downloadProgress,
    this.onCancelDownload,
    required this.onFavorite,
    required this.onOpenBook,
    required this.onDownload,
    required this.onSchedule,
  });

  @override
  State<SubjectBooksScreen> createState() => _SubjectBooksScreenState();
}

class _SubjectBooksScreenState extends State<SubjectBooksScreen> {
  @override
  Widget build(BuildContext context) {
    final color = subjectColor(widget.subject);
    final wide = MediaQuery.of(context).size.width >= 760;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.subject),
          leading: IconButton(
            tooltip: 'رجوع',
            icon: const Icon(Icons.arrow_back_rounded),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [color.withOpacity(.15), color.withOpacity(.05)],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: color.withOpacity(.22)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(15)),
                    child: Icon(subjectIcon(widget.subject), color: color, size: 25),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.subject, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Text(widget.grade, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      ],
                    ),
                  ),
                  Text('${widget.books.length} كتاب', style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (widget.books.isEmpty)
              const EmptyState(
                icon: Icons.menu_book_outlined,
                title: 'لا توجد كتب مسجلة لهذه المادة',
                subtitle: 'يمكن إضافة روابط الكتب لهذه المادة عند توفرها.',
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.books.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: wide ? 3 : 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  mainAxisExtent: 178,
                ),
                itemBuilder: (context, index) {
                  final book = widget.books[index];
                  return BookCard(
                    book: book,
                    favorite: widget.favorites.contains(book.key),
                    offlineSaved: widget.savedBookKeys.contains(book.key),
                    downloading: widget.downloadingBookKeys.contains(book.key),
                    downloadProgress: widget.downloadProgress[book.key],
                    onCancelDownload: widget.onCancelDownload == null
                        ? null
                        : () => widget.onCancelDownload!(book.key),
                    onFavorite: () {
                      widget.onFavorite(book);
                      setState(() {});
                    },
                    onTap: () => widget.onOpenBook(book),
                    onDownload: () {
                      widget.onDownload(book).whenComplete(() {
                        if (mounted) setState(() {});
                      });
                      setState(() {});
                    },
                    onSchedule: () => widget.onSchedule(book),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _GradeNavigationCard extends StatelessWidget {
  final String grade;
  final Color color;
  final VoidCallback onTap;

  const _GradeNavigationCard({required this.grade, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Ink(
          height: 84,
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color, Color.lerp(color, Colors.black, .07)!]),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: color.withOpacity(.14), blurRadius: 11, offset: const Offset(0, 4))],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(.17), borderRadius: BorderRadius.circular(15)),
                  child: Icon(gradeIcon(grade), color: Colors.white, size: 25),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(grade, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(gradeStage(grade), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.84), fontSize: 11)),
                    ],
                  ),
                ),
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(9)),
                  child: Icon(Icons.chevron_left_rounded, color: color, size: 23),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SubjectNavigationCard extends StatelessWidget {
  final String subject;
  final Color color;
  final int bookCount;
  final VoidCallback onTap;

  const _SubjectNavigationCard({required this.subject, required this.color, required this.bookCount, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).cardColor,
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withOpacity(.13), color.withOpacity(.045)]),
            border: Border.all(color: color.withOpacity(.24)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(11),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(15)),
                  child: Icon(subjectIcon(subject), color: color, size: 25),
                ),
                const SizedBox(height: 9),
                Text(subject, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('$bookCount كتاب', style: TextStyle(fontSize: 10, color: Theme.of(context).hintColor)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class BookCard extends StatelessWidget {
  final SchoolBook book;
  final bool favorite;
  final bool offlineSaved;
  final bool downloading;
  final double? downloadProgress;
  final VoidCallback? onCancelDownload;
  final VoidCallback onFavorite;
  final VoidCallback onTap;
  final VoidCallback onDownload;
  final VoidCallback onSchedule;

  const BookCard({
    super.key,
    required this.book,
    required this.favorite,
    required this.offlineSaved,
    required this.downloading,
    this.downloadProgress,
    this.onCancelDownload,
    required this.onFavorite,
    required this.onTap,
    required this.onDownload,
    required this.onSchedule,
  });

  @override
  Widget build(BuildContext context) {
    final color = subjectColor(book.subject);
    final hasLink = book.url.isNotEmpty;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(11, 10, 11, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [color.withOpacity(.20), color.withOpacity(.07)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(subjectIcon(book.subject), color: color, size: 23),
                  ),
                  const Spacer(),
                  IconButton(
                    constraints: const BoxConstraints.tightFor(width: 30, height: 34),
                    padding: EdgeInsets.zero,
                    visualDensity: VisualDensity.compact,
                    tooltip: 'جدولة مراجعة',
                    onPressed: onSchedule,
                    icon: Icon(Icons.event_available_rounded, color: color, size: 18),
                  ),
                  IconButton(
                    constraints: const BoxConstraints.tightFor(width: 34, height: 34),
                    padding: EdgeInsets.zero,
                    visualDensity: VisualDensity.compact,
                    onPressed: onFavorite,
                    tooltip: favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
                    icon: Icon(
                      favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: favorite ? Colors.redAccent : (isDark ? Colors.white54 : const Color(0xFF9AA6B7)),
                      size: 19,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                book.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, height: 1.25),
              ),
              const SizedBox(height: 4),
              Text(
                book.grade,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const Spacer(),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                    decoration: BoxDecoration(
                      color: (downloading ? blue : hasLink ? teal : Colors.blueGrey).withOpacity(.10),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (downloading && downloadProgress != null)
                          SizedBox(
                            width: 12,
                            height: 12,
                            child: CircularProgressIndicator(
                              value: downloadProgress,
                              strokeWidth: 1.6,
                            ),
                          )
                        else if (downloading)
                          const SizedBox(
                            width: 12,
                            height: 12,
                            child: CircularProgressIndicator(strokeWidth: 1.6),
                          )
                        else
                          Icon(
                            hasLink ? Icons.link_rounded : Icons.schedule_rounded,
                            size: 12,
                            color: hasLink ? teal : Colors.blueGrey,
                          ),
                        const SizedBox(width: 3),
                        Text(
                          downloading && downloadProgress != null
                              ? '${(downloadProgress! * 100).round()}%'
                              : downloading
                                  ? 'جارٍ التنزيل'
                                  : hasLink
                                      ? 'متاح'
                                      : 'قريباً',
                          style: TextStyle(
                            color: downloading ? blue : hasLink ? teal : Colors.blueGrey,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: downloading ? 'جارٍ تنزيل الكتاب' : offlineSaved ? 'النسخة محفوظة دون إنترنت' : 'تحميل الكتاب',
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints.tightFor(width: 34, height: 30),
                    padding: EdgeInsets.zero,
                    onPressed: downloading ? onCancelDownload : onDownload,
                    icon: downloading
                        ? const Icon(Icons.close_rounded, size: 19)
                        : Icon(offlineSaved ? Icons.offline_pin_rounded : Icons.download_rounded, size: 19, color: offlineSaved ? teal : color),
                  ),
                  TextButton(
                    onPressed: onTap,
                    style: TextButton.styleFrom(
                      minimumSize: const Size(0, 31),
                      padding: const EdgeInsets.symmetric(horizontal: 9),
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      visualDensity: VisualDensity.compact,
                      backgroundColor: color.withOpacity(.10),
                      foregroundColor: color,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('عرض', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SectionHeading extends StatelessWidget {
  final String title;
  final String subtitle;

  const SectionHeading({
    super.key,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 4,
          height: 39,
          margin: const EdgeInsets.only(top: 2, left: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [blue, teal], begin: Alignment.topCenter, end: Alignment.bottomCenter),
            borderRadius: BorderRadius.circular(6),
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: appSectionTitleSize,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.25,
                  color: dark ? const Color(0xFFF2F5FB) : navy,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  height: 1.45,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 42, horizontal: 20),
      child: Column(
        children: [
          Container(
            width: 86,
            height: 86,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [blue.withOpacity(.15), teal.withOpacity(.07)],
              ),
              shape: BoxShape.circle,
              border: Border.all(color: blue.withOpacity(.10)),
            ),
            child: Icon(icon, size: 39, color: blue),
          ),
          const SizedBox(height: 17),
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              height: 1.6,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}


class QuizResult {
  final String grade;
  final String subject;
  final String difficulty;
  final int score;
  final int total;
  final DateTime date;
  final List<String> missedUnits;
  const QuizResult({required this.grade, required this.subject, this.difficulty = 'متوسط', required this.score, required this.total, required this.date, this.missedUnits = const <String>[]});
  int get percent => total == 0 ? 0 : (score / total * 100).round();
  Map<String, dynamic> toJson() => {'grade': grade, 'subject': subject, 'difficulty': difficulty, 'score': score, 'total': total, 'date': date.toIso8601String(), 'missedUnits': missedUnits};
  factory QuizResult.fromJson(Map<String, dynamic> json) => QuizResult(
    grade: json['grade'] as String? ?? grades.first,
    subject: json['subject'] as String? ?? 'مادة',
    difficulty: json['difficulty'] as String? ?? 'متوسط',
    score: (json['score'] as num?)?.toInt() ?? 0,
    total: (json['total'] as num?)?.toInt() ?? 0,
    date: DateTime.tryParse(json['date'] as String? ?? '') ?? DateTime.now(),
    missedUnits: (json['missedUnits'] as List<dynamic>? ?? const <dynamic>[]).whereType<String>().toList(),
  );
}

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final results = quizHistory.reversed.toList();
    final average = results.isEmpty ? 0 : (results.map((e) => e.percent).reduce((a, b) => a + b) / results.length).round();
    final weakUnitCounts = <String, int>{};
    for (final result in results) {
      for (final unit in result.missedUnits) {
        final key = '${result.subject} • $unit';
        weakUnitCounts.update(key, (count) => count + 1, ifAbsent: () => 1);
      }
    }
    final weakUnits = weakUnitCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('تقدم الطالب')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
          Expanded(child: _progressMetric('الاختبارات', '${results.length}', Icons.quiz_rounded, blue)),
          Expanded(child: _progressMetric('المتوسط', '$average%', Icons.insights_rounded, teal)),
          Expanded(child: _progressMetric('الأسئلة المجابة', '${results.fold<int>(0, (sum, e) => sum + e.total)}', Icons.check_circle_rounded, purple)),
        ]))),
        const SizedBox(height: 18),
        const SectionHeading(title: 'موضوعات تحتاج مراجعة', subtitle: 'تُستخرج من الموضوعات التي أخطأت فيها في الاختبارات الأخيرة'),
        const SizedBox(height: 10),
        if (weakUnits.isEmpty)
          const EmptyState(icon: Icons.lightbulb_outline_rounded, title: 'لا توجد موضوعات مسجلة للمراجعة', subtitle: 'أكمل اختباراً ثم راجع إجاباتك لتظهر الموضوعات التي تحتاج إلى تدريب.')
        else
          ...weakUnits.take(8).map((entry) => Card(
                margin: const EdgeInsets.only(bottom: 7),
                child: ListTile(
                  leading: const Icon(Icons.menu_book_rounded, color: blue),
                  title: Text(entry.key),
                  trailing: Text('${entry.value} خطأ', style: const TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold)),
                ),
              )),
        const SizedBox(height: 18),
        const SectionHeading(title: 'سجل الاختبارات', subtitle: 'النتائج المحفوظة على هذا الجهاز أو المتصفح'),
        const SizedBox(height: 12),
        if (results.isEmpty)
          const EmptyState(icon: Icons.auto_graph_rounded, title: 'لا توجد نتائج بعد', subtitle: 'أكمل اختباراً من مركز الاختبارات حتى يظهر تقدمك هنا.')
        else ...results.map((r) => Card(margin: const EdgeInsets.only(bottom: 9), child: ListTile(
          leading: CircleAvatar(backgroundColor: (r.percent >= 50 ? teal : Colors.orange).withOpacity(.12), child: Text('${r.percent}%', style: TextStyle(fontSize: 11, color: r.percent >= 50 ? teal : Colors.orange, fontWeight: FontWeight.bold))),
          title: Text('${r.subject} — ${r.grade}', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('المستوى ${r.difficulty} • الدرجة ${r.score} من ${r.total}  •  ${r.date.year}/${r.date.month}/${r.date.day}'),
          trailing: const Icon(Icons.chevron_left_rounded),
        ))),
        const SizedBox(height: 10),
        const Text('تُحفظ النتائج محلياً على هذا الجهاز أو المتصفح. مسح بيانات التطبيق أو المتصفح قد يحذفها.', style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.6)),
      ]),
    ));
  }
  Widget _progressMetric(String label, String value, IconData icon, Color color) => Column(children: [Icon(icon, color: color, size: 24), const SizedBox(height: 7), Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11), textAlign: TextAlign.center)]);
}
