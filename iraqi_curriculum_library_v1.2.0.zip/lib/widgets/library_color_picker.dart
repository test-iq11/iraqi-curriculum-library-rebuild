import 'package:flutter/material.dart';

/// Accessible color picker with ready-made colors and exact #RRGGBB input.
Future<Color?> showLibraryColorPicker(
  BuildContext context, {
  required String title,
  required Color current,
}) async {
  const swatches = <Color>[
    Color(0xFF2864E8), Color(0xFF10A97D), Color(0xFFF59E0B),
    Color(0xFF8257CF), Color(0xFFE05E76), Color(0xFF176FAD),
    Color(0xFF157F74), Color(0xFF495A76), Color(0xFFCD6844),
    Color(0xFF9755A0), Color(0xFF3E9CB4), Color(0xFF8B5E3C),
  ];
  String toHex(Color color) => '#${(color.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';
  Color? parseHex(String input) {
    final clean = input.trim().replaceFirst('#', '');
    if (!RegExp(r'^[a-fA-F0-9]{6}$').hasMatch(clean)) return null;
    return Color(0xFF000000 | int.parse(clean, radix: 16));
  }

  final input = TextEditingController(text: toHex(current));
  Color selection = current;
  String? error;
  final result = await showDialog<Color>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, update) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(title),
          content: SizedBox(
            width: 340,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  height: 54,
                  decoration: BoxDecoration(
                    color: selection,
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 9,
                  runSpacing: 9,
                  children: swatches.map((color) => InkWell(
                    onTap: () => update(() {
                      selection = color;
                      input.text = toHex(color);
                      error = null;
                    }),
                    borderRadius: BorderRadius.circular(23),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant, width: 2),
                      ),
                      child: selection.toARGB32() == color.toARGB32()
                          ? const Icon(Icons.check_rounded, color: Colors.white) : null,
                    ),
                  )).toList(),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: input,
                  textDirection: TextDirection.ltr,
                  maxLength: 7,
                  decoration: InputDecoration(
                    labelText: 'كود اللون HEX',
                    hintText: '#2864E8',
                    errorText: error,
                    prefixIcon: const Icon(Icons.palette_outlined),
                  ),
                  onChanged: (text) {
                    final color = parseHex(text);
                    if (color != null) update(() { selection = color; error = null; });
                  },
                ),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                final parsed = parseHex(input.text);
                if (parsed == null) { update(() => error = 'اكتب ست خانات HEX مثل #2864E8'); return; }
                Navigator.pop(dialogContext, parsed);
              },
              child: const Text('تطبيق اللون'),
            ),
          ],
        ),
      ),
    ),
  );
  input.dispose();
  return result;
}
