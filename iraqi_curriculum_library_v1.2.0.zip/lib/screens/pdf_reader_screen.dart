import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'pdf_reader_controls.dart';

class PdfReaderScreen extends StatefulWidget {
  final String path;
  final String bookKey;
  final String title;

  const PdfReaderScreen({
    super.key,
    required this.path,
    required this.bookKey,
    required this.title,
  });

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> with WidgetsBindingObserver {
  final PdfViewerController _controller = PdfViewerController();
  PdfTextSearcher? _textSearcher;
  // Page changes should never rebuild the native PDF surface while scrolling.
  final ValueNotifier<int> _visiblePage = ValueNotifier<int>(1);
  Timer? _progressSaveTimer;
  bool _fastMode = true;
  PdfDocument? _document;
  List<PdfOutlineNode> _outline = const [];
  bool _outlineLoaded = false;
  int _page = 1;
  int _initialPage = 1;
  int _totalPages = 0;
  bool _stateLoaded = false;
  List<int> _bookmarks = const [];
  List<_BookNote> _notes = const [];

  String get _progressKey => 'pdf-progress:${widget.bookKey}';
  String get _bookmarksKey => 'pdf-bookmarks:${widget.bookKey}';
  String get _notesKey => 'pdf-notes:${widget.bookKey}';
  bool get _currentPageBookmarked => _bookmarks.contains(_page);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _restoreReadingState();
  }

  Future<void> _restoreReadingState() async {
    final prefs = await SharedPreferences.getInstance();
    final page = prefs.getInt(_progressKey) ?? 1;
    _fastMode = prefs.getBool('pdf-fast-mode') ?? true;
    final bookmarks = prefs.getStringList(_bookmarksKey) ?? const <String>[];
    final notes = prefs.getStringList(_notesKey) ?? const <String>[];
    final restoredNotes = <_BookNote>[];
    for (final item in notes) {
      try {
        restoredNotes.add(_BookNote.fromJson(Map<String, dynamic>.from(jsonDecode(item) as Map)));
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _initialPage = page < 1 ? 1 : page;
      _page = _initialPage;
      _visiblePage.value = _initialPage;
      _bookmarks = bookmarks.map(int.tryParse).whereType<int>().toList()..sort();
      _notes = restoredNotes;
      _stateLoaded = true;
    });
  }

  void _setVisiblePage(int page, {bool save = true}) {
    if (page < 1 || page == _page) return;
    _page = page;
    _visiblePage.value = page;
    if (save) _queueProgressSave(page);
  }

  // Avoid one expensive platform-channel write for every scroll event.
  // The latest page is flushed when the reader closes as well.
  void _queueProgressSave(int page) {
    _progressSaveTimer?.cancel();
    _progressSaveTimer = Timer(
      const Duration(milliseconds: 850),
      () => unawaited(_persistProgress(page)),
    );
  }

  Future<void> _persistProgress(int page) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_progressKey, page);
    } catch (error) {
      debugPrint('Could not save PDF reading position: $error');
    }
  }

  void _onPageChanged(int? page) {
    if (page != null) _setVisiblePage(page);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_stateLoaded &&
        (state == AppLifecycleState.inactive ||
            state == AppLifecycleState.paused ||
            state == AppLifecycleState.detached)) {
      _progressSaveTimer?.cancel();
      unawaited(_persistProgress(_page));
    }
  }

  Future<void> _toggleFastMode() async {
    setState(() => _fastMode = !_fastMode);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('pdf-fast-mode', _fastMode);
    } catch (error) {
      debugPrint('Could not persist PDF quality mode: $error');
    }
  }

  void _onViewerReady(PdfDocument document, PdfViewerController controller) {
    if (!mounted) return;
    _document = document;
    _textSearcher ??= PdfTextSearcher(controller)..addListener(_onSearchChanged);
    final total = document.pages.length;
    setState(() {
      _totalPages = total;
      _page = (controller.pageNumber ?? _initialPage).clamp(1, total == 0 ? 1 : total).toInt();
      _visiblePage.value = _page;
    });
    if (total > 0 && _initialPage > total) {
      unawaited(controller.goToPage(pageNumber: total, duration: Duration.zero));
    }
    unawaited(_loadOutline(document));
  }

  void _onSearchChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _loadOutline(PdfDocument document) async {
    try {
      final outline = await document.loadOutline();
      if (!mounted || !identical(_document, document)) return;
      setState(() {
        _outline = outline;
        _outlineLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _outlineLoaded = true);
    }
  }

  Future<void> _showBookSearch() async {
    final searcher = _textSearcher;
    if (searcher == null) return;
    final input = TextEditingController(text: searcher.pattern is String ? searcher.pattern! as String : '');
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .78,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
              child: Row(children: [
                const Icon(Icons.manage_search_rounded, color: Color(0xFF16A89A)),
                const SizedBox(width: 9),
                const Expanded(child: Text('بحث داخل الكتاب', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
                if (searcher.isSearching)
                  SizedBox(width: 21, height: 21, child: CircularProgressIndicator(value: searcher.searchProgress, strokeWidth: 2.4)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: input,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'اكتب كلمة أو موضوعاً',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: IconButton(
                    tooltip: 'مسح البحث',
                    onPressed: () { input.clear(); searcher.resetTextSearch(); },
                    icon: const Icon(Icons.close_rounded),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                ),
                onSubmitted: (value) {
                  final query = value.trim();
                  if (query.isNotEmpty) searcher.startTextSearch(query, caseInsensitive: true, goToFirstMatch: false, searchImmediately: true);
                },
              ),
            ),
            const SizedBox(height: 9),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    final query = input.text.trim();
                    if (query.isNotEmpty) searcher.startTextSearch(query, caseInsensitive: true, goToFirstMatch: false, searchImmediately: true);
                  },
                  icon: const Icon(Icons.search_rounded),
                  label: const Text('ابحث في جميع الصفحات'),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  searcher.isSearching ? 'جارٍ البحث… ${searcher.matches.length} نتيجة حتى الآن' : 'النتائج: ${searcher.matches.length}',
                  style: const TextStyle(color: Colors.black54, fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ),
            Expanded(
              child: searcher.matches.isEmpty
                  ? _ReaderEmptyState(
                      icon: searcher.isSearching ? Icons.hourglass_top_rounded : Icons.search_off_rounded,
                      label: searcher.pattern == null ? 'اكتب كلمة لبدء البحث' : (searcher.isSearching ? 'يتم فحص صفحات الكتاب' : 'لا توجد نتائج مطابقة'),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
                      itemCount: searcher.matches.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 4),
                      itemBuilder: (context, index) {
                        final match = searcher.matches[index];
                        return Card(
                          child: ListTile(
                            leading: CircleAvatar(backgroundColor: const Color(0xFF16A89A).withValues(alpha: .12), child: Text('${match.pageNumber}', style: const TextStyle(color: Color(0xFF087C72), fontWeight: FontWeight.w900))),
                            title: Text(match.text.trim().replaceAll(RegExp(r'\s+'), ' '), maxLines: 2, overflow: TextOverflow.ellipsis),
                            subtitle: Text('الصفحة ${match.pageNumber} • نتيجة ${index + 1}'),
                            trailing: const Icon(Icons.north_west_rounded),
                            onTap: () async {
                              await searcher.goToMatch(match);
                              if (sheetContext.mounted) Navigator.pop(sheetContext);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
    input.dispose();
  }

  Future<void> _showThumbnails() async {
    final document = _document;
    if (document == null || _totalPages < 1) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .82,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 3, 20, 12),
              child: Row(children: [
                const Icon(Icons.grid_view_rounded, color: Color(0xFF16A89A)),
                const SizedBox(width: 9),
                const Expanded(child: Text('فهرس الصفحات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
                Text('$_totalPages صفحة', style: const TextStyle(color: Colors.black54, fontSize: 12)),
              ]),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.fromLTRB(14, 2, 14, 20),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, childAspectRatio: .62, crossAxisSpacing: 11, mainAxisSpacing: 12),
                itemCount: _totalPages,
                itemBuilder: (context, index) {
                  final page = index + 1;
                  final selected = page == _page;
                  return Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () { Navigator.pop(sheetContext); _goToPage(page); },
                      child: Container(
                        decoration: BoxDecoration(border: Border.all(color: selected ? const Color(0xFF16A89A) : Colors.black12, width: selected ? 2 : 1), borderRadius: BorderRadius.circular(14)),
                        child: Column(children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(5),
                              child: PdfPageView(document: document, pageNumber: page, maximumDpi: 60, backgroundColor: Colors.white),
                            ),
                          ),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            color: selected ? const Color(0xFF16A89A).withValues(alpha: .10) : const Color(0xFFF3F6FA),
                            child: Text('الصفحة $page', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: selected ? const Color(0xFF087C72) : const Color(0xFF34465B))),
                          ),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _appendOutlineRows(List<PdfOutlineNode> nodes, List<({PdfOutlineNode node, int depth})> rows, [int depth = 0]) {
    for (final node in nodes) {
      rows.add((node: node, depth: depth));
      _appendOutlineRows(node.children, rows, depth + 1);
    }
  }

  Future<void> _showContents() async {
    if (!_outlineLoaded) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('جارٍ تحميل فهرس الفصول…')));
      return;
    }
    final rows = <({PdfOutlineNode node, int depth})>[];
    _appendOutlineRows(_outline, rows);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SizedBox(
          height: MediaQuery.of(sheetContext).size.height * .72,
          child: Column(children: [
            const Padding(padding: EdgeInsets.fromLTRB(20, 2, 20, 14), child: Align(alignment: Alignment.centerRight, child: Text('فهرس الفصول', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)))),
            Expanded(
              child: rows.isEmpty
                  ? const _ReaderEmptyState(icon: Icons.menu_book_outlined, label: 'لا يحتوي هذا الملف على فهرس فصول داخلي')
                  : ListView.builder(
                      itemCount: rows.length,
                      itemBuilder: (context, index) {
                        final row = rows[index];
                        final page = row.node.dest?.pageNumber;
                        return ListTile(
                          contentPadding: EdgeInsetsDirectional.fromSTEB(18 + row.depth * 18.0, 4, 18, 4),
                          leading: Icon(row.depth == 0 ? Icons.bookmark_outline_rounded : Icons.subdirectory_arrow_left_rounded, color: const Color(0xFF16A89A)),
                          title: Text(row.node.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: row.depth == 0 ? FontWeight.w800 : FontWeight.w600)),
                          subtitle: page == null ? null : Text('الصفحة $page'),
                          trailing: page == null ? null : const Icon(Icons.chevron_left_rounded),
                          onTap: page == null ? null : () {
                            Navigator.pop(sheetContext);
                            unawaited(_controller.goToDest(row.node.dest, duration: const Duration(milliseconds: 160)).then((_) {}));
                          },
                        );
                      },
                    ),
            ),
          ]),
        ),
      ),
    );
  }

  void _goToPage(int page) {
    if (!_controller.isReady || _controller.pageCount < 1) return;
    final target = page.clamp(1, _controller.pageCount).toInt();
    // A direct page jump is faster and avoids a long animation on slow devices.
    unawaited(_controller.goToPage(pageNumber: target, duration: const Duration(milliseconds: 90)));
    _setVisiblePage(target);
  }

  Future<void> _toggleBookmark() async {
    final updated = [..._bookmarks];
    final removed = updated.remove(_page);
    if (!removed) updated.add(_page);
    updated.sort();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_bookmarksKey, updated.map((page) => '$page').toList());
    if (!mounted) return;
    setState(() => _bookmarks = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(removed ? 'أُزيلت علامة الصفحة $_page.' : 'حُفظت الصفحة $_page في العلامات.'),
      ),
    );
  }

  Future<void> _removeBookmark(int page) async {
    final updated = [..._bookmarks]..remove(page);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_bookmarksKey, updated.map((item) => '$item').toList());
    if (mounted) setState(() => _bookmarks = updated);
  }

  Future<void> _addNote() async {
    final controller = TextEditingController();
    final note = await showDialog<String>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text('ملاحظة للصفحة $_page'),
          content: TextField(
            controller: controller,
            autofocus: true,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'اكتب ملاحظتك عن هذه الصفحة'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('حفظ')),
          ],
        ),
      ),
    );
    controller.dispose();
    if (note == null || note.isEmpty || !mounted) return;
    final updated = [_BookNote(page: _page, text: note), ..._notes];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_notesKey, updated.map((item) => jsonEncode(item.toJson())).toList());
    if (mounted) setState(() => _notes = updated);
  }

  Future<void> _removeNote(_BookNote note) async {
    final updated = [..._notes]..remove(note);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_notesKey, updated.map((item) => jsonEncode(item.toJson())).toList());
    if (mounted) setState(() => _notes = updated);
  }

  Future<void> _showPagePicker() async {
    if (_totalPages < 1) return;
    final input = TextEditingController(text: '$_page');
    final target = await showDialog<int>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('الانتقال إلى صفحة'),
          content: TextField(
            controller: input,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'رقم الصفحة', helperText: 'من 1 إلى $_totalPages'),
            onSubmitted: (_) => Navigator.pop(dialogContext, _parsePage(input.text)),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton.icon(
              onPressed: () => Navigator.pop(dialogContext, _parsePage(input.text)),
              icon: const Icon(Icons.arrow_forward_rounded),
              label: const Text('انتقال'),
            ),
          ],
        ),
      ),
    );
    input.dispose();
    if (target != null) _goToPage(target);
  }

  int? _parsePage(String value) {
    final western = value
        .replaceAllMapped(RegExp('[٠-٩]'), (match) => '${match.group(0)!.codeUnitAt(0) - 0x0660}')
        .replaceAllMapped(RegExp('[۰-۹]'), (match) => '${match.group(0)!.codeUnitAt(0) - 0x06F0}');
    final page = int.tryParse(western.trim());
    return page != null && page >= 1 && page <= _totalPages ? page : null;
  }

  Future<void> _showQuickAccess() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: StatefulBuilder(
          builder: (sheetContext, setSheetState) => SizedBox(
            height: MediaQuery.of(sheetContext).size.height * .7,
            child: DefaultTabController(
              length: 2,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 2, 20, 10),
                  child: Row(children: [
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('الوصول السريع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                      Text('علاماتك وملاحظاتك المحفوظة', style: TextStyle(color: Colors.black54, fontSize: 12)),
                    ])),
                    IconButton.filledTonal(
                      tooltip: 'اختيار رقم صفحة',
                      onPressed: () { Navigator.pop(sheetContext); _showPagePicker(); },
                      icon: const Icon(Icons.pin_rounded),
                    ),
                  ]),
                ),
                const TabBar(tabs: [
                  Tab(icon: Icon(Icons.bookmarks_outlined), text: 'العلامات'),
                  Tab(icon: Icon(Icons.sticky_note_2_outlined), text: 'الملاحظات'),
                ]),
                Expanded(child: TabBarView(children: [
                  _bookmarks.isEmpty
                      ? const _ReaderEmptyState(icon: Icons.bookmark_border_rounded, label: 'لا توجد صفحات محفوظة بعد')
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _bookmarks.length,
                          itemBuilder: (context, index) {
                            final page = _bookmarks[index];
                            return Card(
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.bookmark_added_rounded)),
                                title: Text('الصفحة $page'),
                                subtitle: const Text('علامة محفوظة'),
                                onTap: () { Navigator.pop(sheetContext); _goToPage(page); },
                                trailing: IconButton(
                                  tooltip: 'إلغاء حفظ الصفحة $page',
                                  icon: const Icon(Icons.bookmark_remove_outlined, color: Colors.redAccent),
                                  onPressed: () async { await _removeBookmark(page); setSheetState(() {}); },
                                ),
                              ),
                            );
                          },
                        ),
                  _notes.isEmpty
                      ? const _ReaderEmptyState(icon: Icons.note_alt_outlined, label: 'لا توجد ملاحظات محفوظة بعد')
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _notes.length,
                          itemBuilder: (context, index) {
                            final note = _notes[index];
                            return Card(
                              child: ListTile(
                                leading: const CircleAvatar(child: Icon(Icons.sticky_note_2_rounded)),
                                title: Text(note.text, maxLines: 2, overflow: TextOverflow.ellipsis),
                                subtitle: Text('الصفحة ${note.page}'),
                                onTap: () { Navigator.pop(sheetContext); _goToPage(note.page); },
                                trailing: IconButton(
                                  tooltip: 'حذف الملاحظة',
                                  icon: const Icon(Icons.delete_outline_rounded),
                                  onPressed: () async { await _removeNote(note); setSheetState(() {}); },
                                ),
                              ),
                            );
                          },
                        ),
                ])),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPageControls() => ValueListenableBuilder<int>(
        valueListenable: _visiblePage,
        builder: (context, page, _) => PdfReaderControls(
          pageNumber: page,
          pageCount: _totalPages,
          onPreviewPage: (value) => _visiblePage.value = value,
          onGoToPage: _goToPage,
          onShowThumbnails: _showThumbnails,
        ),
      );

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _progressSaveTimer?.cancel();
    if (_stateLoaded) unawaited(_persistProgress(_page));
    _visiblePage.dispose();
    _textSearcher?.removeListener(_onSearchChanged);
    _textSearcher?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: const Color(0xFFE9EEF5),
          appBar: AppBar(
            backgroundColor: const Color(0xFF10253F),
            foregroundColor: Colors.white,
            elevation: 0,
            titleSpacing: 0,
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
              const Text('قارئ المناهج • يحفظ تقدمك تلقائياً', style: TextStyle(fontSize: 10, color: Colors.white70)),
            ]),
            actions: [
              PopupMenuButton<String>(
                tooltip: 'خيارات القارئ',
                icon: Icon(Icons.tune_rounded,
                    color: _fastMode ? const Color(0xFFFFD166) : Colors.white),
                onSelected: (option) {
                  if (option == 'speed') {
                    unawaited(_toggleFastMode());
                  } else if (option == 'search') {
                    unawaited(_showBookSearch());
                  } else if (option == 'outline') {
                    unawaited(_showContents());
                  } else if (option == 'thumbnails') {
                    unawaited(_showThumbnails());
                  }
                },
                itemBuilder: (context) => [
                  PopupMenuItem(
                    value: 'speed',
                    child: Row(children: [
                      Icon(_fastMode ? Icons.bolt_rounded : Icons.high_quality_rounded),
                      const SizedBox(width: 10),
                      Text(_fastMode ? 'تصفح سريع: مفعّل' : 'جودة أعلى: مفعّلة'),
                    ]),
                  ),
                  PopupMenuItem(
                    value: 'search',
                    enabled: _textSearcher != null,
                    child: const Row(children: [
                      Icon(Icons.search_rounded), SizedBox(width: 10),
                      Text('البحث داخل الكتاب'),
                    ]),
                  ),
                  const PopupMenuItem(
                    value: 'outline',
                    child: Row(children: [
                      Icon(Icons.segment_rounded), SizedBox(width: 10),
                      Text('فهرس الفصول'),
                    ]),
                  ),
                  const PopupMenuItem(
                    value: 'thumbnails',
                    child: Row(children: [
                      Icon(Icons.grid_view_rounded), SizedBox(width: 10),
                      Text('صور الصفحات'),
                    ]),
                  ),
                ],
              ),
              ValueListenableBuilder<int>(
                valueListenable: _visiblePage,
                builder: (context, page, _) {
                  final bookmarked = _bookmarks.contains(page);
                  return IconButton(
                    tooltip: bookmarked ? 'إلغاء حفظ الصفحة الحالية' : 'حفظ الصفحة الحالية',
                    onPressed: _stateLoaded ? _toggleBookmark : null,
                    icon: Icon(bookmarked ? Icons.bookmark_added_rounded : Icons.bookmark_add_outlined),
                    color: bookmarked ? const Color(0xFFFFD166) : Colors.white,
                  );
                },
              ),
              IconButton(tooltip: 'ملاحظة لهذه الصفحة', onPressed: _stateLoaded ? _addNote : null, icon: const Icon(Icons.note_add_outlined)),
              IconButton(
                tooltip: 'العلامات والملاحظات والتنقل السريع',
                onPressed: _showQuickAccess,
                icon: Badge(
                  isLabelVisible: _bookmarks.isNotEmpty || _notes.isNotEmpty,
                  label: Text('${_bookmarks.length + _notes.length}'),
                  child: const Icon(Icons.toc_rounded),
                ),
              ),
              const SizedBox(width: 4),
            ],
          ),
          body: _stateLoaded
              ? PdfViewer.file(
                  widget.path,
                  controller: _controller,
                  initialPageNumber: _initialPage,
                  params: PdfViewerParams(
                    margin: 16,
                    backgroundColor: const Color(0xFFE9EEF5),
                    pageDropShadow: BoxShadow(color: const Color(0xFF10253F).withValues(alpha: .18), blurRadius: 13, spreadRadius: 1, offset: const Offset(0, 5)),
                    // Cache the nearest pages, not a large number of expensive
                    // scanned spreads on low-memory phones.
                    verticalCacheExtent: _fastMode ? 0.95 : 1.35,
                    maxImageBytesCachedOnMemory: _fastMode ? 70 * 1024 * 1024 : 110 * 1024 * 1024,
                    getPageRenderingScale: (context, page, controller, estimatedScale) =>
                        estimatedScale.clamp(0.4, _fastMode ? 1.7 : 3.0).toDouble(),
                    interactionEndFrictionCoefficient: 0.000008,
                    pagePaintCallbacks: [if (_textSearcher != null) _textSearcher!.pageTextMatchPaintCallback],
                    behaviorControlParams: const PdfViewerBehaviorControlParams(
                      trailingPageLoadingDelay: Duration(milliseconds: 25),
                      pageImageCachingDelay: Duration.zero,
                      partialImageLoadingDelay: Duration.zero,
                      enableLowResolutionPagePreview: true,
                      // Keep full-document search functional; on-demand
                      // dimensions omit text on pages not visited yet.
                      loadPageDimensionsOnDemand: false,
                    ),
                    loadingBannerBuilder: (context, bytesDownloaded, totalBytes) {
                      final progress = totalBytes != null && totalBytes > 0
                          ? (bytesDownloaded / totalBytes).clamp(0.0, 1.0).toDouble()
                          : null;
                      return Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [
                            BoxShadow(color: const Color(0xFF10253F).withValues(alpha: .10), blurRadius: 20, offset: const Offset(0, 6)),
                          ]),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            SizedBox(width: 32, height: 32, child: CircularProgressIndicator(value: progress, strokeWidth: 3, color: const Color(0xFF16A89A))),
                            const SizedBox(height: 12),
                            const Text('جارٍ فتح الكتاب…', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF10253F))),
                          ]),
                        ),
                      );
                    },
                    errorBannerBuilder: (context, error, stackTrace, documentRef) => Center(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(24),
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 420),
                          padding: const EdgeInsets.all(22),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: [
                            BoxShadow(color: const Color(0xFF10253F).withValues(alpha: .10), blurRadius: 20, offset: const Offset(0, 6)),
                          ]),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.picture_as_pdf_rounded, size: 46, color: Color(0xFFB42318)),
                            const SizedBox(height: 12),
                            const Text('تعذّر فتح هذا الكتاب', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF10253F))),
                            const SizedBox(height: 8),
                            const Text('عد إلى المكتبة وحاول فتح الكتاب مرة أخرى. إذا تكرر الخطأ، أرسل التفاصيل أدناه.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
                            const SizedBox(height: 12),
                            SelectableText(error.toString(), maxLines: 5, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Colors.black45)),
                            const SizedBox(height: 14),
                            FilledButton.icon(onPressed: () => Navigator.of(context).maybePop(), icon: const Icon(Icons.arrow_back_rounded), label: const Text('العودة إلى المكتبة')),
                          ]),
                        ),
                      ),
                    ),
                    onPageChanged: _onPageChanged,
                    onViewerReady: _onViewerReady,
                  ),
                )
              : const Center(child: CircularProgressIndicator(color: Color(0xFF16A89A))),
          bottomNavigationBar: _stateLoaded ? _buildPageControls() : null,
        ),
      );
}

class _ReaderEmptyState extends StatelessWidget {
  final IconData icon;
  final String label;

  const _ReaderEmptyState({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 38, color: Colors.black38),
          const SizedBox(height: 10),
          Text(label, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700)),
        ]),
      );
}

class _BookNote {
  final int page;
  final String text;

  const _BookNote({required this.page, required this.text});

  Map<String, dynamic> toJson() => {'page': page, 'text': text};

  factory _BookNote.fromJson(Map<String, dynamic> json) => _BookNote(
        page: (json['page'] as num?)?.toInt() ?? 1,
        text: json['text'] as String? ?? '',
      );
}
