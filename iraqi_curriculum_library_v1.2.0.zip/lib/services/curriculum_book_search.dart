import 'package:pdfrx/pdfrx.dart';

import 'offline_book_model.dart';

class CurriculumSearchHit {
  final OfflineBookInfo book;
  final int page;
  final String excerpt;
  final int score;

  const CurriculumSearchHit({
    required this.book,
    required this.page,
    required this.excerpt,
    required this.score,
  });
}

/// Searches text in books already saved on this device and keeps the page
/// reference beside each excerpt so the assistant can show its source.
class CurriculumBookSearch {
  CurriculumBookSearch._();

  static final Map<String, Future<List<_IndexedPage>>> _pageCache =
      <String, Future<List<_IndexedPage>>>{};

  static String normalize(String value) => value
      .toLowerCase()
      .replaceAll('أ', 'ا')
      .replaceAll('إ', 'ا')
      .replaceAll('آ', 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('\u0640', '')
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '');

  static void invalidateBook(String key) {
    _pageCache.removeWhere((cacheKey, _) => cacheKey.startsWith('$key|'));
  }

  static Future<List<CurriculumSearchHit>> search({
    required String query,
    required List<OfflineBookInfo> books,
    int maxResults = 5,
    int maxPagesPerBook = 500,
  }) async {
    final terms = RegExp(r'[\u0600-\u06FF\w]+')
        .allMatches(normalize(query))
        .map((match) => match.group(0)!)
        .where((term) => term.length > 2)
        .toSet();
    if (terms.isEmpty) return const <CurriculumSearchHit>[];

    final hits = <CurriculumSearchHit>[];
    for (final book in books) {
      final cacheKey = '${book.key}|${book.path}|${book.url}';
      try {
        final pages = await _pageCache.putIfAbsent(
          cacheKey,
          () => _indexBook(book, maxPagesPerBook),
        );
        for (final page in pages) {
          final matchingTerms = terms.where(page.normalizedText.contains).toList();
          if (matchingTerms.isEmpty) continue;
          final firstIndex = page.normalizedText.indexOf(matchingTerms.first);
          final originalIndex = page.originalOffsets[firstIndex];
          final start = (originalIndex - 100).clamp(0, page.text.length).toInt();
          final end = (originalIndex + 260).clamp(start, page.text.length).toInt();
          hits.add(CurriculumSearchHit(
            book: book,
            page: page.page,
            excerpt: page.text.substring(start, end).replaceAll('\n', ' '),
            score: matchingTerms.length,
          ));
        }
      } catch (_) {
        _pageCache.remove(cacheKey);
        // One damaged, scanned, or inaccessible PDF should not hide other books.
      }
    }
    hits.sort((a, b) => b.score.compareTo(a.score));
    return hits.take(maxResults).toList();
  }

  static Future<List<_IndexedPage>> _indexBook(OfflineBookInfo book, int limit) async {
    PdfDocument? document;
    try {
      document = await PdfDocument.openFile(book.path);
      final pages = <_IndexedPage>[];
      for (final page in document.pages.take(limit)) {
        final text = (await page.loadText())?.fullText.trim() ?? '';
        if (text.isNotEmpty) {
          final normalized = _normalizeWithOffsets(text);
          pages.add(_IndexedPage(
            page: page.pageNumber,
            text: text,
            normalizedText: normalized.text,
            originalOffsets: normalized.originalOffsets,
          ));
        }
      }
      return pages;
    } finally {
      await document?.dispose();
    }
  }
}

({String text, List<int> originalOffsets}) _normalizeWithOffsets(String value) {
  final normalized = StringBuffer();
  final originalOffsets = <int>[];
  var originalIndex = 0;
  for (final rune in value.runes) {
    final originalCharacter = String.fromCharCode(rune);
    final character = CurriculumBookSearch.normalize(originalCharacter);
    normalized.write(character);
    for (var i = 0; i < character.length; i++) {
      originalOffsets.add(originalIndex);
    }
    originalIndex += rune > 0xFFFF ? 2 : 1;
  }
  return (text: normalized.toString(), originalOffsets: originalOffsets);
}

class _IndexedPage {
  final int page;
  final String text;
  final String normalizedText;
  final List<int> originalOffsets;

  const _IndexedPage({
    required this.page,
    required this.text,
    required this.normalizedText,
    required this.originalOffsets,
  });
}
