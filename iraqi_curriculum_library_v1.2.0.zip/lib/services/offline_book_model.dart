import 'dart:async';

/// Cancellation signal shared by the UI and the streaming downloader.
class OfflineDownloadCancellation {
  final Completer<void> _abort = Completer<void>();

  bool get isCancelled => _abort.isCompleted;
  Future<void> get abortTrigger => _abort.future;

  void cancel() {
    if (!_abort.isCompleted) _abort.complete();
  }
}

class OfflineDownloadCancelled implements Exception {
  const OfflineDownloadCancelled();

  @override
  String toString() => 'أُلغي تنزيل الكتاب.';
}

class OfflineBookInfo {
  final String key;
  final String title;
  final String grade;
  final String subject;
  final String url;
  final String path;

  const OfflineBookInfo({
    required this.key,
    required this.title,
    required this.grade,
    required this.subject,
    required this.url,
    required this.path,
  });

  Map<String, dynamic> toJson() => {
        'key': key,
        'title': title,
        'grade': grade,
        'subject': subject,
        'url': url,
        'path': path,
      };

  factory OfflineBookInfo.fromJson(Map<String, dynamic> json) => OfflineBookInfo(
        key: json['key'] as String? ?? '',
        title: json['title'] as String? ?? 'كتاب محفوظ',
        grade: json['grade'] as String? ?? '',
        subject: json['subject'] as String? ?? '',
        url: json['url'] as String? ?? '',
        path: json['path'] as String? ?? '',
      );
}
