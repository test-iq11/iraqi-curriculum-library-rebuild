import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

import 'offline_book_model.dart';

Future<Directory> _offlineDirectory([String? storagePath]) async {
  final dir = storagePath == null
      ? Directory('${(await getApplicationDocumentsDirectory()).path}${Platform.pathSeparator}offline_books')
      : Directory(storagePath);
  if (!await dir.exists()) await dir.create(recursive: true);
  return dir;
}

String _fileToken(String key) => base64Url.encode(utf8.encode(key)).replaceAll('=', '');

String _directDownloadUrl(String url) {
  final id = RegExp(r'/d/([^/?]+)').firstMatch(url)?.group(1);
  if (id == null) return url;
  return 'https://drive.google.com/uc?export=download&id=$id';
}

Future<OfflineBookInfo?> saveBookOffline({
  required String key,
  required String title,
  required String grade,
  required String subject,
  required String url,
  OfflineDownloadCancellation? cancellation,
  void Function(int receivedBytes, int? totalBytes)? onProgress,
  http.Client? client,
  String? storagePath,
}) async {
  if (url.trim().isEmpty) throw ArgumentError('رابط الكتاب غير متوفر.');

  final directory = await _offlineDirectory(storagePath);
  final token = _fileToken(key);
  final pdf = File('${directory.path}${Platform.pathSeparator}$token.pdf');
  final partialPdf = File('${pdf.path}.part');
  final metadata = File('${directory.path}${Platform.pathSeparator}$token.meta.json');
  final activeClient = client ?? http.Client();
  final ownsClient = client == null;
  try {
    final request = http.AbortableRequest(
      'GET',
      Uri.parse(_directDownloadUrl(url)),
      abortTrigger: cancellation?.abortTrigger,
    )..headers.addAll(const {'Accept': 'application/pdf,*/*'});
    final response = await activeClient.send(request).timeout(const Duration(seconds: 90));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw HttpException('تعذر تنزيل الملف (HTTP ${response.statusCode}).');
    }

    final sink = partialPdf.openWrite();
    final signature = <int>[];
    var received = 0;
    try {
      await for (final chunk in response.stream.timeout(const Duration(seconds: 90))) {
        if (cancellation?.isCancelled ?? false) throw const OfflineDownloadCancelled();
        for (final byte in chunk) {
          if (signature.length == 4) break;
          signature.add(byte);
        }
        sink.add(chunk);
        received += chunk.length;
        onProgress?.call(received, response.contentLength);
      }
      await sink.flush();
    } on http.RequestAbortedException {
      throw const OfflineDownloadCancelled();
    } finally {
      await sink.close();
    }

    final isPdf = signature.length == 4 &&
        signature[0] == 0x25 && signature[1] == 0x50 &&
        signature[2] == 0x44 && signature[3] == 0x46;
    if (!isPdf) {
      throw const FormatException('لم يُرجع Google Drive ملف PDF مباشراً. افتح الرابط وتأكد من إتاحة الملف للجميع، ثم جرّب مجدداً.');
    }
    if (cancellation?.isCancelled ?? false) throw const OfflineDownloadCancelled();

    if (await pdf.exists()) await pdf.delete();
    await partialPdf.rename(pdf.path);
    final info = OfflineBookInfo(
      key: key,
      title: title,
      grade: grade,
      subject: subject,
      url: url,
      path: pdf.path,
    );
    await metadata.writeAsString(jsonEncode(info.toJson()), flush: true);
    return info;
  } on http.RequestAbortedException {
    throw const OfflineDownloadCancelled();
  } finally {
    if (ownsClient) activeClient.close();
    if (await partialPdf.exists()) await partialPdf.delete();
  }
}

Future<List<OfflineBookInfo>> loadOfflineBooks() async {
  final directory = await _offlineDirectory();
  final found = <OfflineBookInfo>[];
  await for (final entity in directory.list()) {
    if (entity is! File || !entity.path.endsWith('.meta.json')) continue;
    try {
      final decoded = jsonDecode(await entity.readAsString());
      final info = OfflineBookInfo.fromJson(Map<String, dynamic>.from(decoded as Map));
      if (info.path.isNotEmpty && await File(info.path).exists()) found.add(info);
    } catch (_) {
      // Ignore corrupt metadata and continue loading other offline books.
    }
  }
  found.sort((a, b) => a.title.compareTo(b.title));
  return found;
}

Future<bool> hasOfflineBook(String key) async {
  final directory = await _offlineDirectory();
  return File('${directory.path}${Platform.pathSeparator}${_fileToken(key)}.pdf').exists();
}

Future<bool> openOfflineBook(String key) async {
  final directory = await _offlineDirectory();
  final pdf = File('${directory.path}${Platform.pathSeparator}${_fileToken(key)}.pdf');
  if (!await pdf.exists()) return false;
  await OpenFilex.open(pdf.path);
  return true;
}

Future<bool> deleteOfflineBook(String key) async {
  final directory = await _offlineDirectory();
  final token = _fileToken(key);
  final pdf = File('${directory.path}${Platform.pathSeparator}$token.pdf');
  final metadata = File('${directory.path}${Platform.pathSeparator}$token.meta.json');
  var deleted = false;
  if (await pdf.exists()) {
    await pdf.delete();
    deleted = true;
  }
  if (await metadata.exists()) await metadata.delete();
  return deleted;
}
