import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Appearance settings persisted on the device; never clears book downloads.
class LibraryPalette {
  LibraryPalette._();

  static Color accent = const Color(0xFF2864E8);
  static double radius = 22;
  static bool compact = false;
  static bool reduceMotion = false;
  static final Map<String, Color> stages = <String, Color>{};
  static final Map<String, Color> grades = <String, Color>{};

  static const stageNames = <String>[
    'المرحلة الابتدائية',
    'المرحلة المتوسطة',
    'المرحلة الإعدادية',
  ];

  static const defaultStageColors = <Color>[
    Color(0xFF2864E8),
    Color(0xFF10A97D),
    Color(0xFFF59E0B),
  ];

  static const presetNames = <String>[
    'الكلاسيكي', 'الزمردي', 'البنفسجي', 'الوردي', 'البحري',
  ];

  static const presetColors = <List<Color>>[
    [Color(0xFF2864E8), Color(0xFF2864E8), Color(0xFF10A97D), Color(0xFFF59E0B)],
    [Color(0xFF0E9382), Color(0xFF167E91), Color(0xFF10A97D), Color(0xFFC58E36)],
    [Color(0xFF8257CF), Color(0xFF6859C9), Color(0xFF36A796), Color(0xFFDC8A40)],
    [Color(0xFFC15C85), Color(0xFF6A78DD), Color(0xFF329F8A), Color(0xFFDD8D56)],
    [Color(0xFF176FAD), Color(0xFF2366B5), Color(0xFF258E85), Color(0xFFD79D30)],
  ];

  static Color stageColor(String stage) {
    final index = stageNames.indexOf(stage);
    return stages[stage] ?? (index < 0 ? accent : defaultStageColors[index]);
  }

  static Color gradeColor(String grade, Color fallback) => grades[grade] ?? fallback;

  static void load(SharedPreferences prefs, Iterable<String> gradeNames) {
    accent = Color(prefs.getInt('lib-color-accent') ?? 0xFF2864E8);
    radius = (prefs.getDouble('lib-radius') ?? 22).clamp(14.0, 30.0).toDouble();
    compact = prefs.getBool('lib-compact') ?? false;
    reduceMotion = prefs.getBool('lib-reduce-motion') ?? false;
    stages.clear();
    grades.clear();
    for (final stage in stageNames) {
      final value = prefs.getInt('lib-color-stage:$stage');
      if (value != null) stages[stage] = Color(value);
    }
    for (final grade in gradeNames) {
      final value = prefs.getInt('lib-color-grade:$grade');
      if (value != null) grades[grade] = Color(value);
    }
  }

  static Future<void> setAccent(SharedPreferences prefs, Color value) async {
    accent = value;
    await prefs.setInt('lib-color-accent', value.toARGB32());
  }

  static Future<void> setStage(SharedPreferences prefs, String stage, Color value) async {
    stages[stage] = value;
    await prefs.setInt('lib-color-stage:$stage', value.toARGB32());
  }

  static Future<void> setGrade(SharedPreferences prefs, String grade, Color value) async {
    grades[grade] = value;
    await prefs.setInt('lib-color-grade:$grade', value.toARGB32());
  }

  static Future<void> setRadius(SharedPreferences prefs, double value) async {
    radius = value.clamp(14, 30).toDouble();
    await prefs.setDouble('lib-radius', radius);
  }

  static Future<void> setCompact(SharedPreferences prefs, bool value) async {
    compact = value;
    await prefs.setBool('lib-compact', value);
  }

  static Future<void> setReduceMotion(SharedPreferences prefs, bool value) async {
    reduceMotion = value;
    await prefs.setBool('lib-reduce-motion', value);
  }

  static Future<void> applyPreset(SharedPreferences prefs, int presetIndex) async {
    final index = presetIndex.clamp(0, presetColors.length - 1).toInt();
    final set = presetColors[index];
    await setAccent(prefs, set[0]);
    for (var i = 0; i < stageNames.length; i++) {
      await setStage(prefs, stageNames[i], set[i + 1]);
    }
  }
}
