import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_curriculum_library/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  testWidgets('the Iraqi library app opens in Arabic', (tester) async {
    appPrefs = await SharedPreferences.getInstance();
    await tester.pumpWidget(const IraqiLibraryApp());
    // The app has continuous decorative/loading animations; one frame is
    // enough to check its initial content without waiting for every ticker.
    await tester.pump();

    expect(find.text('المرحلة الابتدائية'), findsWidgets);
    expect(find.text('المرحلة المتوسطة'), findsWidgets);
    // The first stage card is rendered at the top without a hero headline.
    expect(find.text('المراحل الدراسية'), findsNothing);
    expect(
      find.byWidgetPredicate(
        (widget) => widget is Directionality && widget.textDirection == TextDirection.rtl,
      ),
      findsWidgets,
    );
  });

  testWidgets('the study planner saves a task locally', (tester) async {
    appPrefs = await SharedPreferences.getInstance();
    await tester.pumpWidget(const MaterialApp(home: StudyPlannerScreen()));
    await tester.enterText(find.byType(TextField).first, 'مراجعة الفصل الأول');
    await tester.tap(find.text('إضافة إلى الجدول'));
    await tester.pumpAndSettle();

    expect(find.text('مراجعة الفصل الأول'), findsOneWidget);
    expect(appPrefs.getString('studyTasks'), contains('مراجعة الفصل الأول'));
  });
}
