import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:iraqi_curriculum_library/services/offline_book_storage.dart';

void main() {
  late Directory temporaryDirectory;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp('curriculum-books-');
  });

  tearDown(() async {
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  test('streams and saves a valid PDF and reports progress', () async {
    final pdfBytes = <int>[0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x37];
    final progress = <(int, int?)>[];
    // MockClient adapts outgoing requests to Request before invoking its
    // handler, so the handler cannot assert the original AbortableRequest type.
    final client = MockClient((_) async => http.Response.bytes(pdfBytes, 200));

    final saved = await saveBookOffline(
      key: 'grade-one-math',
      title: 'الرياضيات',
      grade: 'الأول الابتدائي',
      subject: 'الرياضيات',
      url: 'https://example.test/book.pdf',
      client: client,
      storagePath: temporaryDirectory.path,
      onProgress: (received, total) => progress.add((received, total)),
    );

    expect(saved, isNotNull);
    expect(await File(saved!.path).readAsBytes(), pdfBytes);
    expect(progress, isNotEmpty);
    expect(progress.last.$1, pdfBytes.length);
    expect(await File('${saved.path}.part').exists(), isFalse);
    expect(await File(saved.path.replaceFirst('.pdf', '.meta.json')).exists(), isTrue);
  });

  test('rejects a non-PDF response and removes the partial file', () async {
    final client = MockClient((_) async => http.Response('not a PDF', 200));

    await expectLater(
      saveBookOffline(
        key: 'invalid-book',
        title: 'كتاب غير صالح',
        grade: 'الأول',
        subject: 'العلوم',
        url: 'https://example.test/book.pdf',
        client: client,
        storagePath: temporaryDirectory.path,
      ),
      throwsA(isA<FormatException>()),
    );

    expect(await temporaryDirectory.list().toList(), isEmpty);
  });
}
