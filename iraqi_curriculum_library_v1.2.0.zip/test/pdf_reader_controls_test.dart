import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_curriculum_library/screens/pdf_reader_controls.dart';

void main() {
  // Exercise the real toolbar inside Scaffold: an unconstrained Slider used to
  // make bottomNavigationBar cover the screen and leave the PDF a zero-height body.
  for (final size in [const Size(320, 640), const Size(393, 851), const Size(800, 360)]) {
    for (final pageCount in [0, 120]) {
      testWidgets('reader keeps PDF visible at $size with $pageCount pages', (tester) async {
        tester.view.devicePixelRatio = 1;
        tester.view.physicalSize = size;
        tester.view.padding = const FakeViewPadding(bottom: 24);
        addTearDown(tester.view.resetDevicePixelRatio);
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetPadding);

        const bodyKey = ValueKey('pdf-viewport');
        await tester.pumpWidget(MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              appBar: AppBar(title: const Text('الكتاب')),
              body: const SizedBox.expand(key: bodyKey),
              bottomNavigationBar: PdfReaderControls(
                pageNumber: pageCount == 0 ? 1 : 25,
                pageCount: pageCount,
                onPreviewPage: (_) {},
                onGoToPage: (_) {},
                onShowThumbnails: () {},
              ),
            ),
          ),
        ));

        expect(tester.takeException(), isNull);
        final toolbar = tester.getRect(find.byType(PdfReaderControls));
        final body = tester.getRect(find.byKey(bodyKey));
        final header = tester.getRect(find.byType(AppBar));
        expect(toolbar.height, lessThanOrEqualTo(80));
        expect(toolbar.bottom, closeTo(size.height, .1));
        expect(body.height, greaterThan(size.height * .5));
        expect(body.top, greaterThanOrEqualTo(header.bottom));
        expect(body.bottom, lessThanOrEqualTo(toolbar.top + .1));
        expect(find.text('الكتاب').hitTestable(), findsOneWidget);
      });
    }
  }
}
