import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_curriculum_library/main.dart';
import 'package:iraqi_curriculum_library/theme/library_palette.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
  });

  test('first primary reading and activity link are present and unique', () {
    final firstGrade = makeBooks().where((book) => book.grade == 'الأول الابتدائي');
    final reading = firstGrade.where((book) => book.title == 'كتاب القراءة').toList();
    final activity = firstGrade.where((book) => book.title == 'نشاط القراءة').toList();
    expect(reading, hasLength(1));
    expect(activity, hasLength(1));
    expect(reading.single.url, contains('10RMSOmVOmJ0I5aUFvQMGH2D5qs3WrmAN'));
    expect(activity.single.url, contains('1Ih3Wm3i-UMhP73VTGtKdgsAQiHa2fQSm'));
    expect(activity.single.subject, 'اللغة العربية');
  });

  test('color palette persists stage, grade, accent and spacing separately', () async {
    final prefs = await SharedPreferences.getInstance();
    LibraryPalette.load(prefs, grades);
    const accent = Color(0xFF5571BB);
    const primary = Color(0xFF0D8B82);
    const grade = Color(0xFF7947C1);
    await LibraryPalette.setAccent(prefs, accent);
    await LibraryPalette.setStage(prefs, LibraryPalette.stageNames[0], primary);
    await LibraryPalette.setGrade(prefs, grades[0], grade);
    await LibraryPalette.setCompact(prefs, true);
    LibraryPalette.load(prefs, grades);
    expect(LibraryPalette.accent, accent);
    expect(LibraryPalette.stageColor(LibraryPalette.stageNames[0]), primary);
    expect(LibraryPalette.grades[grades[0]], grade);
    expect(LibraryPalette.compact, isTrue);
  });
}
