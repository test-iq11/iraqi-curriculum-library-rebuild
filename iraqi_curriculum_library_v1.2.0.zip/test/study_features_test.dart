import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_curriculum_library/main.dart';
import 'package:iraqi_curriculum_library/services/curriculum_book_search.dart';

void main() {
  test('Arabic query normalization handles common letter variants', () {
    expect(CurriculumBookSearch.normalize('أإآ ى ة اَلْكِتاب'), 'ااا ي ه الكتاب');
  });

  test('study tasks retain notification IDs when saved and restored', () {
    final task = StudyTask(
      title: 'مراجعة الرياضيات',
      grade: 'الأول المتوسط',
      subject: 'الرياضيات',
      due: DateTime(2026, 10, 25, 18),
    );

    final restored = StudyTask.fromJson(task.toJson());
    expect(restored.id, task.id);
    expect(restored.title, task.title);
    expect(restored.due, task.due);
  });

  test('old task records migrate with a notification ID', () {
    final migrated = StudyTask.fromJson({
      'title': 'واجب',
      'grade': 'الثاني الابتدائي',
      'subject': 'اللغة العربية',
      'due': '2026-10-26T18:00:00.000',
      'done': false,
    });

    expect(migrated.id, greaterThan(0));
    expect(migrated.title, 'واجب');
  });

  test('quiz results keep missed topics for the progress view', () {
    final result = QuizResult(
      grade: 'الأول المتوسط',
      subject: 'الرياضيات',
      score: 7,
      total: 10,
      date: DateTime(2026, 10, 24),
      missedUnits: const ['القسمة'],
    );
    final restored = QuizResult.fromJson(result.toJson());

    expect(restored.missedUnits, ['القسمة']);
  });
}
