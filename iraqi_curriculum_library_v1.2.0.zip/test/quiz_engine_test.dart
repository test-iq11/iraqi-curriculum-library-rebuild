import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_curriculum_library/main.dart';

void main() {
  group('grade-aware quiz questions', () {
    test('math topics and values adapt to the selected grade', () {
      const firstGrade = 'الأول الابتدائي';
      const sixthGrade = 'السادس الابتدائي';
      final first = makeQuizQuestions(firstGrade, 'الرياضيات');
      final sixth = makeQuizQuestions(sixthGrade, 'الرياضيات');

      expect(first, isNotEmpty);
      expect(first.every((question) => question.grade == firstGrade), isTrue);
      expect(first.map((question) => question.unit).toSet(), containsAll({'الجمع', 'الطرح'}));
      expect(first.map((question) => question.unit), isNot(contains('المعادلات')));
      expect(sixth.map((question) => question.unit), contains('المعادلات'));
      expect(
        first.map((question) => question.text).toSet(),
        isNot(equals(sixth.map((question) => question.text).toSet())),
      );
    });

    test('each generated question keeps its correct answer after choices shuffle', () {
      final questions = makeQuizQuestions('الثالث المتوسط', 'الرياضيات', difficulty: 'صعب');

      expect(questions, hasLength(120));
      for (final question in questions) {
        expect(question.choices, hasLength(4));
        expect(question.answer, inInclusiveRange(0, question.choices.length - 1));
        expect(question.grade, 'الثالث المتوسط');
        expect(question.subject, 'الرياضيات');
        expect(question.explanation, isNotEmpty);
        expect(question.bankVersion, quizBankVersion);
      }
    });

    test('existing subject banks are clearly marked as not page-cited', () {
      final questions = makeQuizQuestions('السادس العلمي', 'اللغة العربية');

      expect(questions, isNotEmpty);
      expect(questions.every((question) => question.grade == 'السادس العلمي'), isTrue);
      expect(questions.every((question) => question.source == null), isTrue);
    });
  });
}
